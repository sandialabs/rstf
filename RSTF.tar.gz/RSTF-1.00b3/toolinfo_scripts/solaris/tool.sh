# toolname, arguments
tool_start () {
    if [ "x$RST_COMPILER_OUTPUT_FILE" != "x" ];
	then
	echo "@tool(" $1  ")" >> $RST_COMPILER_OUTPUT_FILE
	echo "Arguments: " $2 >> $RST_COMPILER_OUTPUT_FILE
	echo 'Directory: ' `pwd`  >> $RST_COMPILER_OUTPUT_FILE 
	echo '@begin'  >> $RST_COMPILER_OUTPUT_FILE
    fi
}

# No arguments
tool_end () {
    if [ "x$RST_COMPILER_OUTPUT_FILE" != "x" ];
	then
	echo '@end'  >> $RST_COMPILER_OUTPUT_FILE
    fi
}

#cmd, args
tool_call () {
    if [ "x$RST_COMPILER_OUTPUT_FILE" != "x" ];
	then
	$1 $2  >> $RST_COMPILER_OUTPUT_FILE 2>&1
    fi
}

