#!/bin/sh
TOOLNAME=its.cpp
TOOL=/usr/ccs/lib/cpp

. $RST_WRAPPER_BIN/tool.sh

# start info
tool_start $TOOLNAME "$*"

# print expanded flags
tool_call $TOOL "-V /dev/null";

#end info
tool_end


$TOOL $*
