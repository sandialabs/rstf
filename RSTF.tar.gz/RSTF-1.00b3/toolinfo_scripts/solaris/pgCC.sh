#!/bin/sh
TOOLNAME=pgCC
TOOL=/usr/local/intel/tflop/current/tflops/bin.solaris/pgCC

. $RST_WRAPPER_BIN//tool.sh

# start info
tool_start $TOOLNAME "$*"

# print expanded flags
tool_call $TOOL "-V -dryrun $*";

#end info
tool_end


$TOOL $*
