#!/usr/bin/perl -w
###############################################################################
#  copyright {
# Copyright 2004  Sandia Corporation. Under the terms of
# Contract DE-AC04-94AL85000, there is a non-exclusive license for use
# of this work by or on behalf of the U.S. Government. Export of this
# program may require a license from the United States Government.
#
# This file is a portion of the Robust Systems Test Framework distribution.
# } 
#  
# 
# parse_benchmarks.pl
# 
# Created by: Robert A. Ballance		Wed Oct 13 16:32:11 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/parse_benchmarks.pl,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################

use strict;
use warnings;

use RSTF::Compile::XMLParser;
use XML::Twig;

use RSTF::Configuration;
use RSTF::DB::Application;
use RSTF::DB::Benchmark;
use RSTF::DB::BenchmarkPlanning;
use RSTF::DB::BenchmarkState;
use RSTF::DB::DAOFactory;
use RSTF::DB::DBConnect;
use RSTF::DB::TestCase;
use RSTF::DB::TestCasePlanning;
use RSTF::DB::TestType;
use RSTF::DB::Contact;
use RSTF::DB::Role;
use RSTF::DB::AppContactMap;
use RSTF::DB::Study;
use RSTF::DB::Purpose;
use RSTF::DB::NoteList;
use RSTF::DB::Note;

use vars qw(@ISA);
@ISA = qw(RSTF::Compile::XMLParser);

my $config = new RSTF::Configuration();
$config->getopt();

if ($config->help()) {
    show_help();
    exit(1);
}

trace_init($config->verbose);

unless ($config->database_connect()) {
    die "It does not make sense to run parse_benchmarks without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();

my $application;
my $app_config;
my $benchmark;
my @studylist;
my $status_platform;


sub lookup_contact {
    my $email_addr = shift;
    if ($email_addr && $email_addr =~ /.+@.+/) {
	unless ($email_addr eq 'unknown@sandia.gov') {
	    return RSTF::DB::Contact->find_by_name($email_addr);
	}
    }
    return undef;
}

sub application_handler {
    my ($twig, $field) = @_;
    
    trace_enter('application');
    my $app_name = safe_get_attr($field, 'name');
    $app_config = safe_get_text($field, 'configuration') || 'Standard';
    $application = RSTF::DB::Application->find_by_name($app_name);
    die "Application $app_name not found" unless ($application);
    trace_exit('application');
}

sub benchmark_handler {
  my ($twig, $field) = @_;

  trace_enter('benchmark');

  my $title = safe_get_text($field, 'title');
  my $description = safe_get_text($field, 'description');

  $benchmark->title($title);
  $benchmark->description($description);
  $benchmark->app_id($application->app_id);
  $benchmark->app_config($app_config);
  $benchmark->update;

  trace_exit('benchmark');
}

sub study_handler {
    my ($twig, $field) = @_;
    trace_enter('study');

    # date
    my $date = safe_get_attr($field, 'date');
    $date ||= '';
    if ($date eq '') {
	$date = undef;
    }
    # size
    my $size = safe_get_attr($field, 'size');
    # mode
    my $mode = safe_get_attr($field, 'mode');

    # descrip
    my $description = safe_get_text($field, 'description');

    # studies are unique in size, platform, and mode
    # platform is in the $status_platform global variable.

    my $purpose_name = safe_get_attr($field, 'purpose');
    $purpose_name ||= 'unknown';
    my $purpose = RSTF::DB::Purpose->find_by_name($purpose_name);

    # state
    my $state_name = safe_get_attr($field, 'state');
    $state_name ||= 'Unknown';
    my $state	=  RSTF::DB::BenchmarkState->find_by_name($state_name);

    my $notelist = get_study_notes($field);
    # !!! Need the benchmark id here!
    my $study = new RSTF::DB::Study(size => $size,
				    mode=> $mode,
				    date=>$date,
				    purpose=>$purpose,
				    description=>$description,
				    notes => $notelist,
				    state=>$state);



    push @studylist, $study;
    trace_exit('study');
}

sub get_study_notes {
    my $field = shift;

    my $note_field = $field->first_child('note');
    my @notes;
    while ($note_field) {
	my $note = get_note($note_field);
	push @notes, $note;
	$note_field = $note_field->next_sibling('note');
    }
    return new RSTF::DB::NoteList(notelist=>\@notes);
}

sub get_note {
    my $field = shift;

    my $author_name = safe_get_attr($field, 'author');
    $author_name ||= $config->runner();

    my $author_id = safe_get_attr($field, 'author_id');
    my $date = safe_get_attr($field, 'date');
    
    my $text = $field->trimmed_text();


    my $contact_id;
    if($author_id) {
	$contact_id = $author_id;
    } else {	
	my $author = RSTF::DB::Contact->find_by_name($author_name);
	if ($author) {
	    $contact_id = $author->contact_id;
	}
    }
    return new RSTF::DB::Note(author_id=>$contact_id, text=>$text, date=>$date);
}

sub assignment_handler {
    my ($twig, $field) = @_;
    my $contact_email = safe_get_attr($field, 'contact');
    my $rolename = safe_get_attr($field, 'role');

    my $contact = lookup_contact($contact_email);
    die "Unable to find contact $contact_email" unless($contact);

    my $role = RSTF::DB::Role->find_by_name($rolename);
    die "Unable to find Role $rolename" unless($role);

    my $assignment = new RSTF::DB::AppContactMap(
					 benchmark_id=>$benchmark->benchmark_id,
					 contact_id=>$contact->contact_id,
					 role_id=>$role->role_id);

    printf "Adding assignment of %s as %s to %s\n", $contact->full_name, $role->role, $benchmark->nickname;
    $assignment->insert();
}

sub find_platform {
    my $field = shift;
    my $where = shift;
    my $platform_name = safe_get_attr($field, 'platform');
    unless ($platform_name) {
	die "$where must specify their platform!\n";
    }

    my $platform = RSTF::DB::Platform->find_by_name($platform_name);
    unless ($platform) {
	die "Platform $platform not found";
    }
    return $platform;
}
    
sub testcase_handler {
  my ($twig, $field) = @_;

  trace_enter('testcase');

  my $status = safe_get_attr($field, 'status');
  my $test_type_name = safe_get_attr($field, 'type');
  my $size = safe_get_attr($field, 'size') || 'NULL';
  my $mode = safe_get_attr($field, 'mode') || 'proc3';
  my $nodes = safe_get_attr($field, 'nodes');

  my $platform = find_platform($field, 'TestCase');

  my $benchmark_state = RSTF::DB::BenchmarkState->find_by_name($status);
  die "No such status $status" unless ($benchmark_state);

  # Cache this?
  my $test_type = RSTF::DB::TestType->find_by_name($test_type_name);
  die "No such test_type $test_type" unless ($test_type);

  # get platform attribute from testcase.
  # push the status information into a slot in the testcase, once it is allocated
  # or push the pair (testcase, status) into the @testcases list.
  
  my $procs_per_node = 1;
  if ($platform->name eq 'Red') {
      if ($mode eq 'proc3') {
	  $procs_per_node = 2;
      }
  } else {
      $mode = undef;
  }
  die "No benchmark set " unless($benchmark);

  
  # check for extant test case here (benchmark, platform, size);

  my $testcase;
  eval {
      $testcase = RSTF::DB::TestCase->find_by_name($benchmark->benchmark_id,$platform->platform_id,$size);
  };
  unless  ($testcase) {
      $testcase  = new RSTF::DB::TestCase(
					 benchmark_id=>$benchmark->benchmark_id,
					 size => $size,
					 platform_id => $platform->platform_id);

      $testcase->insert();
  }
  $testcase->procs_per_node($procs_per_node);
  $testcase->nodes_required($nodes);
  $testcase->benchmark_state_id($benchmark_state->benchmark_state_id);
  $testcase->test_type_id($test_type->test_type_id);
  $testcase->red_proc_mode($mode);
  $testcase->update();
  # now build the status info

  # check for value from TestCase!
  my $status_info = $testcase->planning_status();
  tc_status_handler($field, $status_info);
  $status_info->update();
  trace_exit('testcase');

}

sub start_studylist {
  my ($twig, $field) = @_;
  $app_config = undef;
  trace_enter('start_studylist');
  @studylist = ();
 trace_exit('start_studylist');
}

sub start_benchmark {
  my ($twig, $field) = @_;
  $app_config = undef;
  trace_enter('start_benchmark');

  my $nickname = safe_get_attr($field, 'nickname');
  my $tag = safe_get_attr($field, 'tag');
  
  $benchmark = undef;
  if ($nickname) {
      eval {
	  $benchmark = RSTF::DB::Benchmark->find_by_name($nickname);
      };
  }
  if ($benchmark) {
      my $db = RSTF::DB::DAOFactory::get_connection();
      my $id = $benchmark->benchmark_id();
      $db->execute("DELETE FROM AppContactMap where benchmark_id=$id");
  } else {
      
      $benchmark = new RSTF::DB::Benchmark(
					  nickname=>$nickname,
					  tag => $tag);
      $benchmark = $benchmark->insert;
  }
  trace_exit('start_benchmark');
}

sub clear_benchmarks {
    my $app = shift;
    my $appname = $app->name;
    my $app_id = $app->app_id;
    my $db = RSTF::DB::DAOFactory::get_connection();
    print "Flushing contact data for $appname\n";
    $db->execute("DELETE FROM AppContactMap where app_id=$app_id");
}

sub get_date_attr {
    my $field = shift;
    my $childname = shift;
    my $child = $field->first_child($childname);
    if ($child) {
	my $attr = safe_get_attr($child, 'date');
	if ($attr eq '') {
	    return undef;
        }
	return $attr;
    }
    return undef;
}

# Deal with the benchmark status information.
my $benchmark_status;

sub benchmark_status_handler {
    my ($twig, $field) = @_;

    my $platform = find_platform($field, 'benchmark_status');
    my $self;
    eval {
	$self = RSTF::DB::BenchmarkPlanning->find_by_name($benchmark->benchmark_id,
							  $platform->platform_id);
    };
    unless ($self) {
	$self = RSTF::DB::BenchmarkPlanning->new(
						 benchmark_id=>$benchmark->benchmark_id,
						 platform_id=>$platform->platform_id);
	$self->insert();
    }
    my @date_fields = qw(source_code_ready
			 compile_scripts_available
			 compile_scripts_tested);

    foreach my $name (@date_fields) {
	my $attr = get_date_attr($field, $name);
	$self->$name($attr);
    }
    # May be premature to update this here, but let's try
    $self->update();
    # now try for the studies.
    foreach my $study (@studylist) {
	my $size = $study->size;
	# don't create a study if it is already there!
	$study->benchmark_plan_id($self->benchmark_plan_id);
	my $actual_study = RSTF::DB::Study->find_by_name($study->benchmark_plan_id, 
							 $study->size,
							 $study->mode);
	

	if ($actual_study) {
	    $study->study_id($actual_study->study_id);
	    $study->update();
	} else {
	    $study->insert();
	}
    }
}

my @date_fields = qw(
	data_set_on_hand
	inputs_prepared
	sample_scripts_available
	rst_scripts_written
	rst_scripts_tested
	preliminary_runs_scheduled
	preliminary_runs_complete
	final_runs_scheduled
	final_runs_complete
);


sub tc_status_handler {
    my $field = shift;    
    my $status_record = shift;
    foreach my $name (@date_fields) {
	my $attr = get_date_attr($field, $name);
	$status_record->$name($attr);
    }
    return $status_record;
}

foreach my $filename (@ARGV) {
    unless (-e $filename && -r $filename) {
	die "A Filename must be specified";
    }
    my $twig;
    eval {
	$twig = new XML::Twig(
			      TwigHandlers => { 
				  application => \&application_handler,
				  testcase => \&testcase_handler,
				  benchmark => \&benchmark_handler,
				  benchmarkstatus => \&benchmark_status_handler,
				  assignment => \&assignment_handler,
				  study => \&study_handler,
			      },
			      start_tag_handlers => {
				  benchmark=> \&start_benchmark,
				  studylist => \&start_studylist,
			      }
			      );
    };
    if ($@) {
	die $@;
    }
    my $ok = 0;
    eval {
	print "Processing $filename\n";
	$ok = $twig->parsefile($filename);
    };
    if ($@) {
	die $@;
    }
    $twig->purge();
}


