#!/usr/bin/perl -w
###############################################################################
# copyright {
# Copyright (c) 2004 Sandia National Laboratories
# } 
#  
# 
# parse_contacts.pl
# 
# Created by: Robert A. Ballance		Wed Sep 29 09:20:08 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/parse_contacts.pl,v $
# $Revision: 1.2 $
# $Name:  $
# $State: Exp $
# 
# Read contact info and place in the database.
###############################################################################

use strict;
use warnings;

use RSTF::Compile::XMLParser;
use XML::Twig;

use RSTF::Configuration;
use RSTF::DB::Contact;
use RSTF::DB::Application;
use RSTF::DB::DAOFactory;
use RSTF::DB::DBConnect;

use vars qw(@ISA);
@ISA = qw(RSTF::Compile::XMLParser);

my $config = new RSTF::Configuration;
$config->getopt();

if ($config->help()) {
    show_help();
    exit(1);
}

trace_init($config->verbose);

unless ($config->database_connect()) {
    die "It does not make sense to run parse_contacts without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();

my $contact;

sub contact_handler {
    my ($twig, $field) = @_;
    
    trace_enter('contact');
    my $surname = safe_get_text($field, 'surname');
    my $firstname = safe_get_text($field, 'firstname');
    my $nickname = safe_get_text($field, 'nickname');

    my $phone = safe_get_text($field, 'phone');
    my $email = safe_get_text($field, 'email');
    my $fax = safe_get_text($field, 'fax');

    my $company = safe_get_text($field, 'company');
    my $organization = safe_get_text($field, 'organization');
    
    eval {
	$contact = RSTF::DB::Contact->find_by_name($email);
    };
    unless ($contact) {
	$contact = new RSTF::DB::Contact(email=>$email);
	$contact->insert();
    }
    $contact->last_name($surname);
    $contact->first_name($firstname);
    $contact->nickname($nickname);
    $contact->fax($fax);
    $contact->phone($phone);
    $contact-> organization($organization);
    $contact-> company($company);
    $contact->update();

    trace_exit('contact');
}



foreach my $filename (@ARGV) {
    unless (-e $filename && -r $filename) {
	die "A Filename must be specified";
    }
    my $twig;
    eval {
	$twig = new XML::Twig(
			      TwigHandlers => { 
				  contact => \&contact_handler,
			      }     );
    };
    if ($@) {
	die $@;
    }
    my $ok = 0;
    eval {
	print "Processing $filename\n";
	$ok = $twig->parsefile($filename);
    };
    if ($@) {
	die $@;
    }
    $twig->purge();
}


