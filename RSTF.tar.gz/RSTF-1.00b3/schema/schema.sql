/* ----------------------------------------------------------------------------
 * copyright {

	Copyright 2004  Sandia Corporation. Under the terms of
	Contract DE-AC04-94AL85000, there is a non-exclusive license for use
	of this work by or on behalf of the U.S. Government. Export of this
	program may require a license from the United States Government.

	This file is a portion of the Robust Systems Test Framework distribution.

 * }
 * schema.sql
 * 
 * Created by: Robert A. Ballance		Fri Jan 16 11:16:14 2004
 * 
 * $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/schema.sql,v $
 * $Revision: 1.37 $
 * $Name:  $
 * $State: Exp $
 *  
 * Primary schema file for the SevenX database
 * 
 * ----------------------------------------------------------------------------
 */

/* ----------------------------------------------------------------------------
 * Domain Definitions
 * ----------------------------------------------------------------------------
 */
DROP DOMAIN BenchmarkName CASCADE;
CREATE DOMAIN BenchmarkName VARCHAR(32);

DROP DOMAIN TypeName CASCADE;
CREATE DOMAIN TypeName VARCHAR(16);

DROP DOMAIN CommandTypeName CASCADE;
CREATE DOMAIN CommandTypeName VARCHAR(32);

DROP DOMAIN CommandString CASCADE;
CREATE DOMAIN CommandString VARCHAR(32);

DROP DOMAIN CommandArgs CASCADE;
CREATE DOMAIN CommandArgs VARCHAR(256);

DROP DOMAIN CompilerFlags CASCADE;
CREATE DOMAIN CompilerFlags VARCHAR(2048);

DROP DOMAIN DispatchName CASCADE;
CREATE DOMAIN DispatchName VARCHAR(64);

DROP DOMAIN GradeName CASCADE;
CREATE DOMAIN GradeName VARCHAR(16);

DROP DOMAIN HostName CASCADE;
CREATE DOMAIN HostName VARCHAR(64);

DROP DOMAIN LanguageName CASCADE;
CREATE DOMAIN LanguageName VARCHAR(16);

DROP DOMAIN FileName CASCADE;
CREATE DOMAIN FileName VARCHAR(256);

DROP DOMAIN FilePath CASCADE;
CREATE DOMAIN FilePath VARCHAR(2048);

DROP DOMAIN ModeName CASCADE;
CREATE DOMAIN ModeName VARCHAR(8);

DROP DOMAIN PhoneNumber CASCADE;
CREATE DOMAIN PhoneNumber VARCHAR(16);

DROP DOMAIN PlatformName CASCADE;
CREATE DOMAIN PlatformName VARCHAR(16);

DROP DOMAIN PropertyName CASCADE;
CREATE DOMAIN PropertyName VARCHAR(32);

DROP DOMAIN PropertyExpr CASCADE;
CREATE DOMAIN PropertyExpr VARCHAR(128);

DROP DOMAIN Priority CASCADE;
CREATE DOMAIN Priority INTEGER
  CHECK(VALUE >= 0 and VALUE <= 5);

DROP DOMAIN QueueName CASCADE;
CREATE DOMAIN QueueName VARCHAR(64);

DROP DOMAIN OutcomeName CASCADE;
CREATE DOMAIN OutcomeName VARCHAR(64);

DROP DOMAIN PurposeName CASCADE;
CREATE DOMAIN PurposeName VARCHAR(64);

DROP DOMAIN TagType CASCADE;
CREATE DOMAIN TagType VARCHAR(32);

DROP DOMAIN TestCaseName CASCADE;
CREATE DOMAIN TestCaseName VARCHAR(32);

DROP DOMAIN ToolName CASCADE;
CREATE DOMAIN ToolName VARCHAR(32);

DROP DOMAIN MetricName CASCADE;
CREATE DOMAIN MetricName VARCHAR(32);

DROP DOMAIN TimeValue CASCADE;
-- Can we extend this?
CREATE DOMAIN TimeValue FLOAT;

DROP DOMAIN VersionString CASCADE;
CREATE DOMAIN VersionString VARCHAR(128);

DROP DOMAIN AuthorString CASCADE;
CREATE DOMAIN AuthorString VARCHAR(8);

/* ----------------------------------------------------------------------------
 * Platform and Language Tables
 * ----------------------------------------------------------------------------
 */

-- The platform table just discriminates the various compute platforms
DROP TABLE Platform CASCADE;
CREATE TABLE Platform (
   platform_id SERIAL  PRIMARY KEY,
   name  PlatformName  NOT NULL
);

-- INSERT INTO Platform(platform_id, name) values(1, 'Red');
-- INSERT INTO Platform(platform_id, name) values(2, 'Red Storm');

-- The language table discriminates the various languages used on the systems.
-- It is platform independent.
DROP TABLE Language CASCADE;
CREATE TABLE Language (
      name  LanguageName PRIMARY KEY
);

/* ----------------------------------------------------------------------------
 *  Contact Information
 * ----------------------------------------------------------------------------
 */

DROP TABLE Contact CASCADE;
CREATE TABLE Contact (
	contact_id SERIAL PRIMARY KEY,
	last_name  varchar(24),
	first_name varchar(16),
	nickname   varchar(16),
	organization  varchar(16),
	company	      varchar(16),
	phone	      PhoneNumber,
	fax	      PhoneNumber,
	mobile	      PhoneNumber,
	email         varchar(64)
);


DROP TABLE Vendor CASCADE;
CREATE TABLE Vendor (
	vendor_id	SERIAL PRIMARY KEY,
	name VARCHAR(32),
	poc_id  INTEGER REFERENCES Contact(contact_id)
);

--INSERT INTO Vendor(name) VALUES ('Cray');
--INSERT INTO Vendor(name) VALUES ('PGI');
--INSERT INTO Vendor(name) VALUES ('SuSe');
--INSERT INTO Vendor(name) VALUES ('SNL');

--- Descriptor table for run purposes
DROP TABLE Purpose CASCADE;
CREATE TABLE Purpose (
	purpose_id SERIAL PRIMARY KEY,
	name PurposeName  NOT NULL,
	description TEXT,
	UNIQUE(name)
);

-- DELETE FROM Purpose;
INSERT INTO Purpose( name) VALUES ('unknown');
INSERT INTO Purpose( name) VALUES ('debug');
INSERT INTO Purpose(name) VALUES ('planning');
INSERT INTO Purpose(name) VALUES ('production');
INSERT INTO Purpose(name) VALUES ('benchmark');
INSERT INTO Purpose(name) VALUES ('test-benchmark');
INSERT INTO Purpose(name) VALUES ('test-regression');

DROP TABLE BenchmarkState CASCADE;
CREATE TABLE BenchmarkState (
	benchmark_state_id INTEGER PRIMARY KEY,
	name     TypeName NOT NULL
);

-- State 0 is used in Benchmark.pm
-- State 1 is used in the TestCase and Benchmark Tables as the default
-- Set up the benchmark state table
-- Fixed benchmark_stats_id's are used here and are referred to by
-- the Benchmark table in the schema.
-- The inserts are here so that we can document a default value
-- in the Benchmark table
INSERT INTO BenchmarkState(benchmark_state_id, name) values(0,'Unknown');
INSERT INTO BenchmarkState(benchmark_state_id, name) values(1,'Proposed');
INSERT INTO BenchmarkState(benchmark_state_id, name) values(2,'Planned');
INSERT INTO BenchmarkState(benchmark_state_id, name) values(3,'Ready to Run');
INSERT INTO BenchmarkState(benchmark_state_id, name) values(4,'Scheduled');
INSERT INTO BenchmarkState(benchmark_state_id, name) values(5,'Complete');

DROP TABLE PackageType CASCADE;
CREATE TABLE PackageType (
	package_type_id INTEGER PRIMARY KEY,
	name varchar(32)  NOT NULL,
	UNIQUE(name)
);


--- Could really move to the status.xml table.
DELETE FROM PackageType;
INSERT INTO PackageType(package_type_id, name) VALUES (1,'Application');
INSERT INTO PackageType(package_type_id, name) VALUES (2,'Library');


DROP TABLE FileCategory CASCADE;
CREATE TABLE FileCategory (
	category_id SERIAL PRIMARY KEY,
	name TypeName  NOT NULL,
	UNIQUE(name)
);

-- DELETE FROM FileCategory;
INSERT INTO FileCategory(name) VALUES ('source');
INSERT INTO FileCategory(name) VALUES ('input');
INSERT INTO FileCategory(name) VALUES ('output');
INSERT INTO FileCategory(name) VALUES ('intermediate');

DROP TABLE FileType CASCADE;
CREATE TABLE FileType (
	type_id SERIAL PRIMARY KEY,
	name TypeName  NOT NULL,
	UNIQUE(name)
);

-- DELETE FROM FileType;
INSERT INTO FileType(name) VALUES ('Script');
INSERT INTO FileType(name) VALUES ('Source');
INSERT INTO FileType(name) VALUES ('Directory');
INSERT INTO FileType(name) VALUES ('Log');
INSERT INTO FileType(name) VALUES ('Data');
INSERT INTO FileType(name) VALUES ('Viz');
INSERT INTO FileType(name) VALUES ('Restart');
INSERT INTO FileType(name) VALUES ('Summary');

/* Output Directories Table */
DROP TABLE OutputDirectoryType CASCADE;
CREATE TABLE OutputDirectoryType (
	type_id SERIAL PRIMARY KEY,
	type_name TypeName  NOT NULL,
	UNIQUE(type_name)
);


-- DELETE FROM OutputDirectoryType;
INSERT INTO OutputDirectoryType(type_name) VALUES ('scalar');
INSERT INTO OutputDirectoryType(type_name) VALUES ('raid');
INSERT INTO OutputDirectoryType(type_name) VALUES ('viz');

DROP TABLE EnvironmentType CASCADE;
CREATE TABLE EnvironmentType (
	type_id SERIAL PRIMARY KEY,
	name varchar(8)  NOT NULL,
	UNIQUE(name)
);

-- DELETE FROM EnvironmentType;
-- These have hard-coded values in PgDAO/EnvironmentSetting.pm
INSERT INTO EnvironmentType(name) VALUES ('path');
INSERT INTO EnvironmentType(name) VALUES ('value');

/* ----------------------------------------------------------------------------
 * Compiler, Applicationn, and Compilation Information
 * ----------------------------------------------------------------------------
 */
DROP TABLE CompileTool CASCADE;
CREATE TABLE CompileTool (
   tool_id serial primary key,
   platform_id INTEGER REFERENCES Platform
           ON DELETE CASCADE,

   vendor_id INTEGER  REFERENCES Vendor
           ON DELETE CASCADE,
   name  ToolName,
   language LanguageName references  Language(name)  ON DELETE CASCADE,
   version VersionString,
   output_parser  ToolName
);



-- INSERT INTO PackageType(package_type_id, name) VALUES (1,'Application');
-- INSERT INTO PackageType(package_type_id, name) VALUES (2,'Library');

DROP TABLE Application CASCADE;
CREATE TABLE Application (
	app_id  SERIAL PRIMARY KEY,
	package_type_id INTEGER REFERENCES PackageType
	        ON DELETE CASCADE DEFAULT 1,
	name varchar(32),
	lab  varchar(4),
	description text,
--	64-bit clean?
	clean64  boolean,
--	Run on Janus? boolean,
--	Benchmark on Janus? boolean,
	license_info   varchar(32),
	security_classification varchar(32),
	status  text,
	primary_language LanguageName REFERENCES Language(name) ON DELETE CASCADE,
	completion_date DATE
);

DROP TABLE ApplicationPlanning CASCADE;
CREATE TABLE ApplicationPlanning (
  app_id INTEGER REFERENCES Application 
     ON DELETE CASCADE,
 platform_id INTEGER REFERENCES Platform
           ON DELETE CASCADE,

 version VersionString,
 ported_serial DATE,
 ported_parallel DATE,
 ported_serial_by_id INTEGER REFERENCES Contact
     ON DELETE SET NULL,
 ported_parallel_by_id INTEGER REFERENCES Contact
     ON DELETE SET NULL,
 needs_validation boolean,
 validated boolean,
 validated_by_id INTEGER REFERENCES Contact
     ON DELETE SET NULL,

 ready boolean DEFAULT false,
 UNIQUE(app_id,platform_id)
);

DROP TABLE AppBinary CASCADE;
CREATE TABLE AppBinary (
   appbinary_id SERIAL PRIMARY KEY,
   app_id INTEGER REFERENCES Application
         ON DELETE CASCADE,

   platform_id INTEGER REFERENCES Platform
           ON DELETE CASCADE,
   filepath FilePath,
   compilation_host HostName,
   compilation_date TIMESTAMP with TIME ZONE,
   compiled_by_id  INTEGER REFERENCES Contact(contact_id)
	ON DELETE SET NULL,
   size_info VARCHAR(256),
   md5sum    VARCHAR(40),
   byte_count INTEGER
);

--- need to capture the name, working directory, and extend the flags
DROP TABLE BuildInfo CASCADE;
CREATE TABLE BuildInfo (
   id SERIAL     PRIMARY KEY,	
   appbinary_id INTEGER REFERENCES AppBinary
	ON DELETE CASCADE,
   tool_id       INTEGER REFERENCES CompileTool
		ON DELETE CASCADE,
   raw_flags	  CompilerFlags,
   expanded_flags CompilerFlags,
   filename  	 FileName,
   directory	 FilePath,
   ordinal	 INTEGER
);


/* ----------------------------------------------------------------------------
 * Contact Information
 * ----------------------------------------------------------------------------
 */

DROP TABLE Role CASCADE;
CREATE TABLE Role (
	role_id SERIAL PRIMARY KEY,
	role varchar(32)  NOT NULL,
	UNIQUE(role)
);

-- INSERT INTO Role(role) VALUES ('Analyst');
-- INSERT INTO Role(role) VALUES ('Application POC');
-- INSERT INTO Role(role) VALUES ('SNL 7x POC');
-- INSERT INTO Role(role) VALUES ('Cray POC');
-- INSERT INTO Role(role) VALUES ('SNL Witness');
-- INSERT INTO Role(role) VALUES ('Cray Witness');
-- INSERT INTO Role(role) VALUES ('Red Porter');
-- INSERT INTO Role(role) VALUES ('Red Storm Porter');
-- INSERT INTO Role(role) VALUES ('SNL Runner');
-- INSERT INTO Role(role) VALUES ('Cray Runner');

DROP TABLE AppContactMap CASCADE;
CREATE TABLE AppContactMap (
	app_id  INTEGER REFERENCES Application
	   ON DELETE CASCADE,
	benchmark_id  INTEGER REFERENCES Benchmark
	   ON DELETE CASCADE,
	contact_id INTEGER REFERENCES Contact
	   ON DELETE CASCADE,
	role_id INTEGER REFERENCES Role
	   ON DELETE CASCADE,
	notes TEXT,
	UNIQUE(app_id,role_id, contact_id)
);


DROP TABLE Benchmark CASCADE;
CREATE TABLE Benchmark (
     benchmark_id SERIAL PRIMARY KEY, 
     title VARCHAR(32),
     app_id  INTEGER REFERENCES Application
        ON DELETE CASCADE,
     description  text,
     nickname  BenchmarkName,
     tag TagType,

     -- default states to 'Proposed'
     benchmark_state_id INTEGER REFERENCES BenchmarkState DEFAULT 1,

     app_config TEXT,

     priority  INTEGER default 0,

     -- Do these really belong here?
     -- or do they belong in the testcase?
     root_directory  FilePath,
     logname  FileName,
     logpath  FilePath,
     UNIQUE(nickname)
);

DROP TABLE TestType CASCADE;
CREATE TABLE TestType (
	test_type_id SERIAL PRIMARY KEY,
	name varchar(32)  NOT NULL,
	UNIQUE(name)
);

-- INSERT INTO TestType(name) VALUES ('Standard');
-- INSERT INTO TestType(name) VALUES ('Stretch');
-- INSERT INTO TestType(name) VALUES ('Jumbo');
-- INSERT INTO TestType(name) VALUES ('Scaling');
-- INSERT INTO TestType(name) VALUES ('Other');

DROP TABLE TestCase CASCADE;
CREATE TABLE TestCase (
    testcase_id SERIAL PRIMARY KEY,
    name        TestCaseName,

    description TEXT,
    benchmark_id INTEGER REFERENCES Benchmark  ON DELETE CASCADE,
    benchmark_state_id INTEGER REFERENCES BenchmarkState DEFAULT 1,
   -- we only use this table for the path to the binary, but
   -- having this entry makes some coding easier.

   -- Runs will look for a new binary with the correct md5sum.	
   appbinary_id INTEGER REFERENCES AppBinary
		ON DELETE CASCADE,

    platform_id INTEGER REFERENCES Platform ON DELETE CASCADE,

    procs_per_node INTEGER DEFAULT 1,
    nodes_required INTEGER,
    size INTEGER,
    test_type_id INTEGER REFERENCES TestType
     ON DELETE SET NULL,
    prepared_by_id  INTEGER REFERENCES Contact(contact_id)
     ON DELETE SET NULL,
    validated_by_id  INTEGER REFERENCES Contact(contact_id)
     ON DELETE SET NULL,

    est_walltime TimeValue,  -- hours?
    red_proc_mode ModeName,
    working_directory  FilePath,
    stdout  FileName,
    stderr  FileName,
    primary_metric_name MetricName
);


DROP TABLE BenchmarkPlanning CASCADE;
CREATE TABLE BenchmarkPlanning  ( 
    benchmark_plan_id SERIAL PRIMARY KEY,
    benchmark_id INTEGER REFERENCES Benchmark  ON DELETE CASCADE,
    platform_id INTEGER REFERENCES Platform  ON DELETE CASCADE,
    source_code_ready DATE,
    compile_scripts_available   DATE,
    compile_scripts_tested  DATE
);

DROP TABLE TestCasePlanning CASCADE;
CREATE TABLE TestCasePlanning  ( 
    testcase_plan_id SERIAL PRIMARY KEY,
    testcase_id INTEGER REFERENCES TestCase  ON DELETE CASCADE,
    data_set_on_hand  DATE,
    inputs_prepared  DATE,
    sample_scripts_available  DATE,
    rst_scripts_written  DATE,
    rst_scripts_tested   DATE,
    preliminary_runs_scheduled  DATE,	 
    preliminary_runs_complete   DATE,
    final_runs_scheduled   DATE,
    final_runs_complete   DATE
);

/*  
 * In preparing a benchmark, we do a number of smaller studies
 * These could be TestCases in their own right, but it seems nicer
 * to tag them on as a separate element in the planning process
 */
DROP TABLE BenchmarkPlanningStudy CASCADE;
CREATE TABLE BenchmarkPlanningStudy  ( 
    study_id SERIAL PRIMARY KEY,
    benchmark_plan_id INTEGER REFERENCES BenchmarkPlanning  ON DELETE CASCADE,
    purpose_id INTEGER REFERENCES Purpose  ON DELETE CASCADE,
    benchmark_state_id INTEGER REFERENCES BenchmarkState  ON DELETE CASCADE,
    size INTEGER,
    date   DATE,
    mode  ModeName,
    description TEXT
);

DROP TABLE Note CASCADE;
CREATE TABLE Note  ( 
    note_id SERIAL PRIMARY KEY,
    study_id INTEGER REFERENCES BenchmarkPlanningStudy ON DELETE CASCADE,
    author_id INTEGER REFERENCES Contact(contact_id),
    date   DATE,
    text  TEXT
);
  

/* ----------------------------------------------------------------------------
 * I've added SystemConfigurations to the database
 * mostly so that we can add the kind of tracking information
 * that Noe wants concerning the growth of Red Storm.
 * 
 * On Red, the configurations are known and stable.
 * ----------------------------------------------------------------------------
 */
DROP TABLE Machine CASCADE;
CREATE TABLE Machine (
	machine_id SERIAL PRIMARY KEY,
        platform_id INTEGER REFERENCES Platform,
	machine_name VARCHAR(256),
        classified  boolean  default false
);


DROP TABLE SystemConfiguration CASCADE;
CREATE TABLE SystemConfiguration (
  system_config_id SERIAL PRIMARY KEY,
  machine_id INTEGER REFERENCES Machine,

  compute_nodes_available INTEGER,
  procs_available INTEGER,

  os VARCHAR(1024),
  created TIMESTAMP WITH TIME ZONE,
  description TEXT
);
	
--- Descriptor table for run outcomes
DROP TABLE Outcome CASCADE;
CREATE TABLE Outcome (
	outcome_id INTEGER PRIMARY KEY,
	name OutcomeName  NOT NULL,
	UNIQUE(name)
);

--- DO NOT CHANGE THE INDEX VALUES OF THIS TABLE!
INSERT INTO Outcome(outcome_id, name) VALUES (1,'Not scheduled');
INSERT INTO Outcome(outcome_id, name) VALUES (2,'Scheduled');
INSERT INTO Outcome(outcome_id, name) VALUES (3,'Initiated');
INSERT INTO Outcome(outcome_id, name) VALUES (4,'Failed');
INSERT INTO Outcome(outcome_id, name) VALUES (5,'Completed');

--- DO NOT CHANGE THE INDEX VALUES OF THIS TABLE!
-- setup failed
-- compile failed
-- install failed
-- cleanup failed
-- exec error
-- preprocess failed
-- postprocess failed

DROP TABLE Grade CASCADE;
CREATE TABLE Grade (
   grade_id INTEGER PRIMARY KEY,
   name     GradeName,
   mnemonic CHAR(4),
   value float,
   description  TEXT
);

--DELETE FROM Grade;
INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(0, 'unknown', 'U', 0.0, 'No grade assigned');

INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(1, 'fail', 'F', 1.0, 'Test failed');

INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(2, 'dubious', 'D', 2.0, 'Dubious outcome --- review results');

INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(3, 'marginal', 'M', 3.0, 'Marginal outcome --- review results, but probably ok');

INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(4, 'pass', 'P', 4.0, 'Test passed');

INSERT INTO Grade(grade_id, name, mnemonic, value, description)
	VALUES(5, 'exceptional', 'E', 5.0, 'Test passed, but with exceptional results --- better check them');

-- A run is SCHEDULED if scheduled_date != NULL
-- A run is COMPLETED if walltime != NULL and binary_uid != NULL
-- We should require that if a Run has a Wall time, then it has an appbinary_id
-- A run is USABLE if COMPLETED and data_valid is TRUE

DROP TABLE Run CASCADE;
CREATE TABLE Run (
   run_id SERIAL PRIMARY KEY,
   outcome_id INTEGER REFERENCES Outcome
	      ON DELETE CASCADE,

   data_valid BOOLEAN DEFAULT false,

   purpose_id INTEGER REFERENCES Purpose
          ON DELETE CASCADE,

   grade_id INTEGER REFERENCES Grade
          ON DELETE CASCADE,

   validation_id INTEGER REFERENCES Grade(grade_id)
	          ON DELETE CASCADE,

   testcase_id INTEGER REFERENCES TestCase
          ON DELETE CASCADE,

   appbinary_id   INTEGER REFERENCES AppBinary
	          ON DELETE SET NULL, --- Bob?

   job_time  TimeValue,
   compile_time TimeValue,
   preprocess_time TimeValue,
   postprocess_time TimeValue,
   validation_time TimeValue,
   grade_time TimeValue,
   setup_time TimeValue,
   cleanup_time TimeValue,
   installation_time TimeValue,
   finally_time TimeValue,

   scheduled_date TIMESTAMP WITH TIME ZONE,  --- date that run is scheduled
   time_start TIMESTAMP WITH TIME ZONE,
   time_end   TIMESTAMP WITH TIME ZONE,

   runner_id INTEGER REFERENCES Contact(contact_id)
          ON DELETE SET NULL, --- Bob?
   runner_sig_time   TIMESTAMP WITH TIME ZONE,
   witness_id INTEGER REFERENCES Contact(contact_id)
         ON DELETE SET NULL, --- Bob?
   witness_sig_time   TIMESTAMP WITH TIME ZONE,
   system_config_id INTEGER REFERENCES SystemConfiguration,

   tag  TagType,

   note TEXT
);


/* ----------------------------------------------------------------------------
 * 
 * Commands
 *
 * Commands have a type, a pointer to one of an Application, Benchmark, or
 *  TestCase, and the actual command/argument values.
 *  I guess that we could actually add the input, output, and stderr files
 *  without much loss of generality!
 * 
 * The basic idea is that if an Command is associated with an Application,
 * then app_id will be set. It should be an error if more than one of the
 * testcase_id, app_id, and benchmark_id is set!
 * 
 * constraint: ((app_id is not null) and (testcase_id is null) and (benchmark_id is null)) OR
 *	       ((app_id is null) and (testcase_id is not null) and (benchmark_id is null)) OR
 *  	       ((app_id is null) and (testcase_id is null) and (benchmark_id is not null) 
 *
 * 
 * ----------------------------------------------------------------------------
 */

/* Just a static name table! */
DROP TABLE CommandType CASCADE;
CREATE TABLE CommandType (
	type_id SERIAL PRIMARY KEY,
	name TypeName  NOT NULL,
	UNIQUE(name)
);

-- For TestcAses
DELETE FROM CommandType;
INSERT INTO CommandType(name) VALUES ('setup');
INSERT INTO CommandType(name) VALUES ('compile');
INSERT INTO CommandType(name) VALUES ('installation');
INSERT INTO CommandType(name) VALUES ('cleanup');

-- For Runs
INSERT INTO CommandType(name) VALUES ('postprocess');
INSERT INTO CommandType(name) VALUES ('preprocess');
INSERT INTO CommandType(name) VALUES ('runjob');
INSERT INTO CommandType(name) VALUES ('validate');
INSERT INTO CommandType(name) VALUES ('score');
INSERT INTO CommandType(name) VALUES ('finally');

/* The real action table. */
DROP TABLE Command CASCADE;
CREATE TABLE Command (
  command_id SERIAL PRIMARY KEY,

  type_id INTEGER REFERENCES CommandType
	   ON DELETE SET NULL,

  testcase_id   INTEGER REFERENCES TestCase
          ON DELETE CASCADE,

  ordinal INTEGER,

  description TEXT,

  failure_ok BOOLEAN DEFAULT 'false',

  executable CommandString,
  arguments CommandArgs,

  working_directory  FilePath,
  install_directory  FilePath,

  stdin   FileName,
  stdout  FileName,
  stderr  FileName,
  outputfile  FileName,
  dispatch_name DispatchName,
  dispatch_args CommandArgs,
  dispatch_mode ModeName,
  dispatch_procs INTEGER,
  dispatch_max_time VARCHAR(12),
  dispatch_job_queue QueueName
);


/* ----------------------------------------------------------------------------
 * --Not clear to me that we need to embed files and file types in to the
 * --SQL database. This may all be overkill!
 * ----------------------------------------------------------------------------
 */
/* ----------------------------------------------------------------------------
 * -- I don't *really* like the following solution, but the alternatives are worse.
 * -- Pretty much, any or all of the _id fields can be set.
 * -- Files rows cannot be shared, except among an application, benchmark, testcase, or run.
 * -- Clearly, you can share a file by entering it more than once.
 * ----------------------------------------------------------------------------
 */

DROP TABLE File CASCADE;
CREATE TABLE File (
  file_id SERIAL PRIMARY KEY,
  type_id INTEGER REFERENCES FileType
	   ON DELETE SET NULL,
  category_id INTEGER REFERENCES FileCategory(category_id)
	  	 ON DELETE SET NULL,

  platform_id INTEGER REFERENCES Platform
           ON DELETE CASCADE,

  app_id   INTEGER REFERENCES Application
          ON DELETE CASCADE,

  benchmark_id INTEGER REFERENCES Benchmark
         ON DELETE CASCADE,

  testcase_id   INTEGER REFERENCES TestCase
          ON DELETE CASCADE,
  run_id   INTEGER REFERENCES Run
          ON DELETE CASCADE,

  name FileName  NOT NULL,
  path FilePath  NOT NULL
);


-- This may supersede the File table!
DROP TABLE OutputDirectory CASCADE;
CREATE TABLE OutputDirectory (
  output_directory_id SERIAL PRIMARY KEY,
  type_id INTEGER REFERENCES OutputDirectoryType(type_id) 
         ON DELETE CASCADE,
  testcase_id   INTEGER REFERENCES TestCase
          ON DELETE CASCADE,
  directory FilePath,
  number INTEGER
);



/* The Environment Table */
-- PATH values are represented with a type == "_pathvar_"
DROP TABLE Environment CASCADE;
CREATE TABLE Environment (
  env_id SERIAL PRIMARY KEY,
  env_type INTEGER REFERENCES EnvironmentType,

  testcase_id   INTEGER REFERENCES TestCase
          ON DELETE CASCADE,

  name  FileName,
  value FilePath,
  ordinal INTEGER
);

/* The Property table */
DROP TABLE Property CASCADE;
CREATE TABLE Property (
  property_id SERIAL PRIMARY KEY,

  testcase_id   INTEGER REFERENCES TestCase
          ON DELETE CASCADE,

  property_name PropertyName,
  match_type PropertyExpr,
  pattern PropertyExpr,
  filename FileName,
  filepath FilePath
);

/* The Property table */
DROP TABLE PropertyMatch CASCADE;
CREATE TABLE PropertyMatch (
  property_match_id SERIAL PRIMARY KEY,
  property_id    INTEGER REFERENCES Property
          ON DELETE CASCADE,

  run_id   INTEGER REFERENCES Run
          ON DELETE CASCADE,
  matched  boolean,
  value     VARCHAR(128)
);


/* Values of Environment Variables during a Run */
DROP TABLE EnvironmentValue CASCADE;
CREATE TABLE EnvironmentValue (
  env_id SERIAL PRIMARY KEY,
  run_id   INTEGER REFERENCES Run
          ON DELETE CASCADE,

  name  FileName,
  value FilePath
);

/* ----------------------------------------------------------------------------
 * VIEWS
 * ----------------------------------------------------------------------------
 */

-- RunAverage rolls up the Runs for a particular test case
DROP VIEW RunAverage;
CREATE VIEW RunAverage As (select Run.testcase_id,
				 avg(job_time) as average,
                                 count(job_time) FROM Run
		                                 WHERE data_valid='t'
			                         GROUP by testcase_id);

-- RedResults - TestCase and result data for Red
DROP VIEW RedResults;
CREATE VIEW RedResults AS
	(SELECT benchmark_id, Platform.platform_id as platform_id, size, average, count
		From RunAverage, TestCase, Platform
                WHERE Runaverage.testcase_id=Testcase.testcase_id AND
			TestCase.platform_id = Platform.platform_id and Platform.name = 'Red'); 

-- RedStormResults - TestCase and result data for Red Storm
DROP VIEW RedStormResults;
CREATE VIEW RedStormResults AS
	(SELECT benchmark_id, Platform.platform_id as platform_id, size, average, count
		From RunAverage, TestCase, Platform 
	        WHERE Runaverage.testcase_id=Testcase.testcase_id AND
			Testcase.platform_id=Platform.platform_id and Platform.name='Red Storm');

-- Cross-product of results for same testcase size, benchmark, and platform
DROP VIEW Speedup;
CREATE VIEW SPEEDUP As 
	(SELECT T1.benchmark_id,
		T1.size,
		T1.average as Red,
		T2.average as RedStorm,
               (T1.average/T2.average) as Speedup
	              FROM RedResults as T1,
		           RedStormResults as T2
		      WHERE T1.benchmark_id = T2.benchmark_id and T1.size = T2.size
		      ORDER BY T1.benchmark_id, T1.size);

 --- Compute min/max/average speedup for a given benchmark, using the benchmark table
DROP VIEW BenchmarkSpeedup;
CREATE VIEW BenchmarkSpeedup AS 
	(SELECT benchmark_id,
	        min(speedup),
	        max(speedup),
	        avg(speedup) 
	             FROM Speedup
		      GROUP BY benchmark_id);
	
-- Show Runs
DROP VIEW MalformedRun;
CREATE VIEW MalformedRun AS 
	(SELECT run_id, testcase_id FROM RUN WHERE appbinary_id = NULL AND (data_valid = false));


--- Views for status checking
DROP VIEW RunsProjected CASCADE;
CREATE VIEW  RunsProjected AS
(
 SELECT testcase.benchmark_id, run.testcase_id, testcase.size, count(run.run_id) AS scheduled
  FROM Run, Testcase
  WHERE (run.scheduled_date IS NOT NULL OR run.data_valid = false) AND run.testcase_id = testcase.testcase_id
  GROUP BY run.testcase_id, testcase.size, testcase.benchmark_id)
;

DROP VIEW RunsComplete CASCADE;
CREATE VIEW  RunsComplete AS
(
 SELECT testcase.benchmark_id, run.testcase_id, testcase.size, count(run.job_time) AS completed
  FROM run, testcase
  WHERE run.data_valid = true AND run.testcase_id = testcase.testcase_id
  GROUP BY run.testcase_id, testcase.size, testcase.benchmark_id
)
;

DROP VIEW TestcaseStatus CASCADE;
CREATE VIEW TestcaseStatus AS
	(SELECT RunsProjected.testcase_id, scheduled, completed, completed/cast(scheduled as float) as status from RunsProjected,RunsComplete
	        where RunsProjected.testcase_id=RunsComplete.testcase_id);

DROP VIEW RunStatus CASCADE;
CREATE VIEW RunStatus AS
(
SELECT benchmark_id, platform_id, size, count(run_id) as scheduled,
 count(job_time) as completed,  count(job_time)/cast(count(run_id) as float) as status  from Run,TestCase where 
 ((job_time IS NULL AND data_valid='f') 	OR
 (job_time is NOT NULL AND data_valid='t'))  AND
 Run.testcase_id=TestCase.testcase_id
 group by Run.testcase_id, size, benchmark_id, platform_id
 order by benchmark_id, Run.testcase_id, platform_id, size
);
	

DROP VIEW BenchmarkStatus CASCADE;
CREATE VIEW BenchmarkStatus AS
(SELECT benchmark_id, platform_id, sum(scheduled) as scheduled,
 sum(completed) as completed,
 sum(completed)/cast(sum(scheduled) as float) as status from RunStatus
 GROUP BY benchmark_id, platform_id
 ORDER BY benchmark_id, platform_id
);



