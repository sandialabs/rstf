#!/usr/bin/perl -w
###############################################################################
#  copyright {
# Copyright (c) 2004 Sandia National Laboratories
# } 
#  
# 
# cache_tables.pl
# 
# Created by: Robert A. Ballance		Wed Sep 29 09:21:07 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/cache_tables.pl,v $
# $Revision: 1.1 $
# $Name:  $
# $State: Exp $
# 
# Cache database tables into PERL structures for Unconnected operations
# 
###############################################################################

use Data::Dumper;
use RSTF::DB::DAOFactory;
use File::Path;
RSTF::DB::DAOFactory::init();

use strict;

my $dir = $ARGV[0];
die "Must specify output directory" unless ($dir);
mkpath($dir);


my $configfile = $ARGV[1];
open(INPUT, "<$configfile")  or die "Unable to open $configfile";

while (<INPUT>) {
    next if (/^\s*\#/);
    next if (/^\s*$/);
    chomp;
    my ($obj_class, $name_field) = split(/\s+/);
    my @classpath = split('::', $obj_class);
    my $class = pop @classpath;

    eval "use $obj_class";
    if ($@) {
	die $@;
    }
    
    my $pre;
    eval {
	$pre = new $obj_class();
    };
    if ($@) {
	die $@;
    }
    
    my %objects;
    my $objs = $pre->fetch_all();
    foreach my $obj (@$objs) {
	$obj = bless($obj, $obj_class);
	my $name = lc($obj->$name_field);
	$obj->script_compile();
	$objects{$name} = $obj;
    }

    my $outfile = "$dir/$class.pm";
    open(OUTFILE, ">$outfile") or die "Unable to open $outfile";

    print OUTFILE  << "EOF";
package RSTF::DB::Cache::$class;
use $obj_class;
use RSTF::DB::XMLWriter;
my 
EOF
    ;
$Data::Dumper::Purity = 1;
$Data::Dumper::DeepCopy = 1;
print OUTFILE Data::Dumper->Dump([\%objects], ['objects']);

print OUTFILE << 'EOF';

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

EOF
    ;

print OUTFILE << "EOF";
    my \$obj = new $obj_class($name_field => \$name);
    \$objects{\$name} = \$obj;
    return \$obj;
}

1;
EOF
    ;

close OUTFILE;
print "Wrote $outfile\n";
}
close INPUT;
