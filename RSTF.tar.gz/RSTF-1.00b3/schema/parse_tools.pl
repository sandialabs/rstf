#!/usr/bin/perl -w
###############################################################################
# copyright {
# Copyright (c) 2004 Sandia National Laboratories
# } 
#  
# 
# parse_tools.pl
# 
# Created by: Robert A. Ballance		Wed Sep 29 09:17:37 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/parse_tools.pl,v $
# $Revision: 1.1 $
# $Name:  $
# $State: Exp $
# 
# Read in a file structured according to contact.dtd  and add the contacts to
# the database.
###############################################################################

use strict;
use warnings;

use RSTF::Compile::XMLParser;
use XML::Twig;

use RSTF::Configuration;
use RSTF::DB::CompileTool;
use RSTF::DB::Platform;
use RSTF::DB::Vendor;

;use RSTF::DB::Language;

use RSTF::DB::DAOFactory;
use RSTF::DB::DBConnect;

use vars qw(@ISA);
@ISA = qw(RSTF::Compile::XMLParser);

my $config = new RSTF::Configuration;
$config->getopt();

if ($config->help()) {
    show_help();
    exit(1);
}

trace_init($config->verbose);

unless ($config->database_connect()) {
    die "It does not make sense to run parse_contacts without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();

my $contact;

sub vendor_handler {
    my ($twig, $field) = @_;
    
    my $name = $field->trimmed_text();
    print "Inserting vendor $name\n";
    my $v = new RSTF::DB::Vendor(name=>$name);
    $v->insert();

}

sub language_handler {
    my ($twig, $field) = @_;
    
    my $name = $field->trimmed_text();
    print "Inserting language $name\n";
    my $v = new RSTF::DB::Language(name=>$name);
    $v->insert();

}

sub platform_handler {
    my ($twig, $field) = @_;
    
    my $name = $field->trimmed_text();
    print "Inserting platform $name\n";
    my $v = new RSTF::DB::Platform(name=>$name);
    $v->insert();

}

sub lookup_platform {
    my $name = shift;
    print "Looking for platform $name\n";
    if ($name) {
	return RSTF::DB::Platform->find_by_name($name);
    }
    return undef;
}

sub lookup_vendor {
    my $name = shift;
    if ($name) {
	return RSTF::DB::Vendor->find_by_name($name);
    }
    return undef;
}

sub lookup_language {
    my $name = shift;
    if ($name) {
	return RSTF::DB::Language->find_by_name($name);
    }
    return undef;
}


sub compiletool_handler {
    my ($twig, $field) = @_;
    
    my $name = safe_get_text($field, 'name');
    my $parser = safe_get_text($field, 'parser');

    my $platform = lookup_platform(safe_get_attr($field, 'platform'));
    my $vendor = lookup_vendor(safe_get_attr($field, 'vendor'));
    my $language = lookup_language(safe_get_attr($field, 'language'));
    
    die "Malformed compiletool" unless ($language && $vendor && $name);

    print "Inserting compile tool $name\n";
    print "Platform id is " . $platform->platform_id . "\n";
    my $v = new RSTF::DB::CompileTool(name=>$name,
				     vendor_id => $vendor->vendor_id,
				     platform_id => $platform->platform_id,
				     language=>$language->name,
				     output_parser=>$parser);
    $v->insert();

}

# kill all for now
my $db = RSTF::DB::DAOFactory::get_connection();
$db->execute('DELETE FROM Vendor');
$db->execute('DELETE FROM Platform');
$db->execute('DELETE FROM Language');
$db->execute('DELETE FROM CompileTool');
foreach my $filename (@ARGV) {

    unless (-e $filename && -r $filename) {
	die "A Filename must be specified";
    }
    my $twig;
    eval {
	$twig = new XML::Twig(
			      TwigHandlers => { 
				  vendor => \&vendor_handler,
				  language => \&language_handler,
				  platform => \&platform_handler,
				  compiletool => \&compiletool_handler,
			      }     );
    };
    if ($@) {
	die $@;
    }
    my $ok = 0;
    eval {
	print "Processing $filename\n";
	$ok = $twig->parsefile($filename);
    };
    if ($@) {
	die $@;
    }
    $twig->purge();
}


