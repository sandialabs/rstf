#!/usr/bin/perl -w
###############################################################################
# copyright {
# Copyright (c) 2004 Sandia National Laboratories
# } 
#  
# 
# parse_status.pl
# 
# Created by: Robert A. Ballance		Wed Sep 29 09:19:30 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/schema/parse_status.pl,v $
# $Revision: 1.1 $
# $Name:  $
# $State: Exp $
# 
# Read a file structured according to status.dtd, and place the info in the database.
###############################################################################

use strict;
use warnings;

use RSTF::Compile::XMLParser;
use XML::Twig;

use RSTF::Configuration;
use RSTF::DB::Application;
use RSTF::DB::BenchmarkState;
use RSTF::DB::DAOFactory;
use RSTF::DB::TestCase;
use RSTF::DB::Contact;
use RSTF::DB::Role;
use RSTF::DB::Language;
use RSTF::DB::PackageType;
use RSTF::DB::AppContactMap;

use vars qw(@ISA);
@ISA = qw(RSTF::Compile::XMLParser);

my $config = new RSTF::Configuration(['clear!']);
$config->getopt();

if ($config->help()) {
    show_help();
    exit(1);
}

trace_init($config->verbose);

unless ($config->database_connect()) {
    die "It does not make sense to run parse_benchmarks without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();

my $application;
my $platform;
my @ports;

sub get_field_attr {
    my $field = shift;
    my $childname = shift;
    my $attr_name = shift;
    my $child = $field->first_child($childname);
    if ($child) {
	return safe_get_attr($child, $attr_name);
    }
    return undef;
}

sub lookup_contact {
    my $email_addr = shift;
    if ($email_addr && $email_addr =~ /.+@.+/) {
	unless ($email_addr eq 'unknown@sandia.gov') {
	    return RSTF::DB::Contact->find_by_name($email_addr);
	}
    }
    return undef;
}
       
sub port_handler {
    my ($twig, $field) = @_;
    trace_enter('port');
    my $type = safe_get_attr($field, 'type');
    my $date = safe_get_text($field, 'date');
    if ($date =~ /^\s*$/) {
	$date = undef;
    }
    my $ported_by = get_field_attr($field, 'ported_by', 'email');

    my $contact = lookup_contact($ported_by);
    
    push @ports, {
	type => $type,
	date => $date,
	ported_by => $contact };

   trace_exit('port');
}

sub appstatus_handler {
    my ($twig, $field) = @_;
    trace_enter('appstatus');
    my $platform_name = safe_get_attr($field, 'platform');
    my $platform = RSTF::DB::Platform->find_by_name($platform_name);
    die "Platform $platform_name not found" unless ($platform);

    my $status = $application->planning_status($platform);
    
    my $version = safe_get_text($field, 'version');
    my $needs_validation = get_field_attr($field, 'needs_validation', 'status');
    my $validated = get_field_attr($field, 'validated', 'status');
    my $validated_by_email  = get_field_attr($field, 'validated_by', 'email');
    my $validated_by = lookup_contact($validated_by_email);
    my $ready  = get_field_attr($field, 'ready', 'status');

    $status->ready($ready);
    $status->version($version);
    $status->validated($validated);
    $status->validated_by_id($validated_by ? $validated_by->contact_id : undef);
    $status->needs_validation($needs_validation);
    foreach my $port (@ports) {
	if ($port->{type} eq 'serial') {
	    $status->ported_serial($port->{date});
	    $status->ported_serial_by_id($port->{ported_by} ? $port->{ported_by}->contact_id : undef);
	}
	if ($port->{type} eq 'parallel') {
	    $status->ported_parallel($port->{date});
	    $status->ported_parallel_by_id($port->{ported_by} ? $port->{ported_by}->contact_id : undef);
	}
    }
    $status->update();
    trace_exit('appstatus');
}

sub start_application {
    my ($twig, $field) = @_;
    trace_enter('start_application');
    my $app_name = safe_get_attr($field, 'name');
    my $type_name = safe_get_attr($field, 'type');
    $application = RSTF::DB::Application->find_by_name($app_name);
    unless ($application) {
	my $pkg_type = RSTF::DB::PackageType->find_by_name($type_name);
	die "Unable to find $type_name" unless($pkg_type);
	$application = RSTF::DB::Application->new(name => $app_name,
						 package_type_id=>$pkg_type->package_type_id);
	print "INSERTING APPLICATION $app_name\n";
	$application = $application->insert();
    }
	
    die "Application $app_name not found" unless ($application);
    my $db = RSTF::DB::DAOFactory::get_connection();
    my $id = $application->app_id();
    print "Flushing assignments for $app_name\n";
    $db->execute("DELETE FROM AppContactMap where app_id=$id");

    trace_exit('start_application');
}

sub application_handler {
    my ($twig, $field) = @_;

    if ($application) {
	my $name = safe_get_attr($field, 'name');
	die "Application mismatch on $name and " . $application->name unless ($name && $name eq $application->name);
	my $lab = safe_get_text($field, 'lab');
	my $language= safe_get_text($field, 'language');
	$application->lab($lab);
	$application->primary_language($language);
	$application->update();
    } else {
	die "No application defined";
    }
}

sub start_appstatus {
    my ($twig, $field) = @_;
    trace_enter('start_appstatus');
    @ports = ();
    trace_exit('start_appstatus');
}

sub assignment_handler {
    my ($twig, $field) = @_;
    my $contact_email = safe_get_attr($field, 'contact');
    my $rolename = safe_get_attr($field, 'role');

    my $contact = lookup_contact($contact_email);
    die "Unable to find contact $contact_email" unless($contact);

    my $role = RSTF::DB::Role->find_by_name($rolename);
    die "Unable to find Role $rolename" unless($role);
    my $assignment = new RSTF::DB::AppContactMap(
					 app_id=>$application->app_id,
					 contact_id=>$contact->contact_id,
					 role_id=>$role->role_id);

#    printf "Adding assignment of %s as %s to %s", $contact->full_name, $role->role, $application->name;
    $assignment->insert();
}


foreach my $filename (@ARGV) {
    unless (-e $filename && -r $filename) {
	die "A Filename must be specified";
    }
    my $twig;
    eval {
	$twig = new XML::Twig(
			      TwigHandlers => { 
				  appstatus => \&appstatus_handler,
				  port  => \&port_handler,
				  assignment => \&assignment_handler,
				  application => \&application_handler,
			      },
			      start_tag_handlers => {
				  application => \&start_application,
				  appstatus  => \&start_appstatus,
			      }
			      );
    };
    if ($@) {
	die $@;
    }
    my $ok = 0;
    eval {
	print "Processing $filename\n";
	$ok = $twig->parsefile($filename);
    };
    if ($@) {
	die $@;
    }
    $twig->purge();
}


