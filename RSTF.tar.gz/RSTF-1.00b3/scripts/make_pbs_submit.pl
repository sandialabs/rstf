#!/usr/bin/perl -w
use strict;

use Getopt::Long;
use RSTF::Configuration;
use RSTF::DB::Application;
use RSTF::DB::TestCase;
use RSTF::Exec::ParBlock;


my $config = new RSTF::Configuration(['queue=s', 'walltime=s', 'size=s' ]);
$config->getopt();

my $basename  = $ARGV[0];

die "No command specified" unless (defined($basename));

my $exe = sprintf("%s.pl", $basename);
die "Command file $exe not present" unless(-e $exe);

shift @ARGV;
my $args = join(' ', @ARGV);

my $run_script = sprintf("%s.sh", $basename);
my $pbs_script = sprintf("%s.pbs", $basename);
my $p5lib = $ENV{PERL5LIB};
my $path = $ENV{PATH};
my $size = $config->size;
my $queue = $config->queue;
my $walltime = $config->walltime;

open (SCRIPT, ">$run_script") or die "Unable to create $run_script \n";
print SCRIPT << "EOF"
#!/bin/sh
#
cd \$PBS_WORKDIR
PATH=$path
PERL5LIB=$p5lib

rst run $exe --interactive $args 

#
# standard footer
#
exit 0
EOF
;

close(SCRIPT);


open (SCRIPT, ">$pbs_script") or die "Unable to create $pbs_script \n";
print SCRIPT << "EOF"
#!/bin/sh
# ==== Shell Script ===
qsub -lP $size -lT $walltime -q $queue $run_script
EOF
;
close(SCRIPT);

