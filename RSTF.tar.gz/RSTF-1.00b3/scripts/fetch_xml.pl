#!/usr/bin/perl  -w
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# fetch_xml.pl
# 
# Created by: Robert A. Ballance		Fri Apr 16 10:13:12 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/fetch_xml.pl,v $
# $Revision: 1.1 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

# - To create a script, we can use the following inputs
# 	< TestcaseID >
# 	<Benchmark, Platform, Size>
#         <RunID>
use strict;
use RSTF::Configuration;

use RSTF::DB::DAOFactory;

use RSTF::Exec;
use RSTF::Compile::ClassFactory;

my $config = new RSTF::Configuration(['benchmark_id=s','testcase_id=s', 'platform=s','benchmark=s', 'run_id=s', 'size=s']);
$config->getopt();


if ($config->help()) {
    show_help();
    exit(1);
}

unless ($config->database_connect()) {
    die "It does not make sense to run fetch_xml without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();

unless (RSTF::DB::DAOFactory::is_connected()) {
    die "Connection to database failed!\n";
}

my $benchmark;
if ($config->testcase_id) {
    $benchmark = create_from_testcase_id($config->testcase_id);
} elsif ($config->run_id) {
    $benchmark = create_from_run_id($config->run_id);
} else {
    $benchmark = create_from_spec($config->benchmark_id, $config->benchmark, $config->platform, $config->size);
}


# End of script

sub show_help {
  print "fetch_xml.pl [--help]  ...\n";
}

use  RSTF::DB::TestCase;
sub create_from_testcase_id {
    my ($testcase_id) = @_;
    my $testcase = RSTF::Compile::ClassFactory->make_testcase({testcase_id=> $testcase_id});
    my $platform = $testcase->platform();
    unless ($platform) {
	print "No platform found\n";
    }
    my $benchmark  = $testcase->benchmark();
    $benchmark->fetch();
    $benchmark->platform($platform);

    my $application = $benchmark->application();

    unless ($application) {
	print "## No application found\n";
	print sprintf("## benchmark_id = %d, app_id = %d\n", $benchmark->benchmark_id, $benchmark->app_id || -1);
    }
    $benchmark->testcases([$testcase]);
    $benchmark->write_xml();
}

sub create_from_run {
    my ($run_id) = @_;
}

sub create_from_spec {
    my ($benchmark_id, $benchmark_name, $platform_name, $size) = @_;

    die "Platform must be specified" unless ($platform_name);
    
    my $platform = RSTF::DB::Platform->find_by_name($platform_name);
    die "Unable to find platform $platform_name" unless ($platform);
    
    if ($benchmark_name) {
	$benchmark = RSTF::DB::Benchmark->find_by_name($benchmark_name);
	die "Unable to find Benchmark $benchmark_name" unless ($benchmark);
    } else {
	if ($benchmark_id) {
	    $benchmark = new RSTF::DB::Benchmark(benchmark_id => $benchmark_id)->fetch();
	    die "Unable to find Benchmark $benchmark_id" unless ($benchmark);
	}
    }
}

die "No Benchmark specified" unless ($benchmark);

