#!/usr/bin/perl
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# count_lines.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/count_lines.pl,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

use strict;
my $file = $ARGV[0];
my $ct = $ARGV[1];
my $match = $ARGV[2];

unless (-e $file && -r $file) {
    die "$file is not readable!";
}

my $RES= `egrep '$match' $file | wc -l`;

if ($ct == $RES) {
    print "Validate: P\n";
} else {
    print "Validate: F\n";
}
exit 0;

