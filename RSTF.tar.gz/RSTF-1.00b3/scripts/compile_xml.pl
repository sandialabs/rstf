#!/usr/bin/perl 
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# compile_xml.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/compile_xml.pl,v $
# $Revision: 1.17 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
# 
# Options
# --help
# --ignore_prior_logdir 

# get basename into submit command, along with our other arguments
# really should run off filename
#

# run
# debug
# verbose
# help
# dryrun
# resultfile
# logfile
# interactive
# suppress_path_lookups
# tag
# purpose

use strict;
use Data::Dumper;
use RSTF::Configuration;
use RSTF::Utils;

use RSTF::DB::DAOFactory;
use RSTF::DB::Purpose;
use RSTF::DB::Dispatch;
use RSTF::DB::Benchmark;
use RSTF::Compile::Parser;

my $config = new RSTF::Configuration();
$config->getopt();

if ($config->help()) {
  show_help();
  exit(1);
}

RSTF::DB::DAOFactory::init();

foreach my $filename (@ARGV) {
    main($filename);
}

sub main {
    my $filename = shift;

    my $outfile;
    my $basename;
    my $fileroot;

    $filename = RSTF::Utils::validate($filename, $config->xml_dtd);
    return unless($filename);

    unless ($filename && -e $filename && -r $filename)  {
	show_help();
	exit(0);
    }

    if ($filename =~ /(.*).xml/) {
	$fileroot = $1;
	my @path = split('/', $fileroot);
	$basename = pop @path;
    } else {
	die "$filename does not appear to be an XML file\n";
    }

    unless($outfile) {
	$outfile = "$fileroot.pl";
	if ($outfile) {
	    open(SCRIPTOUT, ">$outfile") or die "Unable to create $outfile";
	    select(SCRIPTOUT);
	    RSTF::DB::DAOFactory::init();
	    print STDERR "Compiling $filename to  $outfile\n";
	    compile($filename, $outfile, $basename);
	    select(STDOUT);
	    close(SCRIPTOUT);
	}
    }
}


# End of script

sub show_help {
  print "compile_xml.pl [--help] [--new_log_dir] <file>.xml ...\n";
}

sub compile {
    my $filename = shift;
    my $outfile = shift;
    my $basename = shift;
    my $now = localtime;

    my ($runner, $platform, $class_list) = RSTF::Compile::Parser::parse($filename);

    unless ($runner) {
	die "Unable to parse $filename";
    }

    $runner->script_compile();

    # CODE STARTS HERE
    print "# Script automatically generated from $filename on $now\n";

    print "my \$created_time = \"$now\";\n";
    foreach my $module (@$class_list) {
	print "use $module;\n";
    }
    print << 'EOF'

use RSTF::Exec::Options;
use RSTF::LogFile;
use RSTF::DB::DAOFactory;
use IO::File;
use Fcntl ':flock';

my $options = new RSTF::Exec::Options(['resultfile|result_file=s',
				      'logfile=s',
				       'describe!',
				       'queue=s',
				       'walltime=s',
				       'procs=s',
				       'submit!']);
EOF
;


# Have to interpolate the basename into the string, so special
# print here
    print << "EOF";
    \$options->set('logfile', '$basename.log');
    \$options->set('resultfile', '$basename-results.xml');
    # now read the actual options
    \$options->getopt();

RSTF::DB::DAOFactory::init();
 
EOF
    ;

# Now dump the code
$Data::Dumper::Purity = 1;
$Data::Dumper::DeepCopy = 1;
print Data::Dumper->Dump([$platform, $runner], ['platform', 'job']), "\n";

print << 'EOF';

if ($options->help) {
      show_help();
      exit();
}

if ($options->submit) {
    my $perl = $options->rst_perl();
    my $bin = $options->rst_script_bin();
    my $dispatch;
    eval {
	$dispatch = $job->get_parallel_dispatch($platform);
    };
    if ($@) {
	die $@;
    }
    unless ($dispatch) {
	print STDERRR "This does not seem to be a parallel job; submit option makes no sense.";
	exit(1);
    }

    my $queue = $options->queue || $dispatch->job_queue();
    my $walltime = $options->walltime || $dispatch->max_time();
    my $size =  $options->procs || $dispatch->procs || 0;

    my $mode = $dispatch->mode() || 'proc0';
    unless ($size > 0)  {
	print STDERR  "0 or unknown job size $size\n";
	exit(1);
    }
    if ($mode eq 'proc3') {
	$size = ($size + 1) / 2;
    }
    unless (defined($walltime) && $walltime =~ /\d+:\d\d:\d\d/)  {
	print STDERR "Poorly formatted or unknown wall time $walltime\n";
	exit(1);
    }
    unless (defined($queue)) {
	print STDERR "No queue name specified!\n";
	exit(1);
    }

    my $args = sprintf(" --queue='%s' --walltime=%s --size=%d ", $queue, $walltime, $size);
EOF
    ;

    print << "EOF";
    \$args .=  " '$basename' ";
EOF
;
    print << 'EOF';
    my $script = $platform->get_make_queue_cmd_script($options);
    unless ($script) {
	my $platform_name = $platform->name();
	die "No submission constructor script found -- check for your platform's ($platform_name) queue_submit_script specification" ;
    }
    die "Submission constructor  $bin/$script not found -- " unless (-e "$bin/$script");
    (system("$perl $bin/$script  $args") == 0) or die "Unable to make submission scripts";
    exit(0);
}

if ($options->describe) {
    print "Script created on $created_time\n";
    $job->print_description();
} else {
    unless ($options->resultfile =~ /(.*)\.xml/) {
	die $options->resultfile. " does not appear to be an XML file\n";
    }
    $options->platform($platform);
    $job->execute($options);
    if ($options->dryrun) {
	log_normal("Results not written to " . $options->run_run_log . " since this is a dryrun " );
    } else {
	note_result($options->run_run_log, $job->result_path);
    }
}

# note_result drops a marker into ~/Run.log of the actual data generated
# by this script.
# Right now, it goes into Run.log
sub note_result {
    my $log_file = shift;
    my $output = shift;
    
    log_normal("Writing run info to $log_file");
    my $fh = IO::File->new($log_file, O_WRONLY | O_CREAT | O_APPEND) or die "Unable to open $log_file";
    if ($fh) {
	my $now = localtime;

	flock($fh,LOCK_EX);
	printf $fh "%s!%s\n", $now, $output;
	flock($fh,LOCK_UN);
	undef $fh;
    } else {
	log_warn("Unable to write run information to $log_file");
    }
}
    
EOF

print << "EOF";

sub show_help {
print << 'NEOF';
   make_script.pl [--describe] [--verbose] [--debug] [--interactive] [--nointeractive] [--nolookups] [--purpose=name] [--help]
     --describe : print a description of the test cases contained herein.
     --help :  print this message
     --dryun : echo, but do not execute commands
     --interactive : Run parallel jobs interactively (default t)
     --nointeractive : Run parallel jobs in batch    (default f)
     --purpose=name  : run for this purpose -- one of 
NEOF

print '               '  .  RSTF::DB::Purpose->get_user_tags() . "\n";

print << 'NEOF';
     --nolookups : do not resolve executable names; useful for cross-platform testing
     --debug : Extra-verbose output
NEOF
;
}

EOF
;


}
;
