#!/usr/bin/perl
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# parse_tool_info.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/store_tool_info.pl,v $
# $Revision: 1.1 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

# This file is used to take apart the rst_wrappers.out file, parse the entries,
# and add them to the databse.
# 

use strict;
use warnings;
use RSTF::Configuration;
use RSTF::DB::BuildInfo;
use RSTF::DB::CompileTool;
use RSTF::DB::Application;
use RSTF::DB::Platform;
use RSTF::DB::Contact;
use RSTF::DB::AppBinary;
use RSTF::DB::DAOFactory;
use RSTF::DB::DBConnect;

my $config = new RSTF::Configuration();

$config->getopt();

if ($config->help()) {
    show_help();
    exit(1);
}

unless ($config->database_connect()) {
    die "It does not make sense to run parse_output without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();


my $filename = $ARGV[0];
my $executable;
my $action;
my $platform;

open(INPUT, "<$filename") or die "Unable to open $filename";

$/ = '@end';
my $info_ct = 0;
while (<INPUT>) {
    $info_ct++;
    s/\@end\s*$//g;
    # skip blanks and comments
    next if (/^\s*$/);
    next if (/^\s*\#/);

    if (/\@preamble/) {
	$executable = process_preamble($_);
	die "Unable to create executable" unless($executable);
	next;
    }

    if (/\@tool/) {
	process_tool($_, $executable);
	next;
    }

    if (/\@postamble/) {
	process_postamble($_, $executable);
	next;
    }
    print "Unmatched line $_";
    next;
}

# Process_fields takes a block of lines that look like <name>: <value>
# and break the fields into a hash.
sub process_fields {
    my $chunk = shift;
    my $args  = shift;
    # split on newline
    my @fields = split(/\s*\n/, $chunk);
    foreach my $field (@fields) {
	# skip blanks
	next if ($field =~ /^\s*$/);
	next if ($field =~ /^\s*@/);
	chomp ($field);
	# regex ^\s*([^:]*)\s*:\s*(.*)\s*
	my ($tag, @values) = split(/:/, $field);
	my $value = join(':', @values);
	$tag =~ s/^\s+//g;
	$tag =~ s/\s+$//g;
	$tag = lc $tag;
	$value =~ s/^\s+//g;
	$value =~ s/\s+$//g;
	$args->{$tag} = $value;
    }
}

my %handlers;

# look up a tool handler in the database, and return it.
# This function caches the handlers in %handlers.
sub get_handler {
    my $tool = shift;
    my $handler_name = $tool->output_parser();
    if ($handler_name) {
	my $handler= $handlers{$handler_name};
	unless ($handler) {
	    print STDERR "Creating the handler!\n";
	    eval "require $handler_name";
	    eval {
		$handler = $handler_name->new();
		$handlers{$handler_name} =  $handler;
	    };
	    if ($@) {
		die $@;
	    }
	}
	return $handler;
    }
    die "Tool does not specify a handler name";
}

sub print_hash {
    my $hash = shift;
    print "\n====\n";
    foreach my $key  (keys %$hash) {
	print "$key: " . $hash->{$key} . "\n";
    }
    print "====\n";
}

sub get_application {
    my $name = shift;
    my $application = RSTF::DB::Application->find_by_name($name);

    # I Elect to not create the application!
    unless ($application) {
	die "Application $name not found in database";
    }
    return $application;
}


sub get_platform{
    my $name = shift;
    my $platform = RSTF::DB::Platform->find_by_name($name);
    unless ($platform) {
	die "Platform $name not found in database";
    }
    return $platform;
}

sub get_contact {
    my $name = shift;
    my $contact = RSTF::DB::Contact->find_by_name($name);
    unless ($contact) {
	die "Contact $name not found in database";
    }
    return $contact;
}

# Want to cache this result!
my %tool_cache;

sub get_tool {
    my $name = shift;
    my $platform_id = shift;
    my $version = shift;

    my $key = sprintf("%s/%s/%s", $name, $platform_id, $version || '?');
    if ($tool_cache{$key}) {
	return $tool_cache{$key};
    }
    
    my $tool = RSTF::DB::CompileTool->find_by_name($name, $platform_id, $version);
    if ($tool) {
	$tool_cache{$key} =$tool;
    }
    return $tool;
}

sub make_executable {
    my $args = shift;
    
    my $application = get_application($args->{application});
    # platform is global for later error messages.
    $platform  = get_platform($args->{platform});

    my $executable = RSTF::DB::AppBinary->find_by_name({ appname => $application->name,
							platform => $platform->name   });

    if ($executable) {
	my $str = sprintf("An executable for %s on %s already exists. Overwrite? (Y/n): ",
			  $application->name, $platform->name );
	my $ok = yes_no($str);
	if ($ok) {
	    $action = 'updated';
	} else {
	    $executable = undef;
	    $action = 'created';
	}
    }
	

    my $author  = get_contact($args->{'compiled-by'});
    my $path  = $args->{path};

    unless ($executable) {
	$executable = new RSTF::DB::AppBinary(
					      platform_id => $platform->platform_id,
					      filepath=>$path,
					      app_id => $application->app_id,
					      compilation_host => $args->{hostname},
					      compilation_date => $args->{timestamp},
					      compiled_by => $author->contact_id);
	$executable->insert();
    } else {
	$executable->filepath($path);
	$executable->compilation_host($args->{hostname});
	$executable->compilation_date($args->{timestamp});
	$executable->compiled_by($author->contact_id);
	$executable->update();
    }
    return $executable;
}


	

sub show_help {
    print "parse_tool_info.pl filename\n";
}

sub process_preamble {
    my $preamble = shift;
    my %args;
    
    process_fields($preamble, \%args);

    my $executable = make_executable(\%args);
    return $executable;
}

sub process_postamble {
    my $postamble = shift;
    my $executable = shift;
    my %postamble_data;

    process_fields($postamble, \%postamble_data);

    $executable->byte_count($postamble_data{bytes});
    $executable->md5sum($postamble_data{md5sum});
    my $size_info = $postamble_data{'size-info'};
    $executable->size_info($size_info);
    $executable->update();
    printf "AppBinary for %s on %s %s (appbinary_id=%d)\n",
            $executable->filepath, 
            $platform->name,
            $action, 
            $executable->appbinary_id;
}

sub process_tool {
    my $line = shift;
    my $executable = shift;
    my $toolname;
    my %args;
    
    my ($prefix, $info) = split(/\@begin/, $line);
    next unless  (defined($prefix) && defined($info));
    # @tool(name)
    if ($prefix =~ /\@tool\((\s*[^\)\s]+)\s*\)/) {
	$toolname = $1;
    } else {
	die "Malformed tool line - no tool found!";
    }
    
    process_fields($prefix, \%args);
    
    # I don't have the version at this point!
    # However, I need the version-less tool to return the parser,
    my $tool = get_tool($toolname, $executable->platform_id);
    unless ($tool) {
	warn sprintf("%s for %s not found", $toolname, $platform->name);
	return;
    }

    my $handler = get_handler($tool);
    
    if ($handler) {
	# Copy over the fields from $args
	$handler->toolname($toolname);
	$handler->raw_flags($args{arguments});
	$handler->working_directory($args{directory});
	
	$handler->process_info($info);
	my $versioned_tool;
	if ($handler->version()) {
	    $versioned_tool = get_tool($toolname,
				       $executable->platform_id,
				       $handler->version);
	    
	    unless ($versioned_tool) {
		$versioned_tool = new RSTF::DB::CompileTool(name=>$tool->name,
							   platform_id=>$tool->platform_id,
							   language=>$tool->language,
							   vendor_id=>$tool->vendor_id,
							   output_parser=>$tool->output_parser,
							   version=>$handler->version);
		$versioned_tool->insert;
	    }
	}
	    
	# make the build info here!
	# have the executable, the tool, etc.
	my $info = new RSTF::DB::BuildInfo(
					  appbinary_id= >$executable->appbinary_id,
					  tool_id=>$versioned_tool->tool_id,
					  raw_flags=>$handler->raw_flags,
					  filename=>$handler->filename,
					  directory=>$handler->working_directory,
					  expanded_flags=>$handler->expanded_flags,
					  ordinal=>$info_ct++);
	$info->insert;
    } else {
	warn "No handler found for $toolname\n";
	return;
    }
}

