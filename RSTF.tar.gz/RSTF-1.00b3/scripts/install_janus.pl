#!/usr/bin/perl -w -pi.bak
# Use local perl, but fix

s[#\!\s*\S+][#\!/Net/usr/home/raballa/bin/xtflops/perl]g;
