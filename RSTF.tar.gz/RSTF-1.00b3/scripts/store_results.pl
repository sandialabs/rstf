#!/usr/bin/perl 
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# store_results.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/store_results.pl,v $
# $Revision: 1.2 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

use strict;
use RSTF::Configuration;
use RSTF::Utils;
use RSTF::DB::DAOFactory();
use RSTF::Compile::Parser;
use RSTF::DB::Contact;

my $config = new RSTF::Configuration(['witness=s', 'run_by=s']);

my $outfile;
my $basename;

if ($config->help) {
    show_help();
    exit(0);
}

unless ($config->database_connect()) {
    die "It does not make sense to run store_results.xml without a database connection. Check your rst.conf file!";
}

RSTF::DB::DAOFactory::init();
unless (RSTF::DB::DAOFactory::is_connected()) {
    die "Connection to database failed!\n";
}

my $DTD = $config->xml_dtd;
foreach my $file (@ARGV) {

    # validate prints an error message


    my $filename;

    eval {
	$filename = RSTF::Utils::validate($file, $DTD);
    };
    if ($@) {
	print STDERR  $@;
	exit(1);
    }

    unless ($filename) {
	print STDERR "Input file not valid\n";
	exit(1);
    }

    my $signer_name = $config->run_by() || $config->run_runner();

    my $signer;
    if ($signer_name) {
	$signer = RSTF::DB::Contact->find_by_name($signer_name);
	die "Unable to find signer email/Contact $signer_name" unless ($signer);
    }
    
    my $witness;
    if ($config->witness) {
	$witness = RSTF::DB::Contact->find_by_name($config->witness);
	die "Unable to find witness email/Contact " . $config->witness unless ($witness);
    }
    
    if ($signer) {
	printf("Signature: %s (%s)\n", $signer->full_name(), $signer->email);
    }
    
    if ($witness) {
	printf("Witness: %s (%s)\n",  $witness->full_name(), $witness->email);
    }
    
    write_db($filename, $signer, $witness);
}

sub show_help {
  print "store_resultst.pl [--help]  <file>.xml\n";
  print "Save script or script+results into the database.\n";
}

sub write_db  {
    my $filename = shift;
    my $signer = shift;
    my $witness = shift;

    my $now = localtime;
    my $benchmark;
    my $platform;
    my $class_list;
    eval {
	($benchmark, $platform, $class_list) = RSTF::Compile::Parser::parse($filename);
    };
    if ($@) {
	die $@;
    }

    unless ($benchmark) {
	die "Unable to parse $filename";
    }

    if ($signer || $witness) {
	my $tc = $benchmark->testcases;
	foreach my $testcase (@$tc) {
	    $testcase->sign_and_witness($signer, $witness, 1);
	}
    }

    $benchmark->store();

    my $tc = $benchmark->testcases;
    foreach my $testcase (@$tc) {
	printf ("Benchmark: %s Platform: %s Size: %d Testcase id: %d\n",
		$benchmark->nickname || '?',
		$benchmark->platform->name, 
		$testcase->size,
		$testcase->testcase_id);

    }
 }
