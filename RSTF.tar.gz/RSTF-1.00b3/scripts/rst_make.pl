#!/usr/bin/perl 
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# rst_make.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/rst_make.pl,v $
# $Revision: 1.10 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

use strict;
use RSTF::Configuration;
use RSTF::ToolInfo;

my $config = new RSTF::Configuration(['name=s', 'platform=s', 'exe=s']);
$config->getopt();

if ($config->help) {
    show_help();
    exit(1);
}

sub show_help {
    print "rst_make --name=<application> [--platform=<platform>] [--exe=path-to-result] -- make commands...";
}

die "You must specify the application name!" unless($config->name);

my $timestamp = localtime;
eval {
    RSTF::ToolInfo->start_compilation($config->name,
				     $config->exe,
				     $config->platform() || 'Red',
				     $timestamp,
				     $config
				     );
      
      my $args = join(' ', @ARGV);
      (system(@ARGV) == 0) or die "Make exec failed\n";
};
if ($@) {
    die $@;
}


eval {
    RSTF::ToolInfo->end_compilation($config->exe, $config);
};
if ($@) {
    die $@;
}


