#!/usr/bin/perl -w
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# sign_run.pl
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/sign_run.pl,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
#
# sign xml_file?
#  Read the file.
#  add signature contacts
#  write the file.
#    -- means we need to have the <analyst > and <witness >  tags in the Parser, etc.
# sign --run_id=   --witness= --signer=

use strict;

use RSTF::Configuration;

use RSTF::DB::DAOFactory;

use RSTF::Exec;
use RSTF::Compile::ClassFactory;

use RSTF::DB::Contact;
use RSTF::DB::Run;


my $config = new RSTF::Configuration(['run_id=s@','witness=s']);
$config->getopt();

if ($config->help) {
  show_help();
  exit(1);
}

sub show_help {
  print "sign.pl [--help]  ...\n";
}

RSTF::DB::DAOFactory::init();

my $name = $ARGV[0] || $config->run_runner();

my $runner = RSTF::DB::Contact->find_by_name($name);
die "Unable to find signer email/Contact $name" unless ($runner);

my $witness;

if ($config->witness) {
    $witness = RSTF::DB::Contact->find_by_name($config->witness);
    die "Unable to find witness email/Contact $witness_name" unless ($witness);
}

printf("Runner: %s (%s)\n", $runner->full_name(), $runner->email);
if ($witness) {
    printf("Witness: %s (%s)\n",  $witness->full_name(), $witness->email);
}

my $run_ids = $config->run_id;

foreach my $run_id (@$run_ids) {
    my $do_update = 0;
    my $run = new RSTF::DB::Run(run_id=>$run_id)->fetch();
    die "No run found for $run_id" unless ($run);
    $do_update += $run->sign_run($runner);
    $do_update +=  $run->witness_run($witness);
    if ($do_update) {
	$run->update();
	print "Run $run_id updated\n";
    }
}

