#!/usr/bin/perl 
###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# pack_results.pl
# 
# Created by: Robert A. Ballance		Wed Jun  2 10:06:48 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/scripts/pack_results.pl,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################


use strict;
use Getopt::Long;

my $log;

my %apps;
my $config = new RSTF::Configuration(['force!']);
$config->getopt();


if ($config->help) {
    show_help();
    exit(1);
}


sub split_path {
    my $path = shift;
    my @dirs = split('/', $path);

    my @prefix = ();
    foreach my $dir (@dirs) {
	if ($apps{$dir}) {
	    return join('/', @prefix) . "/";
	} else {
	    push @prefix, $dir;
	}
    }
    return undef;
}

sub add_to_archive {
    my $archive = shift;
    my $directory = shift;
    my $filename = shift;
    my $cmd = "cd $directory; tar rf $archive $filename";
    if (-e $directory && -e "$directory$filename") {
	(system($cmd) == 0 ) or warn "Unable to add $directory $filename to archive";
    } else {
	print STDERR "Skipping $directory/$filename\n";
    }
}

sub main {
    my $archive = shift;
    my $log = shift;

    my $apps_ref = $config->pack_apps();
    foreach my $appname (@$apps_ref) {
	print "Setting $appname\n";
	$apps{$appname}++;
    }

    die "Unable to access run log $log" unless(-e $log && -r $log);
    if (-e $archive && $config->force()) {
	unlink($archive) or die "Unable to remove existing $archive";
    }

    open(INPUT, "<$log") or die "Unable to open $log";
    while(<INPUT>) {
	next if (/^\s*\#/);
	chomp;
	my ($date, $filename) = split('!');
	my $prefix = split_path($filename);
	if ($prefix) {
	    $filename =~ s/$prefix//g;
	    add_to_archive($archive,  $prefix, $filename);
	} else {
	    die "Malformed file specification on $_\n";
	}
    }
    close(INPUT);
}


# End of script

sub show_help {
  print "pack_results.pl [--help] [--base=<base>] [--log=<log>]\n";
}

$log = $ARGV[0] || $config->run_run_log();
main($config->archive(), $log);


;
