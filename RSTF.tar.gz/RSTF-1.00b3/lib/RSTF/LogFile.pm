###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# LogFile.pm
# 
# Created by: Robert A. Ballance		Thu Apr 22 12:21:26 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/LogFile.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
# 
# Code sample from Network Programming With PERL by Lincoln D. Stein
# Adapted by Robert A. Ballance
# file: LogFile.pm
# Figure 14.3: Logging to a File
###############################################################################

package RSTF::LogFile;

use IO::File;
use Fcntl ':flock';
use Carp 'croak';
use Time::HiRes qw(gettimeofday tv_interval);

use strict;
use warnings;

use vars qw(@ISA @EXPORT);
require Exporter;
@ISA = 'Exporter';
@EXPORT = qw(DEBUG NOTICE WARNING CRITICAL NORMAL
             init_log log_priority push_log pop_log get_logfile_name log_push_category log_pop_category
             log_debug log_notice log_normal log_warn log_die log_file_contents);

use constant DEBUG    => 0;
use constant NOTICE   => 1;
use constant NORMAL   => 2;
use constant WARNING  => 3;
use constant CRITICAL => 4;

my ($PRIORITY,$fh);  # globals
$PRIORITY=DEBUG;
my $start_time = [gettimeofday];
my @levels = ();
my $indent = '';
my $category = '?';
my @categories = ();
my $FILENAME;

sub init_log {
  unless ($fh) {
      $FILENAME = shift;
      $start_time = [gettimeofday];
      $fh       = IO::File->new($FILENAME,O_WRONLY|O_CREAT|O_TRUNC,0644) || return;
      $fh->autoflush(1);
      $PRIORITY = NORMAL;   # log all
      $SIG{__WARN__} = \&log_warn;
      $SIG{__DIE__}  = \&log_die;
      log_push_category('top');
  }
  return 1;
}

sub get_logfile_name {
    return $FILENAME;
}

sub log_priority {
  unless ($PRIORITY) {
    $PRIORITY = shift if @_;
    return $PRIORITY;
  }
}

sub log_push_category {
  my $cat = shift;
  push @categories, $category;
  log_debug("Begin $cat");
  $category = $cat;
}

sub log_pop_category {
  log_debug("End $category");
  $category =  pop @categories;
}

sub push_log {
  my $logfile = shift;
  my $priority = shift;
  init_log($logfile);
  push (@levels, $PRIORITY || DEBUG);
  $PRIORITY = $priority;
  $indent = '.' x ($#levels * 4);
}

sub pop_log {
  $PRIORITY = pop(@levels);
  if (@levels) {
    $indent = ' ' x (($#levels - 1) * 4);
  } else {
    $indent = '';
  }
}

sub _msg {
  my $priority = shift;
  my $delta = tv_interval($start_time, [gettimeofday]);
  my $msg = join('',@_);
  if ($priority eq 'warn' || $priority eq 'die') {
     my ($pack,$filename,$line) = caller(1);
     $msg .= " at $filename line $line" unless $msg =~ /\n$/;
   }
  return sprintf("%10.6g %-16s $indent$msg\n", $delta, "[$priority,$category]");
}

sub _log {
    my $message = shift;
    
    if (defined($fh)) {
	flock($fh,LOCK_EX);
	print $fh $message;
	flock($fh,LOCK_UN);
	print $message;
    }
}

sub log_debug  { 
    return unless DEBUG >= $PRIORITY;
    _log(_msg('debug',@_));
}

sub log_notice { 
  return unless NOTICE >= $PRIORITY;
  _log(_msg('notice',@_));
}

sub log_normal{ 
  return unless NORMAL >= $PRIORITY;
  _log(_msg('normal',@_));
}

sub log_warn { 
  return unless WARNING >= $PRIORITY;
  _log(_msg('warning',@_));
}

sub log_die {
  return unless CRITICAL >= $PRIORITY;
  _log(_msg('critical',@_));
  die @_;
}

sub log_file_contents {
  my $filename = shift;
  if ($filename && -e $filename) {
      open(INPUT, "<$filename") or die "Unable to access $filename";
      _log(_msg($filename, '========= BEGIN ======= '));
      while (<INPUT>) {
	  chomp;
	  _log(_msg($filename, $_));
      }
      _log(_msg($filename, '========= END ======= '));
      close(INPUT);
  }
}

1;
