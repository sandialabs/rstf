###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# ToolInfo.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/ToolInfo.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::ToolInfo;
use Cwd;
use Sys::Hostname;
use strict;
use Class::MethodMaker (
			get_set => [qw(
				       toolname

				       realname
				       toolpath
				       version

				       working_directory
				       filename
				       raw_flags
				       expanded_flags
				       )],
			new_hash_init => 'new'
			);

sub print {
    my $self = shift;
    foreach my $field (sort keys %$self) {
	print "$field = " . $self->$field() . "\n";
    }
}



my $path;

sub start_compilation {
    my $pkg = shift;
    my $application = shift;
    my $exename = shift;
    my $platform = shift;
    my $timestamp = shift;
    my $options = shift;

    my $wrapper_bin = $options->wrapper_bin();

    unless (-e $wrapper_bin) {
	die "Unable to find tool wrappers\n";
    }

    unless (-e "$wrapper_bin/tool.sh") {
	die "Tool wrappers are not properly installed\n";
    }

    my $compiler_info_file = $options->wrapper_info_file();

    eval {

	open(OUTPUT, ">$compiler_info_file") or die "Unable to open $compiler_info_file";
	printf OUTPUT "\@preamble\n";
	printf OUTPUT "Application: %s\n", $application;
	if ($exename) {
	    printf OUTPUT "Path: %s\n", $exename;
	}
	printf OUTPUT "Timestamp: %s\n", $timestamp;
	printf OUTPUT "Platform: %s\n", $platform;
	printf OUTPUT "Hostname: %s\n", hostname();
	printf OUTPUT "Compiled-by: %s\n", $options->runner();
	printf OUTPUT "\@end\n";
	
	close(OUTPUT);
    
    };

    $path = $ENV{PATH};
    $ENV{PATH} = sprintf("%s:%s", $wrapper_bin, $path);
    $ENV{RST_WRAPPER_BIN} = $wrapper_bin;
    unless ($compiler_info_file =~ m[^/]) {
	my $cwd = cwd();
	$compiler_info_file = sprintf "%s/%s",$cwd, $compiler_info_file;
    }
    $ENV{RST_COMPILER_OUTPUT_FILE} = $compiler_info_file;
}

sub do_size {
    my $filename = shift;
    my $config = shift;
    my $size = $config->make_size_program || 'size';
    open(INPUT, "$size $filename|") or die "Unable to fork $size on $filename";
    my $headers = <INPUT>;
    chomp($headers);
    $headers =~ s/^\s*//g;
    my @headers = split(/\s+/, $headers);
    
    my $data = <INPUT>;
    chomp($data);
    $data =~ s/^\s*//g;
    
    my @data = split(/\s+/, $data);
    my @pairs = ();
    for(my $i = 0; $i <= $#data; $i++) {
	push @pairs, sprintf("%s=%s", $headers[$i], $data[$i]);
    }
    close(INPUT);
    return join(',', @pairs);
}


sub do_md5 {
    my $filename = shift;
    my $config = shift;
    my $md5sum = $config->make_md5_program|| 'md5sum';

    open(INPUT, "$md5sum $filename|") or die "Unable to fork $md5sum on $filename";
    my $line= <INPUT>;
    chomp($line);
    my ($sum, $exe) = split(/\s+/, $line);
    close(INPUT);
    return $sum;
}    

sub get_bytecount {
    my $filename = shift;
    my @stat= stat($filename);
    return  $stat[7];
}    

sub end_compilation {
    my $pkg = shift;
    my $exepath  = shift;
    my $config  = shift;
    if ($exepath) {
	my $compiler_info_file = $config->wrapper_info_file();
	
	eval {
	    open(OUTPUT, ">>$compiler_info_file") or die "Unable to open $compiler_info_file";
	    printf OUTPUT "\@postamble\n";
	    printf OUTPUT ("bytes: %d\n",  get_bytecount($exepath, $config));
	    printf OUTPUT ("size-info: %s\n",  do_size($exepath, $config));
	    printf OUTPUT ("md5sum: %s\n",  do_md5($exepath, $config));
	    printf OUTPUT "\@end\n";
	    close(OUTPUT);
	    
	};
    }
}

1;
