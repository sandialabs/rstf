###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# RunList.pm
# 
# Created by: Robert A. Ballance		Wed Mar 17 11:11:16 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/RunList.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::RunList;
use strict;
use warnings;
use RSTF::DB::DBList;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::DBList);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(runs  testcase_id)]
);

use RSTF::DB::Run;
use RSTF::DB::XMLWriter;

my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'runlist', other_attr=>[qw(testcase_id)]);

my @default_args = (runs => [],
		    object_type => 'RSTF::DB::Run',
		    key_slots => ['testcase_id'],
		    list_field => 'runs',
		    xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

sub sign_and_witness {
    my $self = shift;
    my $signer = shift;
    my $witness = shift;
    my $force = shift;
    
    my $run_list = $self->runs();
    foreach my $run (@$run_list) {
	$run->sign_run($signer, 1);
	$run->witness_run($witness, 1);
    }
}

1;

