##############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Environment.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 14:53:24 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/DataDirectoryList.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################


package RSTF::DB::DataDirectoryList;
use strict;
use warnings;

use RSTF::DB::DBList;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBList);

use RSTF::DB::OutputDirectory;
use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'datadirectorylist', id_slot=>'testcase_id');

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(directories expanded_directories testcase_id)]
);


my @default_args = (directories => [],
		    expanded_directories => [],
		    object_type => 'RSTF::DB::OutputDirectory',
		    list_field => 'directories',
		    key_slots => ['testcase_id'],
		    xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

sub allocate {
    my $self = shift;
    my $username = shift;
    my $test_name = shift;
    my $test_size = shift;

    my $output_dirs = $self->directories;

    # need to pass the logname and testcase name to the allocate call
    # give OutputDirector.pm a allocate call.
    my @expanded_dirs = ();
    foreach my $directory (@$output_dirs) {
	push @expanded_dirs,  $directory->allocate($username, $test_name, $test_size);
    }
    $self->expanded_directories(\@expanded_dirs);
}

1;

