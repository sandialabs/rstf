###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# XMLWriter.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 13:47:29 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/XMLWriter.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################

package RSTF::DB::XMLWriter;

use strict;
use warnings;

use Class::MethodMaker(
		       new_hash_init => '_init_hash',
		       new_with_init => 'new',
		       get_set => [qw(tag id_slot other_attr is_empty)]
		       );

my @init_args = (is_empty => 0);

sub init {
    my $self = shift;
    return $self->_init_hash(@init_args, @_);
}

my $indent = 0;
my $indent_str = '';

# Could we send in a hash? Or a list of name-value pairs?
sub header {
    my $self = shift;
    my $obj = shift;

    my $id_tag = $self->id_slot;
    my $tag = $self->tag;
    my $other_attr = $self->other_attr;

    my $prev_indent_str = $indent_str;
    $indent += 4;
    $indent_str = ' ' x $indent;

    my $id;
    if ($obj && $id_tag) {
	$id = $obj->$id_tag();
    }
    my $hdr = $prev_indent_str . '<' . $self->tag;
    if (defined($id)) {
	$hdr .= sprintf(" id='%s' ", $id);
    }
    if ($other_attr) {
	foreach my $attr (@$other_attr) {
	    if ($obj && $obj->$attr) {
		$hdr .= sprintf(" %s='%s' ", $attr, $obj->$attr);
	    }
	}
    }

    if ($self->is_empty) {
	$hdr .= '/';
	$indent -= 4;
	$indent_str = ' ' x $indent;
    }
    return $hdr . ">\n";
}

sub footer {    
    my $self = shift;
    unless ($self->is_empty) {
	my $tag = $self->tag;
	$indent -= 4;
	$indent_str = ' ' x $indent;
	return sprintf("%s</%s>\n", $indent_str, $tag);
    }
    return '';
}

sub format_time {
  my $pkg = shift;
  my $tag = shift;
  my $time = shift;
  if ($time) {
      return sprintf("%s<%s> \t%12.6f </%s>\n", $indent_str, $tag, $time, $tag);
  }
  return '';
}

sub format_value {
    my $pkg = shift;
    my $tag = shift;
    my $value = shift;
    if ($value) {
	return sprintf("%s<%s> %s </%s>\n", $indent_str, $tag, $value, $tag);
    }
    return '';
}

1;
