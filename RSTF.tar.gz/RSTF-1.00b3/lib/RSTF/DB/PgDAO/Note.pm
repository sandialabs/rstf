###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Note.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Note.pm,v $
# $Revision: 1.3 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Note;
use strict;

use  RSTF::DB::Note;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);


use DBI qw(:sql_types);
use RSTF::DB::Utils qw(:dates);

my @init_args = (table => 'Note',
		 serial_column => 'note_id',
		 object_class => 'RSTF::DB::Note',
		 scalar_db_fields => [qw(
					 study_id	
					 date
					 author_id
					 text
					 )]

		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM Note WHERE note_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->note_id, SQL_INTEGER);
}

sub get_delete_sql {
    return q{DELETE  FROM Note WHERE note_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->note_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO Note(study_id,
			      author_id,
			      date, 
			      text) VALUES(?,?,?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->study_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->author_id, SQL_INTEGER);
    my $date = $obj->date();
    $date = format_date($date);
    $obj->date($date);
    $insert_stmt->bind_param($i++, $obj->date, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->text, SQL_VARCHAR);
}

sub get_update_sql {
    return q{UPDATE Note SET study_id = ?,
	     author_id = ?,
	     date = ?,
	     text = ?
	 WHERE study_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->study_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->author_id, SQL_INTEGER);
    my $date = $obj->date();
    $date = format_date($date);
    $obj->date($date);
    $update_stmt->bind_param($i++, $obj->date, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->text, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->note_id );
}

sub get_fetchall_sql {
  return q{Select note_id FROM Note };
}

1;
