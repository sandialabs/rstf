###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Vendor.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Vendor.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Vendor;
use strict;

use  RSTF::DB::Vendor;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);


my @init_args = (table => 'Vendor',
		 object_class => 'RSTF::DB::Vendor',
		 serial_column => 'vendor_id',
		 scalar_db_fields => [qw(
					 name	
					 poc_id
					 )]
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM Vendor WHERE vendor_id = ?};
}

sub get_fetchall_sql {
  return q{Select vendor_id FROM Vendor };
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->vendor_id, SQL_INTEGER);
}

sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift; # hash of values returned from a fetch query.
    my $obj = shift;
}

sub get_delete_sql {
    return q{DELETE  FROM Vendor WHERE vendor_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->vendor_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO Vendor(name,poc_id) VALUES(?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->poc_id, SQL_INTEGER);
}

sub get_update_sql {
    return q{UPDATE Vendor SET name = ?, poc_id = ?  WHERE vendor_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->poc_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->vendor_id );
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select vendor_id from Vendor where name = '$name'};
}

1;
