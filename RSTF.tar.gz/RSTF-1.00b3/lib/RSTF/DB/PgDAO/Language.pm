###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Language.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Language.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Language;

use strict;

use  RSTF::DB::Language;
use RSTF::DB::PgDAO::DAO;


use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'Language',
		 nested_object_fields => [],
		 scalar_db_fields => [qw( name )]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}

sub create_object {
  my $self = shift;
  my $name = shift;
  my $obj = new RSTF::DB::Language(name=>$name);
  return $obj;
}

sub get_fetch_sql {
  return q{SELECT * from Language where name = ?};
}


sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $language = shift;

  $fetch_stmt->bind_param(1, $language->name, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO Language(name) VALUES(?)  };
};

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $language = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $language->name, SQL_VARCHAR);
}

sub get_update_sql {
    return q{
	     UPDATE Purpose SET
	     name = ?,
	     WHERE name = ?
	    };
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $language = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $language->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $language->name, SQL_VARCHAR);
}

sub get_delete_sql {
  return q{  DELETE FROM Language where name = ? };
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $language = shift;
    $delete_stmt->bind_param(1, $language->name, SQL_VARCHAR);
}


sub get_fetchall_sql {
  return q{Select name FROM Language };
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select name FROM Language where name  = '$name'};
}

1;
