###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# PackageType.pm
# 
# Created by: Robert A. Ballance		Wed Mar 17 10:52:18 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/PackageType.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  DAO accessor for the PackageType table. All the work happens in the
#  TypeTable base class.
# 
###############################################################################
package RSTF::DB::PgDAO::PackageType;

use strict;

use  RSTF::DB::PackageType;

use RSTF::DB::PgDAO::TypeTable;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::TypeTable);


my @init_args = (table => 'PackageType',
		 name => 'name',
		 typename => 'RSTF::DB::PackageType',
		 serial_column => 'package_type_id',
		 scalar_db_fields => [qw( name )]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
  }

sub create_object {
  my $self = shift;
  my ($id,$name) = @_;
  my $obj = new RSTF::DB::PackageType (package_type_id => $id, name => $name)->fetch();
  return $obj;
}


1;
