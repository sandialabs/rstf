###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# BenchmarkPlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/BenchmarkPlanning.pm,v $
# $Revision: 1.2 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::BenchmarkPlanning;
use strict;

use  RSTF::DB::BenchmarkPlanning;

use RSTF::DB::PgDAO::DAO;
use RSTF::DB::Utils qw(:dates);
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'BenchmarkPlanning',
		 serial_column => 'benchmark_plan_id',
		 object_class=>'RSTF::DB::BenchmarkPlanning',
		 scalar_db_fields => [qw(
					 benchmark_id
					 platform_id
					 source_code_ready	
					 compile_scripts_available	
					 compile_scripts_tested	
					 )]
		 );


sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM BenchmarkPlanning WHERE benchmark_plan_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->benchmark_plan_id, SQL_INTEGER);
}


sub get_delete_sql {
    return q{DELETE  FROM BenchmarkPlanning WHERE benchmark_plan_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->benchmark_plan_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO BenchmarkPlanning(
					   benchmark_id,
					   platform_id,
					   source_code_ready,
					   compile_scripts_available,
					   compile_scripts_tested)
		 VALUES(?,?,?,?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    my $date;
    $insert_stmt->bind_param($i++, $obj->benchmark_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    # Fix date for source_code_ready
    $date = $obj->source_code_ready();
    $obj->source_code_ready(format_date($date));
    $insert_stmt->bind_param($i++, $obj->source_code_ready, SQL_VARCHAR);
    # Fix date for compile_scripts_available
    $date = $obj->compile_scripts_available();
    $obj->compile_scripts_available(format_date($date));
    $insert_stmt->bind_param($i++, $obj->compile_scripts_available, SQL_VARCHAR);
    # Fix date for compile_scripts_tested
    $date = $obj->compile_scripts_tested();
    $obj->compile_scripts_tested(format_date($date));
    $insert_stmt->bind_param($i++, $obj->compile_scripts_tested, SQL_VARCHAR);
}

sub get_update_sql {
    return q{UPDATE BenchmarkPlanning SET
		 benchmark_id=?,
		 platform_id=?,
		 source_code_ready = ?,
		 compile_scripts_available = ?,
		 compile_scripts_tested = ?
		 WHERE benchmark_plan_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;
    my $date;
    $update_stmt->bind_param($i++, $obj->benchmark_id );
    $update_stmt->bind_param($i++, $obj->platform_id );
    # Fix date for source_code_ready
    $date = $obj->source_code_ready();
    $obj->source_code_ready(format_date($date));
    $update_stmt->bind_param($i++, $obj->source_code_ready, SQL_VARCHAR);
    # Fix date for compile_scripts_available
    $date = $obj->compile_scripts_available();
    $obj->compile_scripts_available(format_date($date));
    $update_stmt->bind_param($i++, $obj->compile_scripts_available, SQL_VARCHAR);
    # Fix date for compile_scripts_tested
    $date = $obj->compile_scripts_tested();
    $obj->compile_scripts_tested(format_date($date));
    $update_stmt->bind_param($i++, $obj->compile_scripts_tested, SQL_VARCHAR);

    $update_stmt->bind_param($i++, $obj->benchmark_plan_id );
}

sub get_find_by_name_sql {
    my $self = shift;
    my $benchmark_id = shift;
    my $platform_id = shift;
    my $sql =  qq{Select benchmark_plan_id FROM BenchmarkPlanning WHERE
		      benchmark_id=$benchmark_id AND   platform_id=$platform_id};
    return $sql;
}
1;
