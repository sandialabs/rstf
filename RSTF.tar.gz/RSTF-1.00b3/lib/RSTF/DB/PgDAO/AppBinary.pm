###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# AppBinary.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/AppBinary.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::AppBinary;
use strict;

use  RSTF::DB::AppBinary;
use RSTF::DB::PgDAO::DAO;


use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);
use RSTF::DB::Utils qw(:dates);


use DBI qw(:sql_types);


my @init_args = (table => 'AppBinary',
		 serial_column => 'appbinary_id',
		 object_class => 'RSTF::DB::AppBinary',
		 scalar_db_fields => [qw(
					 app_id	
					 platform_id	
					 filepath
					 compilation_host	
					 compilation_date	
					 compiled_by_id
					 size_info
					 byte_count
					 md5sum
					 )]
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM AppBinary WHERE appbinary_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->appbinary_id, SQL_INTEGER);
}

sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift; # hash of values returned from a fetch query.
    my $obj = shift;
}

sub get_delete_sql {
    return q{DELETE  FROM AppBinary WHERE appbinary_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->appbinary_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO AppBinary(app_id,
				    platform_id,
				    filepath,
				    size_info,
				    byte_count,
				    md5sum,
				    compilation_host,
				    compilation_date,
				    compiled_by_id) VALUES(?,?,?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->filepath, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->size_info, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->byte_count, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->md5sum, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->compilation_host, SQL_VARCHAR);
    # fix date!
    my $date = format_datetime($obj->compilation_date);
    $obj->compilation_date($date);
    $insert_stmt->bind_param($i++, $obj->compilation_date, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->compiled_by_id, SQL_INTEGER);
}

sub get_update_sql {
    return q{UPDATE AppBinary SET app_id = ?,
	     platform_id = ?,
	     filepath = ?,
	     size_info = ?,
	     byte_count=?,
	     md5sum = ?,
	     compilation_host = ?,
	     compilation_date = ?,
	     compiled_by_id = ? 
		 WHERE appbinary_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->filepath, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->size_info, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->byte_count, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->md5sum, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->compilation_host, SQL_VARCHAR);
    # fix date!
    my $date = format_datetime($obj->compilation_date);
    $obj->compilation_date($date);
    $update_stmt->bind_param($i++, $obj->compilation_date, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->compiled_by_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->appbinary_id );
}

sub get_find_by_name_sql {
    my $self = shift;
    my $args = shift;
    if ($args->{appname}) {
	my $appname = $args->{appname};
	my $platform = $args->{platform};
        return qq{Select appbinary_id from AppBinary,Application,Platform WHERE
		      AppBinary.app_id=Application.app_id AND
		      Application.name='$appname' AND
		      AppBinary.platform_id=Platform.platform_id AND
		      Platform.name = '$platform'};
    } 
    if ($args->{md5sum}) {
	my $md5sum = $args->{md5sum};
	my $platform = $args->{platform};
	my $appname = $args->{appname};
	die "No platform specified" unless ($platform);
        return qq{Select appbinary_id from AppBinary,Platform,Application
		      WHERE md5sum='$md5sum' AND
		      AppBinary.app_id=Application.app_id AND
		      Application.name='$appname' AND
		      AppBinary.platform_id=Platform.platform_id AND
		      Platform.name = '$platform'};
    }
    die "Invalid arguments to RSTF::DB::AppBinary->find_by_name\n";
}

1;
