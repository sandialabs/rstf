###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Contact.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Contact.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Contact;
use strict;
use RSTF::DB::PgDAO::DAO;
use RSTF::DB::Contact;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'Contact',  serial_column => 'contact_id',
		 scalar_db_fields => [ qw(
					  last_name
					  first_name
					  nickname
					  organization
					  company
					  phone
					  fax
					  mobile
					  email)]
		 );

sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}

####


sub get_fetch_sql {
  return q{SELECT * from Contact where contact_id = ?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $contact = shift;
  $fetch_stmt->bind_param(1, $contact->contact_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{
	   INSERT INTO Contact(last_name,first_name, nickname,organization, company, phone, fax, mobile, email)
	   VALUES(?,?,?,?,?,?,?,?,?)
	  };
};

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $contact = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $contact->last_name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->first_name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->nickname, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->organization, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->company, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->phone, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->fax, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->mobile, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $contact->email, SQL_VARCHAR);
}

sub get_update_sql {
    return q{
	     UPDATE Contact SET
	     last_name = ?,
	     first_name = ?,
	     nickname = ?,
	     organization =?,
	     company=?,
	     phone= ?,
	     fax =?,
	     mobile =?,
	     email = ?
	     WHERE contact_id = ?
	    };
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $contact = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $contact->last_name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->first_name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->nickname, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->organization, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->company, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->phone, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->fax, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->mobile, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->email, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $contact->contact_id);
}

sub get_delete_sql {
  return q{
	   DELETE FROM Contact where contact_id = ?
	  };
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $contact = shift;
    $delete_stmt->bind_param(1, $contact->contact_id, SQL_INTEGER);
}

sub create_object {
  my $self = shift;
  my ($id) = @_;
  my $obj = new RSTF::DB::Contact(contact_id => $id)->fetch();
  return $obj;
}

sub get_fetchall_sql {
  return q{Select contact_id FROM Contact };
}


# Find by name uses email addresses as the unique name!
sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select contact_id FROM contact where email = '$name'};
}


1;
