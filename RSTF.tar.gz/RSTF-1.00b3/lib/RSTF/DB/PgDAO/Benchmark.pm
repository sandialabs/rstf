###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Benchmark.pm
# 
# Created by: Robert A. Ballance		Fri Apr 16 15:13:55 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Benchmark.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PgDAO::Benchmark;
use strict;

use  RSTF::DB::Benchmark;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);


use DBI qw(:sql_types);


my @init_args = (table => 'Benchmark',
		 serial_column => 'benchmark_id',
		 object_class => 'RSTF::DB::Benchmark',
		 scalar_db_fields => [qw(
					 app_id
					 title	
					 description	
					 nickname
					 tag
					 app_config	
					 priority	
					 root_directory	
					)]
		);

sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
  return q{SELECT * FROM Benchmark WHERE benchmark_id = ?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;
  $fetch_stmt->bind_param(1, $obj->benchmark_id, SQL_INTEGER);
}

sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift;	# hash of values returned from a fetch query.
  my $obj = shift;
    


  if ($db_hashref->{benchmark_state_id}) {
    my $app = new RSTF::DB::BenchmarkState(benchmark_state_id => $db_hashref->{benchmark_state_id})->fetch();
    $obj->benchmark_state($app);
  }

  if ($db_hashref->{logname}) {
    $obj->log_filename($db_hashref->{logname});
  }
  if ($db_hashref->{logpath}) {
    $obj->log_path( $db_hashref->{logpath}); 
  }
  if ($db_hashref->{app_id}) {
      $obj->application();
  }
  if ($db_hashref->{platform_id}) {
      $obj->platformn();
  }
}

sub get_delete_sql {
  return q{DELETE  FROM Benchmark WHERE benchmark_id = ?};
}

sub bind_delete_stmt{
  my $self = shift;
  my $delete_stmt = shift;
  my $obj = shift;
  $delete_stmt->bind_param(1, $obj->benchmark_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO Benchmark(title,
				 app_id,
				 description,
				 nickname,
				 tag,
				 benchmark_state_id,
				 app_config,
				 priority,
				 root_directory,
				 logname,
				 logpath) VALUES(?,?,?,?,?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
  my $self = shift;
  my $insert_stmt = shift;
  my $obj = shift;

  my $i = 1;
  $insert_stmt->bind_param($i++, $obj->title, SQL_VARCHAR);
  if ($obj->application) {
    $insert_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
  } else {
    $insert_stmt->bind_param($i++, undef);
  }
  $insert_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->nickname, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->tag, SQL_VARCHAR);
  if ($obj->benchmark_state) {
    $insert_stmt->bind_param($i++, $obj->benchmark_state()->benchmark_state_id, SQL_INTEGER);
  } else {
    $insert_stmt->bind_param($i++, undef);
  }
  $insert_stmt->bind_param($i++, $obj->app_config, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->priority, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->root_directory, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->log_filename, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->log_path, SQL_VARCHAR);
}

sub get_update_sql {
  return q{UPDATE Benchmark SET title = ?,
	   app_id = ?,
	   description = ?,
	   nickname = ?,
	   tag = ?,
	   benchmark_state_id = ?,
	   app_config = ?,
	   priority = ?,
	   root_directory = ?,
	   logname = ?,
	   logpath = ? 
	   WHERE benchmark_id = ?};
}

sub bind_update_stmt {
  my $self = shift;
  my $update_stmt = shift;
  my $obj = shift;

  my $i = 1;

  $update_stmt->bind_param($i++, $obj->title, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->nickname, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->tag, SQL_VARCHAR);
  if ($obj->benchmark_state) {
    $update_stmt->bind_param($i++, $obj->benchmark_state()->benchmark_state_id, SQL_INTEGER);
  } else {
    $update_stmt->bind_param($i++, undef);
  }
  $update_stmt->bind_param($i++, $obj->app_config, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->priority, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->root_directory, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->log_filename, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->log_path, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->benchmark_id );
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select benchmark_id from Benchmark where nickname = '$name'};
}

1;

