###############################################################################
# Application.pm
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Created by: Robert A. Ballance		Mon Mar 29 10:55:48 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Application.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################


# To Do:
# Make sure that the primary_language is in the Language table.

package RSTF::DB::PgDAO::Application;
use strict;

use RSTF::DB::PgDAO::DAO;
use RSTF::DB::Utils qw(:dates);
use RSTF::DB::OuterBlock;
use RSTF::DB::PropertyList;
use RSTF::DB::Environment;

use RSTF::DB::Application;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::DAO);


use DBI qw(:sql_types);

my @init_args = (table => 'Application',  serial_column => 'app_id', 
		 scalar_db_fields=> [ qw(app_id
					 name
					 description
					 lab
					 status
					 completion_date
					 primary_language
					 package_type_id) ],
		 nested_object_fields=>[]
		);

sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}

sub _fetch_block {
  my $self = shift;
  my $app_id = shift;
  my $type = shift;
  return new RSTF::DB::OuterBlock(key_values=>[$app_id], name=>$type, key_slots=>['app_id']);
}

# FIX THESE!
sub get_fetch_sql {
  return q{SELECT * from Application where app_id = ?};
}


sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $app = shift;
  $fetch_stmt->bind_param(1, $app->app_id, SQL_INTEGER);
}

# sub finalize_fetch { 
#   my $self = shift;
#   my $db_hashref = shift; # hash of values returned from a fetch query.
#   my $obj = shift;
# }

sub get_insert_sql {
  return q{
	   INSERT INTO Application(name,lab,description,status,completion_date,primary_language,package_type_id) VALUES(?,?,?,?,?,?,?)
	  };
};

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $app = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $app->name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $app->lab, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $app->description, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $app->status, SQL_VARCHAR);
    # fix date!
    my $date = format_date($app->completion_date);
    $app->completion_date($date);
    $insert_stmt->bind_param($i++, $app->completion_date, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $app->primary_language, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $app->package_type_id, SQL_INTEGER);

}

sub get_update_sql {
    return q{
	     UPDATE Application SET
	     name = ?,
	     lab = ?,
	     description = ?,
	     status = ?,
	     completion_date = ?,
	     primary_language = ?,
	     package_type_id = ?
	     WHERE app_id = ?
	    };
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $app = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $app->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->lab, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->description, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->status, SQL_VARCHAR);
    # fix date!
    my $date = format_date($app->completion_date);
    $app->completion_date($date);
    $update_stmt->bind_param($i++, $date, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->primary_language, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->package_type_id, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $app->app_id);
}

sub get_delete_sql {
  return q{
	   DELETE FROM Application where app_id = ?
	  };
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $app = shift;
    $delete_stmt->bind_param(1, $app->app_id, SQL_INTEGER);
}

sub create_object {
  my $self = shift;
  my $id = shift;
  my $obj = new RSTF::DB::Application(app_id => $id)->fetch();
  return $obj;
}

sub get_fetchall_sql {
  return q{Select app_id FROM Application };
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select app_id FROM Application where name = '$name'};
}


1;
