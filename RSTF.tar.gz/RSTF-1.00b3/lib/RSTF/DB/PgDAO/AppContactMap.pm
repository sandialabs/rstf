###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# AppContactMap.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/AppContactMap.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################
package RSTF::DB::PgDAO::AppContactMap;
use strict;

use  RSTF::DB::AppContactMap;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'AppContactMap',
		  serial_column => undef,
		 object_class=>'RSTF::DB::AppContactMap',
		 scalar_db_fields => [qw(

					 app_id	
					 benchmark_id	
					 contact_id	
					 role_id	
					 notes
					 )]
);


sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
  }


sub get_fetch_sql {
  return q{SELECT * FROM AppContactMap WHERE app_id=? and role_id=?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;
  $fetch_stmt->bind_param(1, $obj->app_id, SQL_INTEGER);
  $fetch_stmt->bind_param(2, $obj->role_id, SQL_INTEGER);
}

sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift; # hash of values returned from a fetch query.
  my $obj = shift;


}

sub get_delete_sql {
    return q{DELETE  FROM AppContactMap WHERE app_id=? and role_id=?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->app_id, SQL_INTEGER);
    $delete_stmt->bind_param(2, $obj->role_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO AppContactMap(app_id,
				     benchmark_id,
				     contact_id,
				     role_id,
				     notes) VALUES(?,
						   ?,
						   ?,
						   ?,
						   ?)};
}

sub bind_insert_stmt {
  my $self = shift;
  my $insert_stmt = shift;
  my $obj = shift;

  my $i = 1;
  $insert_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->benchmark_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->contact_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->role_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->notes, SQL_VARCHAR);
}

sub get_update_sql {
  return q{UPDATE AppContactMap SET app_id = ?,
	   benchmark_id = ?,
	   contact_id = ?,
	   role_id = ?,
	   notes = ? 
	       WHERE app_id = ? and role_id=?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->benchmark_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->contact_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->role_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->notes, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->app_id );
    $update_stmt->bind_param($i++, $obj->role_id );
}

1;
