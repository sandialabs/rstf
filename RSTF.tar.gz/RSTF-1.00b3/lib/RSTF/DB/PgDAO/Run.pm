###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Run.pm
# 
# Created by: Robert A. Ballance		Wed Apr  7 08:26:24 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Run.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PgDAO::Run;
use strict;

use  RSTF::DB::Run;

use RSTF::DB::PgDAO::DAO;
use RSTF::DB::Utils qw(:dates);

use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'Run',
		 object_class=>'RSTF::DB::Run',
		 serial_column => 'run_id',
		 scalar_db_fields => [qw(
					 outcome_id
					 testcase_id	
					 appbinary_id	
					 grade_id
					 validation_id
					 purpose_id
					 job_time	
					 compile_time	
					 preprocess_time	
					 postprocess_time	
					 validation_time	
					 installation_time
					 grade_time
					 setup_time
					 cleanup_time
					 finally_time
					 
					 scheduled_date	
					 time_start	
					 time_end	
					 data_valid	
					 runner_id	
					 runner_sig_time
					 witness_id	
					 witness_sig_time
					 system_config_id
					 tag
					 note
                        )],
		 nested_object_fields => [ qw(property_matches
					      system_configuration
					      appbinary) ]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
  }


sub get_fetch_sql {
  return q{SELECT * FROM Run WHERE run_id = ?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;
  $fetch_stmt->bind_param(1, $obj->run_id, SQL_INTEGER);
}

sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift; # hash of values returned from a fetch query.
  my $obj = shift;

 # data directories?
  $obj->property_matches(new RSTF::DB::PropertyMatchList(key_values=>[$db_hashref->{run_id}]));
}

sub get_delete_sql {
  return q{DELETE  FROM Run WHERE run_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
   $delete_stmt->bind_param(1, $obj->run_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO Run(outcome_id,
			   testcase_id,
			   appbinary_id,
			   grade_id,
			   validation_id,
			   purpose_id,
			   job_time,
			   compile_time,
			   preprocess_time,
			   postprocess_time,
			   validation_time,
			   grade_time,
			   setup_time,
			   cleanup_time,
			   finally_time,
			   installation_time,

			   scheduled_date,
			   time_start,
			   time_end,
			   data_valid,
			   runner_id,
			   runner_sig_time,
			   witness_id,
			   witness_sig_time,
			   system_config_id,
			   tag,
			   note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->outcome_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->testcase_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->appbinary_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->grade_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->validation_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->purpose_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->job_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->compile_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->preprocess_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->postprocess_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->validation_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->grade_time, SQL_FLOAT);

    $insert_stmt->bind_param($i++, $obj->setup_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->cleanup_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->finally_time, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $obj->installation_time, SQL_FLOAT);

    # fix date!
    my $date = format_datetime($obj->scheduled_date);
    $obj->scheduled_date($date);
    $insert_stmt->bind_param($i++, $obj->scheduled_date, SQL_VARCHAR);

    $date = format_datetime($obj->time_start);
    $obj->time_start($date);
    $insert_stmt->bind_param($i++, $obj->time_start, SQL_VARCHAR);

    $date = format_datetime($obj->time_end);
    $obj->time_end($date);
    $insert_stmt->bind_param($i++, $obj->time_end, SQL_VARCHAR);

    $insert_stmt->bind_param($i++, $obj->data_valid);
    $insert_stmt->bind_param($i++, $obj->runner_id, SQL_INTEGER);

    $date = format_datetime($obj->runner_sig_time);
    $obj->runner_sig_time($date);
    $insert_stmt->bind_param($i++, $obj->runner_sig_time, SQL_VARCHAR);

    $insert_stmt->bind_param($i++, $obj->witness_id, SQL_INTEGER);

    $date = format_datetime($obj->witness_sig_time);
    $obj->witness_sig_time($date);
    $insert_stmt->bind_param($i++, $obj->witness_sig_time, SQL_VARCHAR);

    $insert_stmt->bind_param($i++, $obj->system_config_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->tag, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->note, SQL_VARCHAR);
}

sub get_update_sql {
  return q{UPDATE Run SET
	       outcome_id = ?,
	       testcase_id = ?,
	       appbinary_id = ?,
	       grade_id = ?,
	       validation_id = ?,
	       purpose_id = ?,

	       job_time = ?,
	       compile_time = ?,
	       preprocess_time = ?,
	       postprocess_time = ?,
	       validation_time = ?,
	       grade_time = ?,
	       setup_time = ?,
	       cleanup_time = ?,
	       finally_time = ?,
	       installation_time = ?,
	       scheduled_date = ?,
	       time_start = ?,
	       time_end = ?,
	       data_valid = ?,
	       runner_id = ?,
	       runner_sig_time = ?,
	       witness_id = ?,
	       witness_sig_time = ?,
	       system_config_id = ?,
	       tag = ?,
	       note = ?
	       WHERE run_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $obj->outcome_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->testcase_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->appbinary_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->grade_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->validation_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->purpose_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->job_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->compile_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->preprocess_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->postprocess_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->validation_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->grade_time, SQL_FLOAT);

    $update_stmt->bind_param($i++, $obj->setup_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->cleanup_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->finally_time, SQL_FLOAT);
    $update_stmt->bind_param($i++, $obj->installation_time, SQL_FLOAT);

    # fix date!
    my $date = format_datetime($obj->scheduled_date);
    $obj->scheduled_date($date);
    $update_stmt->bind_param($i++, $obj->scheduled_date, SQL_VARCHAR);

    $date = format_datetime($obj->time_start);
    $obj->time_start($date);
    $update_stmt->bind_param($i++, $obj->time_start, SQL_VARCHAR);

    $date = format_datetime($obj->time_end);
    $obj->time_end($date);
    $update_stmt->bind_param($i++, $obj->time_end, SQL_VARCHAR);

    $update_stmt->bind_param($i++, $obj->data_valid);
    $update_stmt->bind_param($i++, $obj->runner_id, SQL_INTEGER);

    $date = format_datetime($obj->runner_sig_time);
    $obj->runner_sig_time($date);
    $update_stmt->bind_param($i++, $obj->runner_sig_time, SQL_VARCHAR);

    $update_stmt->bind_param($i++, $obj->witness_id, SQL_INTEGER);
    $date = format_datetime($obj->witness_sig_time);
    $obj->witness_sig_time($date);
    $update_stmt->bind_param($i++, $obj->witness_sig_time, SQL_VARCHAR);

    $update_stmt->bind_param($i++, $obj->system_config_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->tag, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->note, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->run_id );
}

 sub create_object {
   my $self = shift;
   my $id = shift;
   my $obj = new RSTF::DB::Run(run_id => $id)->fetch();
   return $obj;
 }

sub get_fetchall_sql {
    return q{SELECT run_id FROM Run};
}

sub get_find_by_name_sql {
    my $self = shift;
    my $date = shift;
    my $testcase_id = shift;
    die "Unable to find Run by name without a testcase_id" unless($testcase_id);

    $date = format_datetime($date);
    return qq{Select run_id FROM Run  where time_start = '$date' and testcase_id=$testcase_id};
}

1;
