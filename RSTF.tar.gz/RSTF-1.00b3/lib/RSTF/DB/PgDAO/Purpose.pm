###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Purpose.pm
# 
# Created by: Robert A. Ballance		Mon May 24 11:10:24 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Purpose.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  DAO accessor for the TestType table. All the work happens in the
#  TypeTable base class.
# 
###############################################################################
package RSTF::DB::PgDAO::Purpose;

use strict;

use  RSTF::DB::Purpose;
use RSTF::DB::PgDAO::DAO;


use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'Purpose',
		 serial_column => 'purpose_id',
		 nested_object_fields => [],
		 scalar_db_fields => [qw( name description)]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
  }

sub create_object {
  my $self = shift;
  my ($id,$name) = @_;
  my $obj = new RSTF::DB::Purpose (purpose_id => $id, name => $name);
  return $obj;
}

sub get_fetch_sql {
  return q{SELECT * from Purpose where purpose_id = ?};
}


sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $purpose = shift;
  $fetch_stmt->bind_param(1, $purpose->purpose_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{
	   INSERT INTO Purpose(purpose_id, name,description)
	       VALUES(?,?,?)
	  };
};

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $purpose = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $purpose->purpose_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $purpose->name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $purpose->description, SQL_VARCHAR);
}

sub get_update_sql {
    return q{
	     UPDATE Purpose SET
	     name = ?,
	     description = ?
	     WHERE purpose_id = ?
	    };
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $purpose = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $purpose->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $purpose->description, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $purpose->purpose_id);
}

sub get_delete_sql {
  return q{  DELETE FROM Purpose where purpose_id = ? };
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $purpose = shift;
    $delete_stmt->bind_param(1, $purpose->purpose_id, SQL_INTEGER);
}


sub get_fetchall_sql {
  return q{Select purpose_id FROM Purpose };
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select purpose_id FROM Purpose where name  = '$name'};
}

1;
