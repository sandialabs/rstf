###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Grade.pm
# 
# Created by: Robert A. Ballance		Mon May 17 11:08:25 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Grade.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::PgDAO::Grade;
use strict;

use RSTF::DB::PgDAO::DAO;

use RSTF::DB::Grade;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'Grade',  
		 scalar_db_fields=> [ qw(grade_id name description mnemonic value)],
		 nested_object_fields=>[]
		);

sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}

sub get_fetch_sql {
  return q{SELECT * from Grade where grade_id = ?};
}


sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $grade = shift;
  $fetch_stmt->bind_param(1, $grade->grade_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{
	   INSERT INTO Grade(grade_id, name,description,value, mnemonic)
	       VALUES(?,?,?,?,?)
	  };
};

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $grade = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $grade->grade_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $grade->name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $grade->description, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $grade->value, SQL_FLOAT);
    $insert_stmt->bind_param($i++, $grade->mnemonic, SQL_CHAR);
}

sub get_update_sql {
    return q{
	     UPDATE Grade SET
	     name = ?,
	     description = ?,
	     value = ?,
	     mnemonic = ?
	     WHERE grade_id = ?
	    };
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $grade = shift;

    my $i = 1;
    $update_stmt->bind_param($i++, $grade->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $grade->description, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $grade->value, SQL_FLOAT);
    $update_stmt->bind_param($i++, $grade->mnemonic, SQL_CHAR);
    $update_stmt->bind_param($i++, $grade->grade_id);
}

sub get_delete_sql {
  return q{  DELETE FROM Grade where grade_id = ? };
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $grade = shift;
    $delete_stmt->bind_param(1, $grade->grade_id, SQL_INTEGER);
}

sub create_object {
  my $self = shift;
  my $id = shift;
  my $obj = new RSTF::DB::Grade(grade_id => $id)->fetch();
  return $obj;
}

sub get_fetchall_sql {
  return q{Select grade_id FROM Grade };
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    return qq{Select grade_id FROM Grade where mnemonic = '$name'};
}


1;
