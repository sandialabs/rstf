###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestType.pm
# 
# Created by: Robert A. Ballance		Wed Mar 17 10:52:18 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/TestType.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  DAO accessor for the TestType table. All the work happens in the
#  TypeTable base class.
# 
###############################################################################
package RSTF::DB::PgDAO::TestType;

use strict;

use  RSTF::DB::TestType;

use RSTF::DB::PgDAO::TypeTable;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::TypeTable);

my @init_args = (table => 'TestType',
		 name => 'name',
		 serial_column => 'test_type_id',
		 scalar_db_fields => [qw( name )]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}

sub create_object {
  my $self = shift;
  my ($id, $name) = @_;
  my $obj = new RSTF::DB::TestType (test_type_id => $id, name => $name);
  unless ($name) {
      $obj->fetch();
  }
  return $obj;
}


1;
