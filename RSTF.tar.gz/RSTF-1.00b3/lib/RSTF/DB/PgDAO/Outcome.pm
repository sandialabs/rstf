###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Outcome.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 14:16:11 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Outcome.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################
package RSTF::DB::PgDAO::Outcome;

use strict;

use  RSTF::DB::Outcome;

use RSTF::DB::PgDAO::TypeTable;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::TypeTable);


my @init_args = (table => 'Outcome',
		 name => 'name',
		 serial_column => 'outcome_id',
		 scalar_db_fields => [qw( name )]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}

sub create_object {
  my $self = shift;
  my ($id,$name) = @_;
  my $obj = new RSTF::DB::Outcome (outcome_id => $id, name => $name);
  return $obj;
}

1;
