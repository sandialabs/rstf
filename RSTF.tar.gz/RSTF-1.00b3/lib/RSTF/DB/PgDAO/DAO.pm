###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DAO.pm
# 
# Created by: Robert A. Ballance		Mon Mar 15 11:54:51 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/DAO.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
#  Fundamental Data Access Object for the system.
#  it uses a number of abstract methods that have to be supplied by the
#  derived classes:
# 
###############################################################################

package RSTF::DB::PgDAO::DAO;;

use strict;
use warnings;

use DBI qw(:sql_types);
use RSTF::DB::StmtFactory;
use RSTF::Configuration;

use RSTF::DB::DAO;
use vars qw(@ISA);
@ISA = qw(RSTF::DB::DAO);

sub init {
  my $self = shift;
  $self->SUPER::init(scalar_db_fields=>undef, stmt_factory=>new RSTF::DB::StmtFactory(), @_);
  die "No table name specified" unless ($self->table);
  return $self;
}


#####
sub finalize_fetch { 
  # EMPTY -- override in subclass for cool stuff
}


sub get_insert_stmt {
  #note - this passes 'self' to the factory's get_insert_stmt
  return $_[0]->stmt_factory()->get_insert_stmt(@_);

}

sub get_fetch_stmt {
  #note - this passes 'self' to the factory's get_fetch_stmt
  return $_[0]->stmt_factory()->get_fetch_stmt(@_);

}

sub get_fetchall_stmt {
  #note - this passes 'self' to the factory's get_fetchall_stmt
  return $_[0]->stmt_factory()->get_fetchall_stmt(@_);

}

sub get_update_stmt {
  #note - this passes 'self' to the factory's get_update_stmt
  return $_[0]->stmt_factory()->get_update_stmt(@_);
}

sub get_delete_stmt {
  #note - this passes 'self' to the factory's get_delete_stmt
  return $_[0]->stmt_factory()->get_delete_stmt(@_);

}


sub get_delete_all_stmt {
  #note - this passes 'self' to the factory's get_fetchall_stmt
  return $_[0]->stmt_factory()->get_delete_all_stmt(@_);

}


sub complete_fetch {
  my $self = shift;
  my $db_hashref = shift;
  my $obj = shift;
  my $scalar_db_fields = $self->scalar_db_fields();
  foreach my $field (@$scalar_db_fields) {
    # Only assign to undefined fields.
    # This means that fetch will  not override
    # existing values.
    if (!defined($obj->$field())) {
      $obj->$field($db_hashref->{$field});
    }
}
    $self->finalize_fetch($db_hashref, $obj);
}


sub fetch {
    my $self = shift;
    my $obj = shift;
#  my @args = @_;
    my $where  = shift;

    my $serial_col = $self->serial_column();
    if ($serial_col && !defined($obj->$serial_col)) {
	return $obj;
    }

    unless (RSTF::DB::DAOFactory::is_connected()) {
	return $obj;
    }

    die "fetch " . ref($self) . "No DBH specified" unless ($self->db);

    my $stmt = $self->get_fetch_stmt(@_);

    $obj->prepare_fetch($where);

    $self->bind_fetch_stmt($stmt, $obj);

    my $rv = $stmt->execute() or die $stmt->errstr;

    if ($rv) {
	my $hr = $stmt->fetchrow_hashref();

	# This code fragment assumes that each column in the query
	# has the identically named key in the object.
	# Naturally, this is a worrisome assumption.
	if ($hr) {
	    $self->complete_fetch($hr, $obj);
	    my $nested_objects = $self->nested_object_fields;
	    foreach my $field (@$nested_objects) { 
		my $nested_obj = $obj->$field;
		if ($nested_obj) {
		    $nested_obj->fetch();
		}
	    }
	} else {
	    if ($serial_col) {
		die  ref($self) . ": No values fetched (1)! where = $where, id = " . $obj->$serial_col;
	    } else {
		return undef;
	    }
	}
    } else {
	if ($serial_col) {
	    die  ref($self) . ": No values fetched (2)! where = $where, id = " . $obj->$serial_col;
	} else {
	    return undef;
	}
    }
    return $obj;
}

# Fetch all
sub fetch_all {
  my $self = shift;
  my $where = shift;

  die "fetch_all " . ref($self) . "No DBH specified" unless ($self->db);

  my $stmt = $self->get_fetchall_stmt($where);

  if ($stmt) {
      my @results = ();
      my $rv = $stmt->execute() or die $stmt->errstr;      
      if ($rv) {
	  my $result;
	  while ($result = $stmt->fetchrow_arrayref()) {
	      if ($result->[0]) {
		  my $obj = $self->create_object(@$result);
		  push @results, $obj;
	      }
	  }
      } else {
	  die "No values fetched!";
      }
#    $stmt->finish();
      return \@results;
  }
  return undef;
}

sub insert {
  my $self = shift;
  my $obj = shift;

  die "insert " . ref($self) . "No DBH specified" unless ($self->db);

  my $stmt = $self->get_insert_stmt();

  $obj->prepare_insert();

  $self->bind_insert_stmt($stmt, $obj);

  my $rv = $stmt->execute() or die $stmt->errstr;

  my $id = $self->get_id();
  my $method = $self->serial_column;
  if ($method) {
      $obj->$method($id);
  }
  my $nested_objects = $self->nested_object_fields;
  # bob?
  $obj->update_child_keys();
  foreach my $field (@$nested_objects) { 
      my $nested_obj = $obj->$field;
      if ($nested_obj) {
	  $nested_obj->insert();
      }
  }
  return $obj;
}


sub update {
  my $self = shift;
  my $obj = shift;
  die "update  " . ref($self) . "No DBH specified" unless ($self->db);
  my $stmt = $self->get_update_stmt();

  $obj->prepare_update();

  $self->bind_update_stmt($stmt, $obj);
  my $rv = $stmt->execute() or die $stmt->errstr;
  if ($rv) {
    my $nested_objects = $self->nested_object_fields;
    foreach my $field (@$nested_objects) { 
      my $nested_obj = $obj->$field;
      if ($nested_obj) {
	$nested_obj->update();
      }
    }
  }
#  $stmt->finish();
  return undef;
}

sub delete {
  my $self = shift;
  my $obj = shift;
  die "delete " . ref($self) . "No DBH specified" unless ($self->db);

  my $delete_stmt = $self->get_delete_stmt();
  $self->bind_delete_stmt($delete_stmt, $obj);
  $obj->prepare_update();
  my $rv = $delete_stmt->execute() or die $delete_stmt->errstr;
  # Nested object fields get deleted automatically via cascading deletes!
#  $delete_stmt->finish();
  return $rv;
}

sub delete_all {
  my $self = shift;
  my $where = shift;

  die "delete_all " . ref($self) . "No DBH specified" unless ($self->db);

  my $delete_stmt = $self->get_delete_all_stmt($where);
  my $rv = $delete_stmt->execute() or die $delete_stmt->errstr;
  # Nested object fields get deleted automatically via cascading deletes!
#  $delete_stmt->finish();
  return $rv;
}


my $id_stmt;
sub get_id {
  my $self = shift;
  if ($self->serial_column) {
    unless ($id_stmt) {
      $id_stmt = $self->db->prepare(q{
				      Select currval(?)
				     });
    }
    my $sequence_name = sprintf("%s_%s_seq", $self->table, $self->serial_column);
    $id_stmt->bind_param(1, $sequence_name, SQL_VARCHAR);
    my $rv = $id_stmt->execute() or die $id_stmt->errstr;
    my ($id) = $id_stmt->fetchrow_array();
    return $id;
  }
  return undef;
}

sub execute_lookup {
  my $self = shift;
  my  $sql = shift;
  my $dbh = $self->db();
  my $sth = $dbh->prepare($sql) or die $dbh->errstr;
  $sth->execute() or die $sth->errstr;
  my ($id) = $sth->fetchrow_array();
  return $id;
}

sub find_by_name {
    my $self = shift;
    my @args = @_;
    die "No name specified in find_by_name" unless (@args);

    # I know that if I am here, we are connected to the DB.
    # First try the cached values.
    # This will fail (kindly) if the cache does not exist
    # or if the value is not in the cache.

    my $config = new RSTF::Configuration;
    
    my $result;
    unless ($config->database_ignore_cache) {
	$result = $self->find_cached_name(@args);
    }
    unless ($result) {
	my $sql = $self->get_find_by_name_sql(@args);
	die ref($self) . "Find by name not implemented --- no SQL string" unless ($sql);
	if ($sql) {
	    my $id = $self->execute_lookup($sql);
	    if ($id) {
		return $self->create_object($id);
	    }
	    return undef;
	}
    }
    return $result;
}

sub create_object {
    my $self = shift;
    my $id = shift;
    my $serial_col = $self->serial_column;
    my $class_name= $self->object_class;
    die "No class name specified in created object for " . ref($self) . "\n" unless ($class_name);
    return eval "new $class_name($serial_col => $id)->fetch()";
}

# For once, the SQL can be common.
sub get_delete_all_sql {
    my $self = shift;
    my $table = $self->table;
    return qq{DELETE FROM $table };
}

1;
