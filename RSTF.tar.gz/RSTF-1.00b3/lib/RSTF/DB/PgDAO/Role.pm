###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Role.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Role.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Role;

use strict;

use  RSTF::DB::Role;

use RSTF::DB::PgDAO::TypeTable;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PgDAO::TypeTable);

my @init_args = (table => 'Role',
		 name => 'role',
		 serial_column => 'role_id',
		 scalar_db_fields => [qw( role )]
);

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}

sub create_object {
  my $self = shift;
  my ($id, $name) = @_;
  my $obj = new RSTF::DB::Role (role_id => $id, role => $name);
  unless ($name) {
      $obj->fetch();
  }
  return $obj;
}


1;
