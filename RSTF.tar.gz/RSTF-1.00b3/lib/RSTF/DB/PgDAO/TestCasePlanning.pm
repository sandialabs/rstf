###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestCasePlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/TestCasePlanning.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::TestCasePlanning;
use strict;

use  RSTF::DB::TestCasePlanning;

use RSTF::DB::PgDAO::DAO;
use RSTF::DB::Utils qw(:dates);
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'TestCasePlanning',
		 serial_column => 'testcase_plan_id',
		 object_class=>'RSTF::DB::TestCasePlanning',
		 scalar_db_fields => [qw(
					 testcase_id
					 data_set_on_hand	
					 inputs_prepared	
					 sample_scripts_available	
					 rst_scripts_written	
					 rst_scripts_tested	
					 preliminary_runs_scheduled	
					 preliminary_runs_complete	
					 final_runs_scheduled	
					 final_runs_complete
					 )]
		 );


sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM TestCasePlanning WHERE testcase_plan_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->testcase_plan_id, SQL_INTEGER);
}


sub get_delete_sql {
    return q{DELETE  FROM TestCasePlanning WHERE testcase_plan_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->testcase_plan_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO TestCasePlanning(testcase_id,
					  data_set_on_hand,
					  inputs_prepared,
					  sample_scripts_available,
					  rst_scripts_written,
					  rst_scripts_tested,
					  preliminary_runs_scheduled,
					  preliminary_runs_complete,
					  final_runs_scheduled,
					  final_runs_complete) VALUES(?,?,
								      ?,
								      ?,
								      ?,
								      ?,
								      ?,
								      ?,
								      ?,
								      ?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    my $date;
    $insert_stmt->bind_param($i++, $obj->testcase_id, SQL_INTEGER);
    # Fix date for data_set_on_hand
    $date = $obj->data_set_on_hand();
    $obj->data_set_on_hand(format_date($date));
    $insert_stmt->bind_param($i++, $obj->data_set_on_hand, SQL_VARCHAR);
    # Fix date for inputs_prepared
    $date = $obj->inputs_prepared();
    $obj->inputs_prepared(format_date($date));
    $insert_stmt->bind_param($i++, $obj->inputs_prepared, SQL_VARCHAR);
    # Fix date for sample_scripts_available
    $date = $obj->sample_scripts_available();
    $obj->sample_scripts_available(format_date($date));
    $insert_stmt->bind_param($i++, $obj->sample_scripts_available, SQL_VARCHAR);
    # Fix date for rst_scripts_written
    $date = $obj->rst_scripts_written();
    $obj->rst_scripts_written(format_date($date));
    $insert_stmt->bind_param($i++, $obj->rst_scripts_written, SQL_VARCHAR);
    # Fix date for rst_scripts_tested
    $date = $obj->rst_scripts_tested();
    $obj->rst_scripts_tested(format_date($date));
    $insert_stmt->bind_param($i++, $obj->rst_scripts_tested, SQL_VARCHAR);
    # Fix date for preliminary_runs_scheduled
    $date = $obj->preliminary_runs_scheduled();
    $obj->preliminary_runs_scheduled(format_date($date));
    $insert_stmt->bind_param($i++, $obj->preliminary_runs_scheduled, SQL_VARCHAR);
    # Fix date for preliminary_runs_complete
    $date = $obj->preliminary_runs_complete();
    $obj->preliminary_runs_complete(format_date($date));
    $insert_stmt->bind_param($i++, $obj->preliminary_runs_complete, SQL_VARCHAR);
    # Fix date for final_runs_scheduled
    $date = $obj->final_runs_scheduled();
    $obj->final_runs_scheduled(format_date($date));
    $insert_stmt->bind_param($i++, $obj->final_runs_scheduled, SQL_VARCHAR);
    # Fix date for final_runs_complete
    $date = $obj->final_runs_complete();
    $obj->final_runs_complete(format_date($date));
    $insert_stmt->bind_param($i++, $obj->final_runs_complete, SQL_VARCHAR);
}

sub get_update_sql {
    return q{UPDATE TestCasePlanning SET
		 testcase_id=?,
		 data_set_on_hand = ?,
		 inputs_prepared = ?,
		 sample_scripts_available = ?,
		 rst_scripts_written = ?,
		 rst_scripts_tested = ?,
		 preliminary_runs_scheduled = ?,
		 preliminary_runs_complete = ?,
		 final_runs_scheduled = ?,
		 final_runs_complete = ? 
		 WHERE testcase_plan_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;
    my $date;
    $update_stmt->bind_param($i++, $obj->testcase_id );
    # Fix date for data_set_on_hand
    $date = $obj->data_set_on_hand();
    $obj->data_set_on_hand(format_date($date));
    $update_stmt->bind_param($i++, $obj->data_set_on_hand, SQL_VARCHAR);
    # Fix date for inputs_prepared
    $date = $obj->inputs_prepared();
    $obj->inputs_prepared(format_date($date));
    $update_stmt->bind_param($i++, $obj->inputs_prepared, SQL_VARCHAR);
    # Fix date for sample_scripts_available
    $date = $obj->sample_scripts_available();
    $obj->sample_scripts_available(format_date($date));
    $update_stmt->bind_param($i++, $obj->sample_scripts_available, SQL_VARCHAR);
    # Fix date for rst_scripts_written
    $date = $obj->rst_scripts_written();
    $obj->rst_scripts_written(format_date($date));
    $update_stmt->bind_param($i++, $obj->rst_scripts_written, SQL_VARCHAR);
    # Fix date for rst_scripts_tested
    $date = $obj->rst_scripts_tested();
    $obj->rst_scripts_tested(format_date($date));
    $update_stmt->bind_param($i++, $obj->rst_scripts_tested, SQL_VARCHAR);
    # Fix date for preliminary_runs_scheduled
    $date = $obj->preliminary_runs_scheduled();
    $obj->preliminary_runs_scheduled(format_date($date));
    $update_stmt->bind_param($i++, $obj->preliminary_runs_scheduled, SQL_VARCHAR);
    # Fix date for preliminary_runs_complete
    $date = $obj->preliminary_runs_complete();
    $obj->preliminary_runs_complete(format_date($date));
    $update_stmt->bind_param($i++, $obj->preliminary_runs_complete, SQL_VARCHAR);
    # Fix date for final_runs_scheduled
    $date = $obj->final_runs_scheduled();
    $obj->final_runs_scheduled(format_date($date));
    $update_stmt->bind_param($i++, $obj->final_runs_scheduled, SQL_VARCHAR);
    # Fix date for final_runs_complete
    $date = $obj->final_runs_complete();
    $obj->final_runs_complete(format_date($date));
    $update_stmt->bind_param($i++, $obj->final_runs_complete, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->testcase_plan_id );
}

sub get_find_by_name_sql {
    my $self = shift;
    my $testcase_id = shift;
    my $sql =  qq{Select testcase_plan_id FROM TestCasePlanning WHERE
		      testcase_id=$testcase_id};
    return $sql;
}

1;
