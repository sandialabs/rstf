###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Machine.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Machine.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Machine;
use strict;

use  RSTF::DB::Machine;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);


my @init_args = (table => 'Machine',
		 serial_column => 'machine_id',
		 object_class => 'RSTF::DB::Machine',
		 scalar_db_fields => [qw(

					 platform_id	
					 machine_name	
					 classified                        )]
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM Machine WHERE machine_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->machine_id, SQL_INTEGER);
}

sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift; # hash of values returned from a fetch query.
    my $obj = shift;


}

sub get_delete_sql {
    return q{DELETE  FROM Machine WHERE machine_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->machine_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO Machine(platform_id,
				 machine_name,
				 classified) VALUES(?,
						    ?,
						    ?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->machine_name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->classified);
}

sub get_update_sql {
    return q{UPDATE Machine SET platform_id = ?,
	     machine_name = ?,
	     classified = ? 
		 WHERE machine_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->machine_name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->classified);
    $update_stmt->bind_param($i++, $obj->machine_id, SQL_INTEGER );
}

sub get_fetchall_sql {
  return q{Select machine_id FROM Machine };
}

sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    my $platform_id = shift;
    return qq{Select machine_id FROM Machine where machine_name = '$name' and platform_id=$platform_id};
}

sub create_object {
  my $self = shift;
  my $id = shift;
  my $obj = new RSTF::DB::Machine(machine_id => $id)->fetch();
  return $obj;
}

1;
