###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DBConnect.pm
# 
# Created by: Robert A. Ballance		Fri Jan 16 15:30:07 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/DBConnect.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
#  Fundamental database connector for various perl scripts
# 
#  Underlying implementation is smart enough to consult .pgpass for
# a password if you don't supply one.
# 
###############################################################################

package RSTF::DB::PgDAO::DBConnect;
use RSTF::Configuration;

use DBI;
use strict;
use warnings;

my %attr = (
	    PrintError => 1,
	    RaiseError => 0 );

use Class::MethodMaker
    get_set => [qw(dbh verbose)],
    new_with_init => 'new' ;

sub init {
    my $self = shift;
    my %args = @_;
    
    my $config = new RSTF::Configuration();
    
    my $pw = $args{password} || $config->database_pw();
    my $db = $args{db} || $config->database_name;
    my $user = $args{user} || $config->database_user; 
    my $host = $args{host} || $config->database_host;
    my $port = $args{port} || $config->database_port;
    
    my $url = sprintf("dbi:Pg:dbname=%s;host=%s;port=%d;",
		      $db, $host, $port);
    
    my $dbh = DBI->connect($url, $user, $pw,
			   {PrintError => 1,
			    RaiseError => 1}) or die "Unable to connect!";
    if ($dbh) {
	$dbh->{RaiseError} = 1;
	$self->dbh($dbh);
	$self->verbose(1);
    } else {
	die "Connection failed\n";
    }
}

sub execute {
  my $self = shift;
  my  $sql = shift;
  my $dbh = $self->dbh();
  if ($self->verbose) {
    print "Execute: $sql\n";
  }
  my $sth = $dbh->prepare($sql);
  $sth->execute() || die $sth->errstr;

}

sub execute_query {
  my $self = shift;
  my  $sql = shift;
  my $dbh = $self->dbh();
  my $sth = $dbh->prepare($sql);
  if ($self->verbose) {
    print "Execute: $sql\n";
  } 
  $sth->execute() || die $sth->errstr;
  if (my @row = $sth->fetchrow_array()) {
    return $row[0];
  }
  return undef;
}

my %app_index;

sub find_app {
  my $self = shift;
  my $appname = shift;

  unless ($app_index{$appname}) {
    $app_index{$appname} = $self->execute_query("Select app_id from Application where name='$appname'");
  }
  my $app_id = $app_index{$appname};
  if ($self->verbose()) {
    print "App id for $appname is $app_id\n";
  }
  return $app_id;
}

sub find_platform {
  my $self = shift;
  my $name = shift;
  my $result = $self->execute_query("Select platform_id from Platform where name='$name'");
  return $result or die "Unable to find Platform named $name";
}


sub find_role {
  my $self = shift;
  my $rolename = shift;
  my $result = $self->execute_query("Select role_id from Role where role='$rolename'");
  return $result or die "Unable to find Role named $rolename";
}

my %test_type_index;
sub find_test_type {
  my $self = shift;
  my $test_typename = shift;
  unless ($test_type_index{$test_typename}) {
    $test_type_index{$test_typename} = $self->execute_query("Select test_type_id from TestType where name='$test_typename'");  }
  my $id = $test_type_index{$test_typename};
  die "No id for $test_typename" unless defined($id);
  if ($self->verbose()) {
    print "Test type id for $test_typename is $id\n";
  }
  return $id;
}

my %status_index;
sub find_benchmark_state {
  my $self = shift;
  my $name = shift;

  unless ($status_index{$name}) {
    $status_index{$name} = $self->execute_query("Select benchmark_state_id from BenchmarkState where name='$name'");
  }
  my $id = $status_index{$name};
  if ($self->verbose()) {
    print "Id for status $name is $id\n";
  }
  return $id;
}

sub get_serial {
  my $self = shift;
  my  $table = shift;
  my  $column = shift;
  my $sequence_name = sprintf("%s_%s_seq", $table, $column);
  my $result = $self->execute_query("Select currval('$sequence_name')");
  return $result or die "Unable to find value for $sequence_name";
}

sub do_insert {
  my $self = shift;
  my  $table = shift;
  my  $id_column = shift;
  my $cols = shift;
  my $values = shift;

  my $dbh = $self->dbh();
  my $sql = "INSERT INTO $table($cols) VALUES($values)";
  if ($self->verbose()) {
    print "INSERT: $sql\n";
  }
  my $sth = $dbh->prepare($sql);
  $sth->execute() || die $sth->errstr;
  if ($id_column && $id_column ne '') {
    return $self->get_serial($table, $id_column);
  } else {
    return undef;
  }
}

# Always disconnect from the database if a database handle is setup
DESTROY {
  my $self = shift;
  my $dbh = $self->dbh();
  if ($dbh) {
      eval {
	  $dbh->disconnect() if $dbh;
      };
  }
}

1;
