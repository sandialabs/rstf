###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DAOFactory.pm
# 
# Created by: Robert A. Ballance		Thu Apr 22 12:23:37 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/DAOFactory.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PgDAO::DAOFactory;
use strict;
use warnings;
use RSTF::Configuration;
use RSTF::DB::PgDAO::DBConnect;
use RSTF::DB::DAOFactory;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::DAOFactory);

my %dao_cache;

my %dao_map = (
	       'RSTF::DB::EnvPath' => 'RSTF::DB::PgDAO::EnvironmentSetting',
	       'RSTF::DB::EnvVar' => 'RSTF::DB::PgDAO::EnvironmentSetting',
	       'RSTF::Exec::QueueCommand' => 'RSTF::DB::PgDAO::Command',
	       'RSTF::Exec::GradedCommand' => 'RSTF::DB::PgDAO::Command',
	       'RSTF::Exec::DiskAllocator' => 'RSTF::DB::PgDAO::OutputDirectory'
);



my $factory;

# package method?
sub new {
    my $self = shift;
    my $config = new RSTF::Configuration();
    unless ($factory) {
	my $connection = new RSTF::DB::PgDAO::DBConnect();
	my $db = $connection->dbh();
	die "Unable to connect to database " unless ($connection && $db);
	$factory =  $self->SUPER::_init_hash(db_connection=>$connection, db=>$db);
	if (defined($config->database_dbi_trace)) {
	    DBI->trace($config->database_dbi_trace);
	}
    }
    return $factory;
}


sub is_connected {
    my $self = shift;
    return defined($self->db_connection());
}


# Takes a class name, and returns its DAO
sub do_find_dao {
    my $self = shift;
    my $class_name = shift;

    my @class_path = split('::', $class_name);
    my $basename = pop @class_path;
    my $dao = $dao_cache{$class_name};
    if ($dao) {
	return $dao;
    }
    
    # Here if DAO has not been created yet.
    
    # Check map first
    my $dao_class = $dao_map{$class_name};
    unless ($dao_class) {
	#not in map -- create a reasonable name
	$dao_class = sprintf('RSTF::DB::PgDAO::%s', $basename);
    }

    eval "require $dao_class";
    if ($@) {
	die $@;
    }
    
    eval {
	$dao = $dao_class->new(db=>$self->db);
    };
    if ($@) {
	die $@;
    }

    die "New DAO failed for $dao_class" unless ($dao);
    $dao_cache{$class_name} = $dao;
    $dao->classname($class_name);
    return $dao;
}

1;
