###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# ApplicationPlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/ApplicationPlanning.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::ApplicationPlanning;
use strict;

use  RSTF::DB::ApplicationPlanning;
use  RSTF::DB::Utils qw(:dates);

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'ApplicationPlanning',
		  serial_column => undef,
		  object_class=>'RSTF::DB::ApplicationPlanning',
		  scalar_db_fields => [qw(
					  app_id	
					  platform_id	
					  version	
					  ported_serial	
					  ported_parallel	
					  ported_serial_by_id	
					  ported_parallel_by_id	
					  needs_validation	
					  validated	
					  validated_by_id	
					  ready
					  )]
);


sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
  }


sub get_fetch_sql {
    return q{SELECT * FROM ApplicationPlanning WHERE app_id=? and platform_id=?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;

  $fetch_stmt->bind_param(1, $obj->app_id, SQL_INTEGER);
  $fetch_stmt->bind_param(2, $obj->platform_id, SQL_INTEGER);
}

sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift; # hash of values returned from a fetch query.
  my $obj = shift;
}

sub get_delete_sql {
  return q{DELETE  FROM ApplicationPlanning WHERE app_id=? and platform_id=?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->app_id, SQL_INTEGER);
    $delete_stmt->bind_param(2, $obj->platform_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO ApplicationPlanning(app_id,
					   platform_id,
					   version,
					   ported_serial,
					   ported_parallel,
					   ported_serial_by_id,
					   ported_parallel_by_id,
					   needs_validation,
					   validated,
					   validated_by_id,
					   ready) VALUES(?,?,?,?,?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
  my $self = shift;
  my $insert_stmt = shift;
  my $obj = shift;
  my $date;

  my $i = 1;
  $insert_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->version, SQL_VARCHAR);
  $date = $obj->ported_serial();
  $obj->ported_serial(format_date($date));
  $insert_stmt->bind_param($i++, $obj->ported_serial);

  $date = $obj->ported_parallel();
  $obj->ported_parallel(format_date($date));
  $insert_stmt->bind_param($i++, $obj->ported_parallel);

  $insert_stmt->bind_param($i++, $obj->ported_serial_by_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->ported_parallel_by_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->needs_validation);
  $insert_stmt->bind_param($i++, $obj->validated);
  $insert_stmt->bind_param($i++, $obj->validated_by_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->ready);
}

sub get_update_sql {
    return q{UPDATE ApplicationPlanning SET app_id = ?,
	     platform_id = ?,
	     version = ?,
	     ported_serial = ?,
	     ported_parallel = ?,
	     ported_serial_by_id = ?,
	     ported_parallel_by_id = ?,
	     needs_validation = ?,
	     validated = ?,
	     validated_by_id = ?,
	     ready = ? 
	     WHERE app_id=? and platform_id=?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;
    my $date;

    $update_stmt->bind_param($i++, $obj->app_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->version, SQL_VARCHAR);
    $date = $obj->ported_serial();
    $obj->ported_serial(format_date($date));
    $update_stmt->bind_param($i++, $obj->ported_serial);

    $date = $obj->ported_parallel();
    $obj->ported_parallel(format_date($date));
    $update_stmt->bind_param($i++, $obj->ported_parallel);

    $update_stmt->bind_param($i++, $obj->ported_serial_by_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->ported_parallel_by_id, SQL_INTEGER);

    $update_stmt->bind_param($i++, $obj->needs_validation);
    $update_stmt->bind_param($i++, $obj->validated);
    $update_stmt->bind_param($i++, $obj->validated_by_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->ready);
    $update_stmt->bind_param($i++, $obj->app_id );
    $update_stmt->bind_param($i++, $obj->platform_id );
}

1;
