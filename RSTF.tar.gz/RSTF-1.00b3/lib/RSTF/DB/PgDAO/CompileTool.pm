###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# CompileTool.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/CompileTool.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::CompileTool;
use strict;

use  RSTF::DB::CompileTool;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);


my @init_args = (table => 'CompileTool',
		 object_class => 'RSTF::DB::CompileTool',
		 serial_column => 'tool_id',
		 scalar_db_fields => [qw(

					 platform_id	
					 vendor_id	
					 name	
					 language	
					 version
					 output_parser)]
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM CompileTool WHERE tool_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->tool_id, SQL_INTEGER);
}

sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift; # hash of values returned from a fetch query.
    my $obj = shift;


}

sub get_delete_sql {
    return q{DELETE  FROM CompileTool WHERE tool_id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->tool_id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO CompileTool(platform_id,
				     vendor_id,
				     name,
				     language,
				     output_parser,
				     version) VALUES(?,?,?,?,?, ?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->vendor_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->language, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->output_parser, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->version, SQL_VARCHAR);
}

sub get_update_sql {
    return q{UPDATE CompileTool SET platform_id = ?,
	     vendor_id = ?,
	     name = ?,
	     language = ?,
	     output_parser=?,
	     version = ? 
		 WHERE tool_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->vendor_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->language, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->output_parser, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->version, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->tool_id );
}

# this function is overloaded to use the version_id if possible,
# and it otherwise looks ujp 
sub get_find_by_name_sql {
    my $self = shift;
    my $name = shift;
    my $platform_id= shift;
    my $version = shift;
    my $sql;
    if ($version) {
	$sql =  qq{Select tool_id from CompileTool where name='$name' and platform_id=$platform_id and version='$version'};
    } else {
	$sql =  qq{Select tool_id from CompileTool where name='$name' and platform_id=$platform_id and version is null};
    }
    return $sql;
}

sub create_object {
  my $self = shift;
  my $id = shift;
  return new RSTF::DB::CompileTool(tool_id => $id)->fetch();
}

1;
