###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# BuildInfo.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/BuildInfo.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::BuildInfo;
use strict;

use  RSTF::DB::BuildInfo;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);


use DBI qw(:sql_types);


my @init_args = (table => 'BuildInfo',
		 serial_column => 'id',
		 scalar_db_fields => [qw(

					 executable_id	
					 tool_id	
					 raw_flags	
					 expanded_flags	
					 filename	
					 directory	
					 ordinal                        )]
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM BuildInfo WHERE id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    $fetch_stmt->bind_param(1, $obj->id, SQL_INTEGER);
}

sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift; # hash of values returned from a fetch query.
    my $obj = shift;


}

sub get_delete_sql {
    return q{DELETE  FROM BuildInfo WHERE id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO BuildInfo(executable_id,
				   tool_id,
				   raw_flags,
				   expanded_flags,
				   filename,
				   directory,
				   ordinal) VALUES(?,
						   ?,
						   ?,
						   ?,
						   ?,
						   ?,
						   ?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->executable_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->tool_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->raw_flags, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->expanded_flags, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->filename, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->directory, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->ordinal, SQL_INTEGER);
}

sub get_update_sql {
    return q{UPDATE BuildInfo SET executable_id = ?,
	     tool_id = ?,
	     raw_flags = ?,
	     expanded_flags = ?,
	     filename = ?,
	     directory = ?,
	     ordinal = ? 
		 WHERE id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->executable_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->tool_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->raw_flags, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->expanded_flags, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->filename, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->directory, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->ordinal, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->id );
}

1;
