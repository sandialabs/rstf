###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Command.pm
# 
# Created by: Robert A. Ballance		Fri Apr 16 16:18:03 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Command.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PgDAO::Command;
use strict;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

use  RSTF::DB::Command;
use  RSTF::Exec::Dispatch;

my @init_args = (table => 'Command',
		 serial_column => 'command_id',
		 object_class => 'RSTF::DB::Command',
		 scalar_db_fields => [qw(
					 type_id	
					 testcase_id	
					 description	
					 executable
					 arguments	
					 stdin	
					 stdout	
					 stderr	
					 working_directory	
					 install_directory	
					 failure_ok	
					 ordinal	
					)]
		);

sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
  return q{SELECT * FROM Command WHERE command_id = ?};
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;
  $fetch_stmt->bind_param(1, $obj->command_id, SQL_INTEGER);
}

sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift;	# hash of values returned from a fetch query.
  my $obj = shift;

  my $dispatch = new RSTF::Exec::Dispatch(
					 name => $db_hashref->{dispatch_name},
					 procs => $db_hashref->{dispatch_procs},
					 arguments => $db_hashref->{dispatch_args},
					 mode => $db_hashref->{dispatch_mode},
					 max_time => $db_hashref->{dispatch_max_time},
					 job_queue => $db_hashref->{dispatch_job_queue}
					 );
  
  $obj->dispatch($dispatch);
}

sub get_fetchall_sql {
  return q{Select command_id FROM Command };
}

# sub create_object {
#   my $self = shift;
#   my ($id) = @_;
#   my $obj = new RSTF::DB::Command(command_id => $id)->fetch();
#   return $obj;
# }

sub get_delete_sql {
  return q{DELETE  FROM Command WHERE command_id = ?};
}

sub bind_delete_stmt{
  my $self = shift;
  my $delete_stmt = shift;
  my $obj = shift;
  $delete_stmt->bind_param(1, $obj->command_id, SQL_INTEGER);
}


sub get_insert_sql {
  return q{INSERT INTO Command(type_id,
 			       testcase_id,
 			       description,
 			       executable,
			       arguments,
 			       stdin,
 			       stdout,
 			       stderr,
			       working_directory,
 			       install_directory,
 			       failure_ok,
			       ordinal,
 			       dispatch_name,
 			       dispatch_args,
 			       dispatch_mode,
 			       dispatch_procs,
			       dispatch_max_time,
			       dispatch_job_queue) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)};
 }

sub bind_insert_stmt {
  my $self = shift;
  my $insert_stmt = shift;
  my $obj = shift;

  my $i = 1;
  $insert_stmt->bind_param($i++, $obj->type_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->testcase_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->executable, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->arguments, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->stdin, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->stdout, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->stderr, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->working_directory, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->install_directory, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->failure_ok);
  $insert_stmt->bind_param($i++, $obj->ordinal, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->dispatch()->name, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->dispatch()->arguments, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->dispatch()->mode, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->dispatch()->procs, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->dispatch()->max_time, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->dispatch()->job_queue, SQL_VARCHAR);
}

sub get_update_sql {
  return q{UPDATE Command SET type_id = ?,
	   testcase_id = ?,
	   description = ?,
	   executable= ?,
	   arguments = ?,
	   stdin = ?,
	   stdout = ?,
	   stderr = ?,
	   working_directory = ?,
	   install_directory = ?,
	   outputfile = ?,
	   failure_ok = ?,
	   ordinal = ?,
	   dispatch_name = ?,
	   dispatch_args = ?,
	   dispatch_mode = ?,
	   dispatch_procs = ?,
	   dispatch_max_time = ?,
	   dispatch_job_queue = ?
	   WHERE command_id = ?};
}

sub bind_update_stmt {
  my $self = shift;
  my $update_stmt = shift;
  my $obj = shift;

  my $i = 1;

  $update_stmt->bind_param($i++, $obj->type_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->testcase_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->executable, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->arguments, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->stdin, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->stdout, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->stderr, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->working_directory, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->install_directory, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->failure_ok);
#  $update_stmt->bind_param($i++, $obj->failure_ok ? 't' : 'f'); # bob?
  $update_stmt->bind_param($i++, $obj->ordinal, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->dispatch()->name, SQL_VARCHAR);
  $update_stmt->bind_param($i++, ,$obj->dispatch()->arguments, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->dispatch()->mode, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->dispatch()->procs, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->dispatch()->max_time, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->dispatch()->job_queue, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->command_id );
}

1;
