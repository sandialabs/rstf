###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Study.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/Study.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::PgDAO::Study;
use strict;
use warnings;

use  RSTF::DB::Study;
use RSTF::DB::NoteList;

use RSTF::DB::PgDAO::DAO;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use RSTF::DB::Utils qw(:dates);
use DBI qw(:sql_types);

my @init_args = (table => 'BenchmarkPlanningStudy',
		 serial_column => 'study_id',
		 object_class=>'RSTF::DB::Study',
		 scalar_db_fields => [qw(
					 benchmark_plan_id
					 benchmark_state_id
					 purpose_id
					 size
					 mode
					 description
					 date
					 )],
		 nested_object_fields => [qw(
					     notes
					     )]
		 
		 );

sub init {
    my $self = shift;
    return $self->SUPER::init(@init_args, @_);
}


sub get_fetch_sql {
    return q{SELECT * FROM BenchmarkPlanningStudy WHERE study_id = ?};
}

sub bind_fetch_stmt {
    my $self = shift;
    my $fetch_stmt = shift;
    my $obj = shift;
    my $ct = 1;
    $fetch_stmt->bind_param($ct++, $obj->study_id, SQL_INTEGER);
}


sub finalize_fetch { 
    my $self = shift;
    my $db_hashref = shift;	# hash of values returned from a fetch query.
    my $obj = shift;
    
    my $study_id = $obj->study_id;
    my $notelist = new RSTF::DB::NoteList(key_values=>[$study_id], key_slots=>['study_id'])->fetch;
    $obj->notes($notelist);
}

sub get_delete_sql {
    return q{DELETE  FROM BenchmarkPlanningStudy WHERE id = ?};
}

sub bind_delete_stmt{
    my $self = shift;
    my $delete_stmt = shift;
    my $obj = shift;
    $delete_stmt->bind_param(1, $obj->id, SQL_INTEGER);
}

sub get_insert_sql {
    return q{INSERT INTO BenchmarkPlanningStudy(
						benchmark_plan_id,
						benchmark_state_id,
						purpose_id,
						size,
						mode,
						description,
						date) VALUES(?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
    my $self = shift;
    my $insert_stmt = shift;
    my $obj = shift;

    my $i = 1;
    $insert_stmt->bind_param($i++, $obj->benchmark_plan_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->benchmark_state_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->purpose_id, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->size, SQL_INTEGER);
    $insert_stmt->bind_param($i++, $obj->mode, SQL_VARCHAR);
    $insert_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
    # Fix date for source_code_read

    my $date = $obj->date();
    $date = format_date($date);
    $obj->date($date);
    $insert_stmt->bind_param($i++, $date, SQL_VARCHAR);
}

sub get_update_sql {
    return q{UPDATE BenchmarkPlanningStudy SET	
	 benchmark_plan_id = ?,
		 benchmark_state_id = ?,
		 purpose_id = ?,
		 size = ?,
		 mode  = ?,
		 description = ?,
		 date = ?
		 WHERE study_id = ?};
}

sub bind_update_stmt {
    my $self = shift;
    my $update_stmt = shift;
    my $obj = shift;

    my $i = 1;

    $update_stmt->bind_param($i++, $obj->benchmark_plan_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->benchmark_state_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->purpose_id, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->size, SQL_INTEGER);
    $update_stmt->bind_param($i++, $obj->mode, SQL_VARCHAR);
    $update_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);

    my $xdate = $obj->date();
    $xdate = format_date($xdate);
    $obj->date($xdate);

    $update_stmt->bind_param($i++, $xdate, SQL_VARCHAR);

    $update_stmt->bind_param($i++, $obj->study_id, SQL_INTEGER);
}


sub get_find_by_name_sql {
    my $self = shift;
    my $plan_id = shift;
    my $size = shift;
    my $mode = shift;

    my $mode_clause;
    if ($mode) {
	$mode_clause = "mode='$mode'";
    } else {
	$mode_clause = "mode IS NULL";
    }
    my $sql =  qq{SELECT study_id FROM BenchmarkPlanningStudy WHERE
		      benchmark_plan_id=$plan_id AND
		      size=$size AND
		      $mode_clause};
    return $sql;
}

sub get_fetchall_sql {
    return q{SELECT study_id FROM BenchmarkPlanningStudy };
}

1;
