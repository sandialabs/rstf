###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestCase.pm
# 
# Created by: Robert A. Ballance		Fri Apr 16 10:30:22 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PgDAO/TestCase.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PgDAO::TestCase;
use strict;

use  RSTF::DB::TestCase;
use RSTF::DB::PgDAO::DAO;
use RSTF::DB::OuterBlock;
use RSTF::DB::PropertyList;
use RSTF::DB::DataDirectoryList;
use RSTF::DB::RunList;
use RSTF::DB::Environment;
use RSTF::DB::Utils qw(:utils);



use vars qw(@ISA);
@ISA=qw(RSTF::DB::PgDAO::DAO);

use DBI qw(:sql_types);

my @init_args = (table => 'TestCase',
		 serial_column => 'testcase_id',
		 nested_object_fields => [qw(
					     environment
					     preprocess_commands
					     postprocess_commands
					     exec_commands
					     validate_commands
					     grade_commands
					     setup_commands
					     compile_commands
					     cleanup_commands
					     installation_commands
					     final_commands
					     property_matchers
					     data_directories
					     appbinary

					     run_list
					     )],

		 scalar_db_fields => [qw(

					 benchmark_id	
					 name	
					 description	
					 benchmark_state_id	
					 platform_id	
					 procs_per_node	
					 nodes_required	
					 size	
					 test_type_id	
					 prepared_by_id	
					 validated_by_id	
					 est_walltime	
					 red_proc_mode	
					 working_directory	
					 stdout	
					 stderr
					 primary_metric_name
					 )]
		);


sub init {
  my $self = shift;
  return $self->SUPER::init(@init_args, @_);
}

sub _fetch_block {
  my $self = shift;
  my $testcase_id = shift;
  my $type = shift;
  return new RSTF::DB::OuterBlock(key_values=>[$testcase_id], name=>$type, key_slots=>['testcase_id']);
}

sub get_fetch_sql {
  return q{SELECT * FROM TestCase WHERE testcase_id = ? };
}

sub bind_fetch_stmt {
  my $self = shift;
  my $fetch_stmt = shift;
  my $obj = shift;
  $fetch_stmt->bind_param(1, $obj->testcase_id, SQL_INTEGER);
}


sub finalize_fetch { 
  my $self = shift;
  my $db_hashref = shift;	# hash of values returned from a fetch query.
  my $obj = shift;


  my $testcase_id = $obj->testcase_id;

  $obj->exec_commands($self->_fetch_block($testcase_id, 'runjob'));
  $obj->preprocess_commands($self->_fetch_block($testcase_id, 'preprocess'));
  $obj->postprocess_commands($self->_fetch_block($testcase_id, 'postprocess'));
  $obj->validate_commands($self->_fetch_block($testcase_id, 'validate'));
  $obj->grade_commands($self->_fetch_block($testcase_id, 'score'));

  $obj->setup_commands($self->_fetch_block($testcase_id, 'setup'));
  $obj->compile_commands($self->_fetch_block($testcase_id, 'compile'));
  $obj->cleanup_commands($self->_fetch_block($testcase_id, 'cleanup'));
  $obj->installation_commands($self->_fetch_block($testcase_id, 'installation'));
  $obj->final_commands($self->_fetch_block($testcase_id, 'finally'));

  # Environment?
  $obj->environment(new RSTF::DB::Environment(key_values=>[$testcase_id], key_slots=>['testcase_id']));

  # Properties?
  $obj->property_matchers(new RSTF::DB::PropertyList(key_values=>[$testcase_id]));

  # data directories?
  # Environment?
  $obj->data_directories(new RSTF::DB::DataDirectoryList(key_values=>[$testcase_id], key_slots=>['testcase_id']));

  $obj->run_list(new RSTF::DB::RunList(key_values=>[$testcase_id], key_slots=>['testcase_id']));

}

sub get_delete_sql {
  return q{DELETE  FROM TestCase WHERE testcase_id = ?};
}

sub bind_delete_stmt{
  my $self = shift;
  my $delete_stmt = shift;
  my $obj = shift;
  $delete_stmt->bind_param(1, $obj->testcase_id, SQL_INTEGER);
}

sub get_insert_sql {
  return q{INSERT INTO TestCase(benchmark_id,
				name,
				description,
				benchmark_state_id,
				platform_id,
				procs_per_node,
				nodes_required,
				size,
				test_type_id,
				prepared_by_id,
				validated_by_id,
				est_walltime,
				red_proc_mode,
				working_directory,
				stdout,
				stderr,
				primary_metric_name) VALUES(?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?)};
}

sub bind_insert_stmt {
  my $self = shift;
  my $insert_stmt = shift;
  my $obj = shift;

  my $i = 1;
  $insert_stmt->bind_param($i++, $obj->benchmark_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->benchmark_state_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->procs_per_node, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->nodes_required, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->size, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->test_type_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->prepared_by_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->validated_by_id, SQL_INTEGER);
  $insert_stmt->bind_param($i++, $obj->est_walltime, SQL_FLOAT);
  $insert_stmt->bind_param($i++, $obj->red_proc_mode, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->working_directory, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->stdout, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->stderr, SQL_VARCHAR);
  $insert_stmt->bind_param($i++, $obj->primary_metric_name, SQL_VARCHAR);
}

sub get_update_sql {
  return q{UPDATE TestCase SET  benchmark_id = ?,
	   name = ?,
	   description = ?,
	   benchmark_state_id = ?,
	   platform_id = ?,
	   procs_per_node = ?,
	   nodes_required = ?,
	   size = ?,
	   test_type_id = ?,
	   prepared_by_id = ?,
	   validated_by_id = ?,
	   est_walltime = ?,
	   red_proc_mode = ?,
	   working_directory = ?,
	   stdout = ?,
	   stderr = ?,
	   primary_metric_name=?
	   WHERE testcase_id = ?};
}

sub bind_update_stmt {
  my $self = shift;
  my $update_stmt = shift;
  my $obj = shift;

  my $i = 1;

  $update_stmt->bind_param($i++, $obj->benchmark_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->name, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->description, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->benchmark_state_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->platform_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->procs_per_node, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->nodes_required, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->size, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->test_type_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->prepared_by_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->validated_by_id, SQL_INTEGER);
  $update_stmt->bind_param($i++, $obj->est_walltime, SQL_FLOAT);
  $update_stmt->bind_param($i++, $obj->red_proc_mode, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->working_directory, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->stdout, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->stderr, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->primary_metric_name, SQL_VARCHAR);
  $update_stmt->bind_param($i++, $obj->testcase_id );
}

sub create_object {
    my $self = shift;
    my $id = shift;
    return new RSTF::DB::TestCase(testcase_id => $id)->fetch();
}

sub get_find_by_name_sql {
    my $self = shift;
    my $benchmark_id = shift;
    my $platform_id = shift;
    my $size = shift;
    return qq{Select testcase_id from TestCase where benchmark_id=$benchmark_id and platform_id=$platform_id and size=$size};
}

1;
