###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# SystemConfiguration.pm
# 
# Created by: Robert A. Ballance		Fri May 28 13:42:53 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/SystemConfiguration.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::SystemConfiguration;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Machine;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       new_with_init=>'new',
		       get_set=> [qw(system_config_id
				     machine_id
				     os
				     procs_available 
				     compute_nodes_available
				     description 
				     created

				     hostname
				     platform_name
				     )]
		      );

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'systemconfiguration', id_slot=>'system_config_id',
					is_empty=>0);

my @init_args = (xmlwriter=>$xmlwriter, compute_nodes_available=> 0, procs_available=>0, description=>'');
sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
  return $self;
}

sub machine {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'machine_id',
      object_slot => '_machine_slot',
      object_classname => 'RSTF::DB::Machine'
      }, @_);
}

sub script_compile {
    my $self = shift;
    $self->machine->script_compile();
    $self->purify();
}

sub set_child_keys {
    # EMPTY
}

sub write_xml_body {
    my $self = shift;

    $self->machine()->write_xml();
    print
	$self->xml_wrap_tag('timestamp', $self->created),
	$self->xml_wrap_tag('osinfo', $self->os),
	$self->xml_wrap_tag('description', $self->description),
#	$self->xml_wrap_tag('procsavailable', $self->procs_available),
#	$self->xml_wrap_tag('nodesavailable', $self->compute_nodes_available);
}


# SystemConfiguration should only be in the DB once for each unique 
# instance. Skip the real insert if it is already there!
sub insert {
    my $self = shift;
    unless (defined($self->system_config_id)) {
	return $self->SUPER::insert();
    }
    return undef;
}

sub make {
    my $pkg = shift;
    my $machine_name = shift;
    my $os = shift;
    my $platform = shift;
    my $created = shift;
    my $description = shift;

    $created ||=  localtime;
    # this is offline --- later, when we write to DB, the actual machines get created.
    # This, of course, depends on writing, then reading, the XML
    my $machine = new RSTF::DB::Machine(machine_name=>$machine_name, platform_id=>$platform->platform_id);
    return new RSTF::DB::SystemConfiguration(machine=>$machine, os=>$os, created=>$created, description=>$description);
}

1;
