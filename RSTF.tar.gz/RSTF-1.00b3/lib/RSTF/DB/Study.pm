###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Study.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Study.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::Study;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::BenchmarkPlanning;
use RSTF::DB::NoteList;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'study', id_slot=>'study_id',
					other_attr=>[qw(benchmark_plan_id date mode size)],
					is_empty=>1);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     study_id
				     benchmark_plan_id
				     benchmark_state_id
				     purpose_id
				     date
				     size
				     mode
				     description
				     notes
			     )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub testase_plan {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'benchmark_plan_id',
      object_slot => '_plan_slot',
      object_classname => 'RSTF::DB::BenchmarkPlanning'
      }, @_);
}

sub purpose {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'purpose_id',
      object_slot => '_purpose_slot',
      object_classname => 'RSTF::DB::Purpose'
      }, @_);
}

sub state {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'benchmark_state_id',
      object_slot => '_state_slot',
      object_classname => 'RSTF::DB::BenchmarkState'
      }, @_);
}

sub update_child_keys {
    my $self = shift;
    my $keyval = [$self->study_id];
    my $dao = $self->dao();
    if ($self->dao) {
	my $nested_obj = $self->dao()->nested_object_fields();
	foreach my $field (@$nested_obj) {
	    my $obj = $self->$field;
	    if ($obj) {
		$obj->set_child_keys($keyval);
	    }
	}
    }
}

1;
