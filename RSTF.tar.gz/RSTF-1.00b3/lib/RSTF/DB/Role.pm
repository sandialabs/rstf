###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Role.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Role.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::Role;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(role role_id)]);


use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'role', id_slot=>'role_id', is_empty=>1, other_attr=>['role']);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

1;
