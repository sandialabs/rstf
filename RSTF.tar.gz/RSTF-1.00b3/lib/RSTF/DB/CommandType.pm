###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestType.pm
# 
# Created by: Robert A. Ballance		Wed Mar 17 10:52:53 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/CommandType.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
# Slot description for the TestType table.
#
###############################################################################

package RSTF::DB::CommandType;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       get_set=> [qw(name type_id)]
);


1;
