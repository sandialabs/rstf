###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# StmtFactory.pm
# 
# Created by: Robert A. Ballance		Fri Mar 19 12:30:47 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/StmtFactory.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::StmtFactory;
use strict;
use warnings;

use RSTF::DB::DAO;
use Data::Dumper;
use Class::MethodMaker (
		       get_set => [qw(
				      cached_fetch_stmt
				      cached_fetch_sql
				      cached_fetch_all_stmt
				      cached_delete_stmt
				      cached_delete_all_stmt
				      cached_update_stmt
				      cached_insert_stmt
				     )],

		       new_hash_init => 'new');

sub get_fetch_stmt {
  my $self = shift;
  my $dao = shift;
  my $where = shift;

  my $stmt;

  unless ($where) {
    $stmt = $self->cached_fetch_stmt();
  }
  unless ($stmt) {
    my $sql = $dao->get_fetch_sql();

    if ($where) {
      $sql .= ' ' . $where;
    }
    $stmt = $dao->db()->prepare($sql) or die $dao->db->errstr;
    unless ($where) {
      $self->cached_fetch_stmt($stmt);
      $self->cached_fetch_sql($sql);
    }
  }
  return $stmt;
}

sub get_fetchall_stmt {
  my $self = shift;
  my $dao = shift;
  my $where = shift;

  my $stmt;

  unless ($where) {
    $stmt = $self->cached_fetch_all_stmt();
  }
  unless ($stmt) {
    my $sql = $dao->get_fetchall_sql();
    if ($where) {
      $sql .= ' ' . $where;
    }
    $stmt = $dao->db()->prepare($sql);
    unless ($where) {
      $self->cached_fetch_all_stmt($stmt);
    }
  }
  return $stmt;
}
sub get_delete_all_stmt {
  my $self = shift;
  my $dao = shift;
  my $where = shift;

  my $stmt;

  unless ($where) {
    $stmt = $self->cached_delete_all_stmt();
  }
  unless ($stmt) {
    my $sql = $dao->get_delete_all_sql();
    if ($sql && $where) {
      $sql .= ' ' . $where;
    }
    $stmt = $dao->db()->prepare($sql);
    unless ($where) {
      $self->cached_delete_all_stmt($stmt);
    }
  }
  return $stmt;
}

sub get_update_stmt {
  my $self = shift;
  my $dao = shift;

  my $stmt = $self->cached_update_stmt();
  unless ($stmt) {
    $stmt = $dao->db()->prepare($dao->get_update_sql());
    $self->cached_update_stmt($stmt);
  }
  return $stmt;
}

sub get_insert_stmt {
  my $self = shift;
  my $dao = shift;

  my $stmt = $self->cached_insert_stmt();
  unless ($stmt) {
    my $sql = $dao->get_insert_sql();
    $stmt = $dao->db()->prepare($sql) or die $dao->db->errstr;
    $self->cached_insert_stmt($stmt);
  }
  return $stmt;
}

sub get_delete_stmt {
  my $self = shift;
  my $dao = shift;

  my $stmt = $self->cached_delete_stmt();
  unless ($stmt) {
    $stmt = $dao->db()->prepare($dao->get_delete_sql());
    $self->cached_delete_stmt($stmt);
  }
  return $stmt;
}

1;
