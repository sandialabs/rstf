###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DAOFactory.pm
# 
# Created by: Robert A. Ballance		Thu Apr 22 12:23:37 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/DAOFactory.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::DAOFactory;
use strict;
use warnings;
use RSTF::Configuration;

use Class::MethodMaker (
			new_hash_init => '_init_hash',
			get_set => [qw(db_connection db)]
			);

my $factory;

sub init {
    unless ($factory) {
	$factory = _make_factory();
    }
    return $factory;
}

sub _make_factory {
    my $config = new RSTF::Configuration();
    my $factory_class = 'RSTF::DB::Unconnected::DAOFactory';
    if ($config->database_connect()) {
	$factory_class = 'RSTF::DB::PgDAO::DAOFactory';
    }
    eval "require $factory_class";

    if ($@) {
	die $@;
    }

    my $factory;
    eval {
	$factory = new $factory_class;
    };

    if ($@)  {
	die $@;
    }
    return $factory;
}


sub get_connection {
    die "Must call RSTF::DB::DAOFactory::init first!" unless($factory);
    return $factory->db_connection();
}

sub find_dao {
    my $class = shift;
    die "Must call RSTF::DB::DAOFactory::init first!" unless($factory);
    my $dao =  $factory->do_find_dao($class);
    return $dao;
}

sub dbh {
    die "Must call RSTF::DB::DAOFactory::init first!" unless($factory);
    return $factory->db();
}

sub is_connected {
    if ($factory) {
	return $factory->is_connected();
    }
    return 0;
}


1;
