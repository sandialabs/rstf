###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# EnvironmentSetting.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 14:56:52 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/EnvironmentSetting.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::EnvironmentSetting;

use strict;
use warnings;

use RSTF::DB::DBObject;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use constant PATH => 1;
use constant VARIABLE => 2;

# These could be nested inner classes if Perl had them!
use RSTF::DB::EnvVar;
use RSTF::DB::EnvPath;

# XML Writers are set up by the derived classes!
use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw (env_id 
				       env_type
				       testcase_id
				       name
				       value
				       ordinal
				      )]
);

1;
