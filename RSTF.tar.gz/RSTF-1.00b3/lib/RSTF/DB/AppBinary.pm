###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# AppBinary.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/AppBinary.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::AppBinary;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Contact;
use RSTF::DB::Application;
use RSTF::DB::CompileTool;
use RSTF::DB::Platform;
use RSTF::FilePath;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'appbinary', id_slot=>'appbinary_id', other_attr=>[qw(app_id platform_id compiled_by_id)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     appbinary_id
				     app_id
				     filepath
				     platform_id
				     compilation_host
				     compilation_date
				     compiled_by_id
				     size_info
				     byte_count
				     md5sum

				     compilation_platform
				     compiled_by_email
				     app_name
				    )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  $self = $self->SUPER::init(@init_args, @_);
  return $self;
}

# AppBinary should only be in the DB once for each unique 
# instance. Skip the real insert if it is already there!
sub insert {
    my $self = shift;
    unless (defined($self->appbinary_id)) {
	return $self->SUPER::insert();
    } else {
	# prepare insert moves values like compiled_by_email into compiled_by_id
	$self->prepare_insert();
    }
    return $self;
}

sub compiled_by {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'compiled_by_id',
      object_slot => '_compiled_by_slot',
      object_accessor => 'contact_id',
      object_classname => 'RSTF::DB::Contact'   }, @_);
}

sub platform {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'platform_id',
      object_slot => '_platform_slot',
      object_classname => 'RSTF::DB::Platform'   }, @_);
}

sub application {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'app_id',
      object_slot => '_app_slot',
      object_classname => 'RSTF::DB::Application'   }, @_);
}

sub prepare_insert {
    my $self = shift;
    unless ($self->compiled_by_id) {
	if ($self->compiled_by_email) {
	    my $contact = RSTF::DB::Contact->find_by_name($self->compiled_by_email);
	    $self->compiled_by($contact);
	}
    }
    unless ($self->platform_id) {
	if ($self->compilation_platform) {
	    my $platform = RSTF::DB::Platform->find_by_name($self->compilation_platform);
	    $self->platform($platform);
	}
    }
    
    unless ($self->app_id) {
	if ($self->app_name) {
	    my $app = RSTF::DB::Application->find_by_name($self->app_name);
	    $self->application($app);
	}
    }
}


sub prepare_update {
    my $self = shift;
    $self->prepare_insert();
}

# expand the path relative to the root directory!
# Otherwise it will be working-directory relative
sub expanded_path {
    my $self = shift;
    my $path = $self->filepath;
    if ($path) {
	return expand_path($path);
    }
    return $path;
}

# Had to override this function since it gets called from Run update_child_keys.
sub set_child_keys {
    #empty
}

sub write_xml_body {
    my $self = shift;

    print $self->xml_wrap_tag('filepath', $self->filepath);

    if ($self->app_name) {
	print $self->xml_wrap_tag('appname', $self->app_name);
    } else {
	my $application = $self->application();
	if ($application && $application->name) {
	    print $self->xml_wrap_tag('appname', $application->name);
	}
    }

    print $self->xml_wrap_tag('compilationplatform', $self->compilation_platform);
    print $self->xml_wrap_tag('host', $self->compilation_host);
    print $self->xml_wrap_tag('compilationdate', $self->compilation_date);
    print $self->xml_wrap_tag('compiledby', $self->compiled_by_email);
    print $self->xml_wrap_tag('md5sum', $self->md5sum);
    print $self->xml_wrap_tag('sizeinfo', $self->size_info);
    print $self->xml_wrap_tag('bytecount', $self->byte_count);
}

1;
