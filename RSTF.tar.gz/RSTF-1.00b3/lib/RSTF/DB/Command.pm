###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Command.pm
# 
# Created by: Robert A. Ballance		Tue Apr 13 08:43:10 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Command.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::Command;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'command', id_slot=>'command_id',
					other_attr => [qw(failure_ok)]);



#   command_id SERIAL PRIMARY KEY,

#   type_id INTEGER REFERENCES CommandType
# 	   ON DELETE SET NULL,


#   testcase_id   INTEGER REFERENCES TestCase
#           ON DELETE CASCADE,

#   description TEXT,

#   executable CommandString,
#   arguments CommandArgs,
#   working_directory  FilePath,
#   stdin   FileName,
#   stdout  FileName,
#   stderr  FileName,
#   dispatch_name DispatchName,
#   dispatch_args CommandArgs,
#   dispatch_mode VARCHAR(8),
#   dispatch_procs INTEGER
use RSTF::DB::Dispatch;

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [ qw(
					command_id
					type_id
					testcase_id
					ordinal
					
					description
					executable
					arguments
					stdin
					stdout
					stderr
					working_directory
					install_directory
					failure_ok

					dispatch

				       )],

);


my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
}


# Ordinal?
# failure_ok?
sub write_xml_body {
  my $self = shift;

  print $self->xml_wrap_tag('description', $self->description);
  print $self->xml_wrap_tag('workingdirectory', $self->working_directory);
  $self->dispatch->write_xml();
  print $self->xml_wrap_tag('installationdirectory', $self->install_directory);
  print $self->xml_wrap_tag('executable', $self->executable);
  print $self->xml_wrap_tag('arguments', $self->arguments);
  print $self->xml_wrap_tag('stdin', $self->stdin);
  print $self->xml_wrap_tag('stdout', $self->stdout);
  print $self->xml_wrap_tag('stderr', $self->stderr);
}


1;

