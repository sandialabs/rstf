###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Property.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 18:58:53 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Property.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
#   property_id SERIAL PRIMARY KEY,

#   testcase_id   INTEGER REFERENCES TestCase
#           ON DELETE CASCADE,

#   name PropertyName,
#   pattern PropertyExpr,
#   filename FileName,
#   filepath FilePath,
#   matched  boolean,
#   value     VARCHAR(128)

package RSTF::DB::Property;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);
use Class::MethodMaker(
		       get_set => [ qw(property_id
				       testcase_id
				       property_name match_type filename filepath
				       pattern 
				       result)]
);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'property',
					id_slot=>'property_id',
					other_attr=>[qw(testcase_id)]);


my @default_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

sub write_xml_body {
    my $self = shift;
    print
	$self->xml_wrap_tag('name', $self->property_name),
	$self->xml_wrap_tag('matchtype', $self->match_type),
	$self->xml_wrap_tag('filename', $self->filename),
	$self->xml_wrap_tag('filepath', $self->filepath),
	$self->xml_wrap_tag('pattern', $self->pattern);
}

1;

