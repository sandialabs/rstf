###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# OuterBlock.pm
# 
# Created by: Robert A. Ballance		Thu Apr  8 09:32:23 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/OuterBlock.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################

package RSTF::DB::OuterBlock;
use strict;
use warnings;

use RSTF::DB::DBList;
use RSTF::DB::CommandType;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::DBList);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(commands name app_id testcase_id benchmark_id type_id )]
);

use RSTF::DB::Command;
#use RSTF::DB::DAO::LookupTable;
use RSTF::DB::XMLWriter;


my @default_args = (commands => [],
		    object_type => 'RSTF::DB::Command',
		    list_field => 'commands',
		    key_slots => [],
		    key_values => []);
		  

sub init {
    my $self = shift;
    $self->SUPER::init(@default_args, @_);
    my $xmlwriter = new RSTF::DB::XMLWriter(tag => $self->name, id_slot=>'testcase_id');
    $self->xmlwriter($xmlwriter);

    if ($self->name) {
	my $type = RSTF::DB::CommandType->find_by_name($self->name);
#$self->lookup_table()->lookup_by_name($self->name);
	die "Unable to find " . $self->name unless($type);
	$self->type_id($type->type_id);
    }

    my $key_slots = $self->key_slots;
    my @slot_list = @$key_slots;
    push @slot_list, 'type_id';
    $self->key_slots(\@slot_list);
    
    $self->slot_count($#slot_list + 1);
    
    my $key_values = $self->key_values();
    my @value_list = @$key_values;
    push @value_list, $self->type_id;
    $self->key_values(\@value_list);
    
    return $self;
}

# my $lookup_table;

# # Not clear to RAB that this belongs quite like this, but it works!
# sub lookup_table {
#   my $self = shift;
#   unless ($lookup_table) {
#     $lookup_table= new RSTF::DB::DAO::LookupTable(id_slot => 'type_id',
# 						  name_slot => 'name',
# 						  db =>  RSTF::DB::DAOFactory::dbh(),
# 						  typename => 'RSTF::DB::CommandType',
# 						  table => 'CommandType');
#   }
#   return $lookup_table;
# }

sub set_child_keys {
     my $self = shift;
     my $key_values = shift;
     my @value_list = @$key_values;
     if (@value_list) {
	 push @value_list, $self->type_id;
	 $self->SUPER::set_child_keys(\@value_list);
     }
}


sub fetch {
  my $self = shift;
  my $obj =  $self->SUPER::fetch(' Order by ordinal ');
  return $obj;
}

sub prepare_insert {
    my $self = shift;
    my $objects = shift;
    my $ord = 1;
    foreach my $cmd (@$objects) {
	$cmd->ordinal($ord++);
    }
}

sub prepare_update {
    my $self = shift;
    $self->prepare_insert;
}

1;

