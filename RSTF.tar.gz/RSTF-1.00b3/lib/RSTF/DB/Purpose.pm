###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Purpose.pm
# 
# Created by: Robert A. Ballance		Mon May 24 11:10:59 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Purpose.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::Purpose;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);


use Class::MethodMaker( new_with_init => 'new',
			get_set=> [qw(name purpose_id description)]
);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'purpose', id_slot=>'purpose_id', is_empty=>1, other_attr=>['name']);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}


# This tag list has to correlate with the database!
# Can we get this from the DAO hash?
my @tags = qw(unknown debug production benchmark test-bench test-regression) ;

sub get_user_tags {
    my $pkg = shift;
    return join " ", @tags[1 .. 5];
}


sub _id_to_name {
    my $pkg = shift;
    my $id = shift;
    # list is indexed at 1
    my $tag = $tags[$id - 1];
    if ($tag) {
	return $tag;
    }
    warn "RSTF::DB::Purpose::_id_to_name -- id '$id' not found";
    return $tags[0];
}

sub _name_to_id {
    my $pkg = shift;
    my $name = shift;

    for (my $id = 0; $id <= $#tags; $id++) {
	if ($name eq $tags[$id]) {
	    return $id + 1;
	}
    }
    warn "RSTF::DB::Purpose::_name_to_id -- name '$name' not found";
    return 1;

}
sub purpose_from_name {
    my $pkg = shift;
    my $name = shift;

    $name = lc $name;

    my $id = $pkg->_name_to_id($name);

    # if name is invalid, id_from_name returns the Unknown id, so we need to remap the name
    $name = $pkg->_id_to_name($id);

    return new RSTF::DB::Purpose(purpose_id=>$id, name=>$name);
}

1;
