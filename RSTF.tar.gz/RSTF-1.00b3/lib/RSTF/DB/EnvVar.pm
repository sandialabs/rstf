###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# EnvVar.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 19:07:18 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/EnvVar.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::EnvVar;
use strict;
use warnings;

use RSTF::DB::EnvironmentSetting;
use vars qw(@ISA);
@ISA = qw(RSTF::DB::EnvironmentSetting);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw (old old_value )]
);

use RSTF::LogFile;
use RSTF::DB::XMLWriter;
use RSTF::DB::Utils;

# This XML value is for the structured Variable object.
my $valuewriter = new RSTF::DB::XMLWriter(tag=>'variable', id_slot=>'env_id', other_attr=>[qw(env_type testcase_id)]);

my @default_args = (env_type => RSTF::DB::EnvironmentSetting::VARIABLE, xmlwriter=>$valuewriter);
sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
}


sub add {
    my $self = shift;
    $self->old_value($ENV{$self->name});
    my $value = subst_env_vars($self->value);
    $ENV{$self->name} = $value;
    log_debug("Environment: " . $self->name . '=' . $value);
}

sub remove {
    my $self = shift;
    my $prev_val = $self->old_value;
    if ($prev_val) {
	$ENV{$self->name} = $prev_val;
    } else {
	delete $ENV{$self->name}
    }
}

sub write_xml_body  {
    my $self = shift;
    print
	$self->xml_wrap_tag('name', $self->name),
	$self->xml_wrap_tag('value', $self->value);

}

1;
