###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
#  
# 
# DAOFactory.pm
# 
# Created by: Robert A. Ballance		Tue Sep 28 15:18:48 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Unconnected/DAOFactory.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################
# Stub version
use strict;
package RSTF::DB::Unconnected::DAOFactory;
use RSTF::DB::DAOFactory;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DAOFactory);

use RSTF::DB::Unconnected::DAO;


my $factory;

# package method?
sub new {
    my $self = shift;
    unless ($factory) {
#	log_notice("Running Unconnected");
	$factory =   $self->SUPER::_init_hash(db_connection=>undef, db=>undef);
    }
    return $factory;
}


sub is_connected {
    my $self = shift;
    return 0;
}

my %dao_cache;

sub do_find_dao {
    my $self = shift;
    my $class_name = shift;
    my @class_path = split('::', $class_name);
    my $basename = pop @class_path;
    my $dao = $dao_cache{$class_name};
    if ($dao) {
	return $dao;
    }

    $dao = new RSTF::DB::Unconnected::DAO();
    die "New DAO failed for $class_name" unless ($dao);
    $dao_cache{$class_name} = $dao;
    $dao->classname($class_name);

    return $dao;
}


DESTROY {
    
}

1;
