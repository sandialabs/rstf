###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DAO.pm
# 
# Created by: Robert A. Ballance		Mon Mar 15 11:54:51 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Unconnected/DAO.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
#  Fundamentall Data Access Object for the system.
#  it uses a number of abstract methods that have to be supplied by the
#  derived classes:
# 
###############################################################################

use strict;
package RSTF::DB::Unconnected::DAO;
use RSTF::DB::DAO;

use vars qw(@ISA);
@ISA =qw(RSTF::DB::DAO);

# This just calls the function that checks caches
sub find_by_name {
    my $self = shift;
    my ($name, @rest)  = @_;
    # pass the do_create flag on to find_cached_name.
    my $x = $self->find_cached_name($name, @rest);
    unless ($x) {
	if ($self->object_cache_valid()) {
	    $x = $self->create_cached_object_by_name($name);
	}
    }
    die "Unable to find or create a " . $self->classname unless($x);
    print STDERR "xml writer is " . $x->xmlwriter . "\n";
    return $x;
}

#####
sub fetch {
    my $self = shift;
    return $self;
}

# Fetch all
sub fetch_all {
    my $self = shift;
    return $self;
}

sub insert {
    my $self = shift;
    return $self;
}


sub update {
    my $self = shift;
    return $self;
}

sub delete {
    my $self = shift;
    return $self;
}



1;
