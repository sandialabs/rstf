###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# ApplicationPlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/ApplicationPlanning.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::ApplicationPlanning;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'applicationstatus',
				       other_attr=>[qw(app_id platform_id)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     app_id
				     platform_id
				     version
				     ported_serial
				     ported_parallel
				     ported_serial_by_id
				     ported_parallel_by_id
				     needs_validation
				     validated boolean
				     validated_by_id
				     ready 
				     )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub write_xml_body {
    my $self = shift;
    warn "write_xml_body not defined for ApplicationPlanning\n";
}

1;
