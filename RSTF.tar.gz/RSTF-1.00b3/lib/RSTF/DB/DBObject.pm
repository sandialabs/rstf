###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DBObject.pm
# 
# Created by: Robert A. Ballance		Wed Apr 14 16:02:54 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/DBObject.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::DBObject;
use strict;
use warnings;

use Class::MethodMaker(
		       new_hash_init => '_init_hash',
		       new_with_init => 'new',
		       get_set => [qw(dao
				      _cached_object_slots
				      xmlwriter)]
);

use RSTF::DB::DAO;
use RSTF::DB::DAOFactory;
use RSTF::DB::XMLWriter;

sub init {
  my $self = shift;
  $self->_init_hash(@_, _cached_object_slots=>{});

  my $class = ref($self);
  my $dao = RSTF::DB::DAOFactory::find_dao($class);
  unless ($dao) {
    die "No DAO for ", $class, "\n";
  }
  $self->dao($dao);
  return $self;
}

sub is_interned {
  my $self = shift;
  my $dao = $self->dao();
  my $serial_col = $dao->serial_column;
  if ($serial_col) {
      return defined($self->$serial_col);
  } else {
      die ref($self) . "Must define an is_interned() method\n";
  }
}

sub store {
  my $self = shift;
  if ($self->is_interned()) {
    return $self->update();
  } else {
      return $self->insert();
  }
}

#
sub fetch {
    my $self = shift;
    return $self->dao()->fetch($self, @_);
}

sub fetch_all {
    my $self = shift;
    my $where = shift;
    return $self->dao()->fetch_all($where);
}

sub insert {
    my $self = shift;
    my $dao = $self->dao();
    if ($dao) {
	return $self->dao()->insert($self);
    } else {
	die "No dao for " . ref($self) . "\n";
    }
}

sub delete {
    my $self = shift;
    return $self->dao()->delete($self);
}

sub update {
    my $self = shift;
    return $self->dao()->update($self);
}

sub prepare_insert {
  $_[0]->update_child_keys();
}

sub prepare_fetch {
  $_[0]->update_child_keys();
}

sub prepare_update {
  $_[0]->update_child_keys();
}

sub prepare_delete {
  $_[0]->update_child_keys();
}


sub update_child_keys {
  # empty
}


# Accessors for Objects

# There are lots of times that we want to store an object inside another one.
# Think of this as a triple <benchmark, benchmark_id, Benchmark>
# If you fetch the benchmark, and it is present, return it.
# If the benchmark is not present, benchmark_id is set, then fetch the
#  benchmark and return it.
# You also need a way to store the created benchmark object.

# On storing via benchmark(), aslo update the benchmark_id.

# The following code does this

# sub benchmark {
#   my $self = shift;
#   return $self->object_access({ 
# 			       id_slot => 'benchmark_id',
# 			       object_slot => '_benchmark_slot',
# 			       object_classname => 'RSTF::DB::Benchmark'
# 				    }, @_);
# }


# { 
#   id_slot => 'benchmark_id',
#   object_slot => '_benchmark_slot',
#   object_accessor => 'benchmark_id',  --- defaults to id_slot.
#   object_classname => 'RSTF::DB::Benchmark'
# }


sub object_access {
  my $self = shift;
  my $info  = shift;
  my $obj = shift;
  die "No info !!" unless ($info);

  my $id_slot = $info->{id_slot};
  my $obj_slot = $info->{object_slot};

  my $hidden_slots = $self->_cached_object_slots;

  $hidden_slots->{$obj_slot}++;

  my $accessor = $info->{object_accessor} || $id_slot;

  if ($obj) {
      my $v = $obj->$accessor;
      $self->$id_slot($v);
      $self->{$obj_slot} = $obj;
      return $obj;
  }
  # No object specified
  # Try getting the current object.
  $obj = $self->{$obj_slot};
  if ($obj) {
    return $obj;
  }

  # No obj value. Create a new one
  if ($self->$id_slot) {

     my $classname = $info->{object_classname};

     die "No classname specific" unless ($classname);
     my $arglist = sprintf("%s=>%d", $accessor, $self->$id_slot);
     $obj = eval "new $classname ($arglist)";
     if ($@) {
	 die $@;
     }
     if ($obj) {
	 $obj->fetch();
	 $self->{$obj_slot}=$obj;
	 return $obj;
     } else {
	 die "Object creation failed";
     }
     return undef;
 }
}

sub script_compile {
    my $self = shift;
    $self->purify();
}

sub find_by_name {
    my $pkg = shift;
    my @args = @_;

    my $dao = RSTF::DB::DAOFactory::find_dao($pkg);
    my $obj = $dao->find_by_name(@args);

    if ($obj) {
	$obj = bless($obj, $pkg);
    }
    return $obj;
}


use Data::Dumper;
sub dump {
    my $self = shift;
    print Data::Dumper->Dump([$self]);
}

sub purify {
    my $self = shift;
    $self->dao(undef);
    my $hidden_slots = $self->_cached_object_slots();
    foreach my $key (keys %$hidden_slots) {
	my $value = $self->{$key};
	if ($value) {
	    $value->script_compile();
	}
    }
}

#
sub xml_header {
  my $self = shift;
  die "NO XML Writer for " . ref($self) unless($self->xmlwriter);
  return $self->xmlwriter->header($self);
}

sub xml_footer {
  my $self = shift;
  die "NO XML Writer for " . ref($self) unless($self->xmlwriter);
  return $self->xmlwriter->footer();
}

# use nested object fields?
sub write_xml {
  my $self = shift;
  die "NO XML Writer for " . ref($self) unless($self->xmlwriter);
  print $self->xml_header();
  $self->write_xml_body();
  print $self->xml_footer();
}

sub write_xml_body {
  #empty
}

# Really for RSTF::Exec, but this is the common base class
sub output_results {
    my $self = shift;
    $self->write_xml();
}

# Next function should be obsolete!
# sub xml_id_tag {
#     my $self = shift;
#     my $tag = shift;
#     my $id = shift;
#     if ($id) {
# 	return sprintf("<%s id=\"%d\">\n", $tag, $id);
#     } else {
# 	return sprintf("<%s>\n", $tag);
#     }
# }

sub xml_wrap_tag {
    my $self = shift;
    my $tag = shift;
    my $info = shift;
    return RSTF::DB::XMLWriter->format_value($tag, $info);
}

sub xml_result_time {
  my $self = shift;
  my $time = shift;
  my $tag = shift;
  return RSTF::DB::XMLWriter->format_time($tag, $time);
}


sub compile_nested_fields {
    my $self = shift;
    my $dao = $self->dao();
    if ($self->dao) {
	my $nested_obj = $self->dao()->nested_object_fields();
	foreach my $field (@$nested_obj) {
	    my $obj = $self->$field;
	    if ($obj) {
		$obj->script_compile();
	    }
	}
    }
}


1;
