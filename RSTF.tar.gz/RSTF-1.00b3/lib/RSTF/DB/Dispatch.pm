###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Dispatch.pm
# 
# Created by: Robert A. Ballance		Tue Apr 13 12:10:15 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Dispatch.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::DB::Dispatch;
use strict;
use warnings;

use RSTF::DB::Utils qw(:times);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'dispatch');

use Class::MethodMaker (
			new_hash_init => '_init_hash',
			new_with_init => 'new',
			get_set => [ qw(  name arguments mode procs max_time job_queue is_parallel)]
);

sub init {
    my $self = shift;
    return $self->_init_hash(@_);
}

sub write_xml {
    my $self = shift;

    print $xmlwriter->header($self);
    if ($self->name eq 'direct') {
	my $directwriter = new RSTF::DB::XMLWriter(tag=>'direct', is_empty=>1);
	print $directwriter->header();
    } else {
	my $writer = new  RSTF::DB::XMLWriter(tag=>$self->name, is_empty=>0);
	print
	    $writer->header($self),
	    $writer->format_value('procs', $self->procs),
	    $writer->format_value('arguments', $self->arguments),
	    $writer->format_value('mode', $self->mode),
	    $writer->format_value('timelimit', $self->max_time),
	    $writer->format_value('queue', $self->job_queue),
	    $writer->footer();
    }
    print $xmlwriter->footer();
}

# Called during block compilation
# returns new dispatch object if the merge can happen
# returns undef if not
sub check_eq {
    my $a = shift;
    my $b = shift;
    return (!defined($a) && !defined($b)) ||
	    (defined($a) && defined($b) && ($a eq $b));
}

sub unify {
    my $self = shift;
    my $candidate = shift;
    if (($self && $candidate) &&
	(ref($self) eq ref($candidate)) &&
	(($self->procs > 1 && $candidate->procs > 1) ||	 ($self->procs == 1 && $candidate->procs == 1)) &&
	check_eq($self->name, $candidate->name) &&
	check_eq($self->arguments,$candidate->arguments) &&
	check_eq($self->job_queue, $candidate->job_queue) &&
	check_eq($self->mode, $candidate->mode)) {
	
	# similar enough
	if ($candidate->procs > $self->procs) {
	    $self->procs($candidate->procs);
	}
	$self->max_time(add_times($self->max_time || '0:00:00', $candidate->max_time));
	return 1;
    }
    return 0;
}

1;

