###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DBList.pm
# 
# Created by: Robert A. Ballance		Fri Apr 16 10:31:08 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/DBList.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
# Abstract base class for representing lists of data --- likek properties, runs, or
# commands.
#
###############################################################################

package RSTF::DB::DBList;

use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(object_type
				      key_slots
				      key_values
				      list_field
				      slot_count

				      foreign_key
				      local_key

				     )]
);

# The list DAO is really the DAO for the underlying data type.
sub init {
    my $self = shift;
    # Don't call super init here --- it will look for the wrong DAO!
    $self->_init_hash(@_);

   my $class = $self->object_type;

   die "Lists must specify object type" unless ($class);
   my $dao = RSTF::DB::DAOFactory::find_dao($class);
   unless ($dao) {
     die "No DAO for ", $class, "\n";
   }
   $self->dao($dao);
    my $slots = $self->key_slots() || [];
    my @slot_list = @$slots;
    $self->slot_count($#slot_list + 1);
    return $self;
}

# Return a reference to the list's objects.
sub _objects {
    my $self = shift;
    my $list_field = $self->list_field;
    return $self->$list_field;
}


sub get_fetch_constraints {
  my $self = shift;

  my $slot_ref = $self->key_slots();
  my $values = $self->key_values;

  my @constraints = ();
  for (my $i = 0; $i < $self->slot_count; $i++) {
    push @constraints, $slot_ref->[$i] . '=' . $values->[$i];
  }
  return @constraints;
}

# Fetch takes an argument of the matching owner's value
# For now owners are always integers!
# Values should be in the order of the owner_slots.
#
sub fetch {
    my $self = shift;
    my $order_by = shift;

    my @constraints = $self->get_fetch_constraints();
    my $where = '';
    if (@constraints) {
	$where = ' Where ' . join(' AND ', @constraints);
    }
    if ($order_by) {
      $where .= " $order_by ";
    }
#! This needs to list all the kids.
    my $objects =  $self->fetch_all($where);
    my $list_field = $self->list_field;
    $self->$list_field($objects);
    return $self;
}


sub fetch_all {
    my $self = shift;
    my $where = shift;
    return $self->dao()->fetch_all($where);
}


sub set_child_keys {
    my $self = shift;
    my $key_values = shift;
    $self->key_values($key_values);
}

sub update_key_fields {
     my $self = shift;
     my $obj = shift;

     my $key_values = $self->key_values;
     my $fields  = $self->key_slots;
     my $i = 0;
     foreach my $field (@$fields) {
	 $obj->$field($key_values->[$i]);
	 $i++;
     }
 }

sub insert {
    my $self = shift;
    my $objects = $self->_objects();
    $self->prepare_insert($objects);
    foreach my $obj (@$objects) {
	$self->update_key_fields($obj);
	$obj->insert();
    }
}

# sub delete {
#     my $self = shift;

#     my $objects = $self->_objects();
#     $self->prepare_delete($objects);
#     foreach my $obj (@$objects) {
#       $obj->delete();
#     }
# }

sub update {
    my $self = shift;
#     my $objects = $self->_objects();
#     $self->prepare_update($objects);
#     foreach my $obj (@$objects) {
#       $obj->update();
#     }
    $self->delete();
    $self->insert();
}

sub script_compile {
  my $self = shift;
  my $objects = $self->_objects();
  foreach my $obj (@$objects) {
      if ($obj) {
	  $obj->script_compile();
      } else {
	  die "Bad OBJ $obj " . ref($self);
      }
  }
  $self->purify();
}

sub prepare_delete {
    # Args: (self, $objects)
    #empty
}

sub prepare_insert {
    # Args: (self, $objects)
    #empty
}

sub prepare_update {
    # Args: (self, $objects)
    # This would be a good place to delete the old elements.
    # Can either delete all, or fetch all and then remove those not in the $objects list.
    #empty
}


# Return T if the list is empty. 
sub is_empty {
    my $self = shift;
    my $objects = $self->_objects();
    if ($objects && $objects->[0]) {
	return 0;
    }
    return 1;
}

sub write_xml {
    my $self = shift;

    unless ($self->is_empty) {
	$self->SUPER::write_xml();
    }
}

sub write_xml_body {
  my $self = shift;
  my $objects = $self->_objects();
  foreach my $obj (@$objects) {
    $obj->write_xml();
  }
}
use RSTF::DB::Utils qw(:utils);
sub delete {
    my $self = shift;
    my @constraints = $self->get_fetch_constraints();
    my $where = '';
    if (@constraints) {
	$where = ' Where ' . join(' AND ', @constraints);
    }
    $self->dao->delete_all($where);
}


1;
