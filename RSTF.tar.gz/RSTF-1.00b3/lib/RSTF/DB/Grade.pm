###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Grade.pm
# 
# Created by: Robert A. Ballance		Mon May 17 11:06:37 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Grade.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################

package RSTF::DB::Grade;
use strict;
use warnings;

use RSTF::DB::DBObject;
use vars qw(@ISA);

@ISA = qw(RSTF::DB::DBObject);
use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'grade', id_slot=>'grade_id', is_empty=>1, other_attr=>['mnemonic']);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(
				      grade_id
				      name
				      mnemonic
				      value
				      description

				      comments
				      )]
		      );

# Note: the 'comment' slot is used only within RSTF::Exec, and is not in the database!

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

my %id_map = (
	      U =>    0,
	      F =>    1,
	      D =>    2,
	      M =>    3,
	      P =>    4,
	      E =>    5
	      );

sub grade_from_mnemonic {
    my $pkg = shift;
    my $char = shift;

    $char = uc($char);
    my $id = $id_map{$char};
    unless (defined($id)) {
	warn "Unknown grade mnemonic $char";
	$char = 'U';
	$id = $id_map{$char};
    }
    return new RSTF::DB::Grade(grade_id => $id, mnemonic => $char);
}
    
1;

