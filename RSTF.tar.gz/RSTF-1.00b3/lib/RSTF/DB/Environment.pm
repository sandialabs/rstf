##############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Environment.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 14:53:24 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Environment.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

# This package breaks symmetry -- by being a list, but not being named List
#
package RSTF::DB::Environment;
use strict;
use warnings;

use RSTF::DB::DBList;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBList);

use RSTF::DB::EnvironmentSetting;
use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'environment', id_slot=>'testcase_id');

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(settings testcase_id)]
);


my @default_args = (settings => [],
		    object_type => 'RSTF::DB::EnvironmentSetting',
		    list_field => 'settings',
		    key_slots => ['testcase_id'],
		    xmlwriter=>$xmlwriter);

sub init {
    my $self = shift;
    $self->SUPER::init(@default_args, @_);
    return $self;
}

sub fetch {
    my $self = shift;
    my $obj =  $self->SUPER::fetch(' Order by ordinal ');
    return $obj;
}

sub prepare_insert {
    my $self = shift;
    my $objects = shift;
    my $ord = 1;
    foreach my $cmd (@$objects) {
	$cmd->ordinal($ord++);
    }
}


sub prepare_update {
    my $self = shift;
    # Kill old values?
    $self->prepare_insert(@_);
}


sub add {
  my $self = shift;
  my $settings = $self->settings();
  if ($settings) {
    foreach my $x (@$settings) {
      $x->add();
    }
  }
}


sub remove {
  my $self = shift;
  my $settings = $self->settings();
  if ($settings) {
    foreach my $x (reverse @$settings) {
      $x->remove();
    }
  }
}

1;

