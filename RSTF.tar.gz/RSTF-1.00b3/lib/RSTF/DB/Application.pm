###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Application.pm
# 
# Created by: Robert A. Ballance		Fri Apr  9 08:41:05 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Application.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::Application;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'application', id_slot=>'app_id');

use RSTF::DB::ApplicationPlanning;
use RSTF::DB::Platform;

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [ qw(name
					app_id
					package_type_id
					description
					lab
					status
					primary_language
					completion_date
					
					)]
			);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub describe {
    my $self = shift;
    return  $self->name;
}

sub print_description {
    my $self = shift;
    print "Application: " . $self->describe . "\n";
}

sub package_type {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'package_type_id',
      object_slot => '_package_type_slot',
      object_classname => 'RSTF::DB::PackageType'
      }, @_);
}

# use nested object fields?
sub script_compile {
    my $self = shift;
    $self->compile_nested_fields();
    $self->purify();
}

sub planning_status {
  my $self = shift;
  my $platform = shift;

  unless ($self->app_id) {
      $self->insert();
  }
  die "No platform id " unless ($platform->platform_id);
  my $status = new RSTF::DB::ApplicationPlanning(app_id => $self->app_id,
						platform_id => $platform->platform_id);
  my $x = $status->fetch();
  unless ($x) {
      $status->insert();
  }
  return $status;
}

# use nested object fields?
sub write_xml_body {
  my $self = shift;
  print 
      $self->xml_wrap_tag('name', $self->name);
      
  my $dao = $self->dao();
  if ($self->dao) {
    my $nested_obj = $self->dao()->nested_object_fields();
    foreach my $field (@$nested_obj) {
      my $obj = $self->$field;
      if ($obj) {
	$obj->write_xml();
      }
    }
  }
}

1;

