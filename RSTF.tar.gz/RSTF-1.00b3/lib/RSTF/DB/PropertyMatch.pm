###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Property.pm
# 
# Created by: Robert A. Ballance		Wed Apr 14 13:31:13 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PropertyMatch.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
#   property_id SERIAL PRIMARY KEY,

#   testcase_id   INTEGER REFERENCES TestCase
#           ON DELETE CASCADE,

#   name PropertyName,
#   pattern PropertyExpr,
#   filename FileName,
#   filepath FilePath,
#   matched  boolean,
#   value     VARCHAR(128)

package RSTF::DB::PropertyMatch;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [ qw(property_match_id
				       property_id
				       run_id
				       value
				       matched)]
);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'propertymatch', id_slot=>'property_match_id', other_attr=>[qw(property_id run_id)]);

my @init_args = (xmlwriter=>$xmlwriter);
sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
  return $self;
}

sub property {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'property_id',
      object_slot => '_property_slot',
      object_classname => 'RSTF::DB::Property'   }, @_);
}

# This function is called to properly fix up the property_id slot,
# in case the property was not in the DB when the Match was
# created.
sub fixup_property_id {
    my $self = shift;
    unless ($self->property_id) {
	my $prop = $self->property;
	if ($prop) {
	    my $id = $prop->property_id;
	    $self->property_id($id);
	} else {
	    log_warn("No property found for property match -- are you missing a file?");
	}
    }
}

# Override the given one for now.
sub write_xml_body {
    my $self = shift;
    print
	$self->xml_wrap_tag('result', $self->matched),
	$self->xml_wrap_tag('value', $self->value);
}

sub valid_value {
    my $self = shift;
    return ($self->matched eq 'true');
}

sub property_name {
    my $self = shift;
    my $prop = $self->property;
    if ($prop) {
	return $prop->property_name();
    }
    return undef;
}

1;

