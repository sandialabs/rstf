###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Run.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 18:51:02 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Run.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################


package RSTF::DB::Run;
use strict;
use warnings;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::DBObject);


use RSTF::DB::DBObject;
use RSTF::DB::Contact;
use RSTF::DB::AppBinary;
use RSTF::DB::TestCase;
use RSTF::DB::Outcome;
use RSTF::DB::XMLWriter;
use RSTF::DB::PropertyMatchList;
use RSTF::DB::Purpose;
use RSTF::DB::SystemConfiguration;

my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'run', id_slot=>'run_id');
my $outcome_writer = new RSTF::DB::XMLWriter(tag => 'outcome', id_slot=>'outcome_id');
my $validation_writer = new RSTF::DB::XMLWriter(tag => 'validationgrade', id_slot=>'grade_id', is_empty=>1, other_attr=>['mnemonic']);

my $runner_writer = new RSTF::DB::XMLWriter(tag => 'runner', id_slot=>'runner_id', is_empty=>1);
my $witness_writer = new RSTF::DB::XMLWriter(tag => 'witness', id_slot=>'witness_id', is_empty=>1);

my $match_writer = new RSTF::DB::XMLWriter(tag => 'propertymatchlist');

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(
				      run_id
				      outcome_id
				      testcase_id
				      appbinary_id
				      purpose_id
				      grade_id
				      validation_id

				      job_time
				      compile_time
				      preprocess_time
				      postprocess_time
				      validation_time
				      setup_time
				      cleanup_time
				      installation_time
				      grade_time
				      finally_time

				      scheduled_date
				      time_start
				      time_end
				      data_valid
				      
				      runner_id
				      runner_sig_time

				      witness_id
				      witness_sig_time

				      system_config_id
				      status
				      tag

				      property_matches
				      note
				      )]
		      );

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
  return $self;
}

sub update_child_keys {
    my $self = shift;
    my $keyval = [$self->run_id];
    my $dao = $self->dao();
    if ($self->dao) {
	my $nested_obj = $self->dao()->nested_object_fields();
	foreach my $field (@$nested_obj) {
	    my $obj = $self->$field;
	    if ($obj) {
		$obj->set_child_keys($keyval);
	    }
	}
    }
}

sub script_compile {
    my $self = shift;
    $self->compile_nested_fields();
    if ($self->purpose()) {
	$self->purpose()->script_compile();
    }
    if ($self->grade()) {
	$self->grade()->script_compile();
    }
    if ($self->validation_result()) {
	$self->validation_result()->script_compile();
    }
    if ($self->outcome()) {
	$self->outcome()->script_compile();
    }
    if ($self->runner()) {
	$self->runner()->script_compile();
    }
    if ($self->witness()) {
	$self->witness()->script_compile();
    }

    if ($self->system_configuration()) {
	$self->system_configuration->script_compile();
    }
    $self->purify();
}

sub appbinary {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'appbinary_id',
      object_slot => '_appbinary_slot',
      object_classname => 'RSTF::DB::AppBinary'   }, @_);
}

sub testcase {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'testcase_id',
      object_slot => '_testcase_slot',
      object_classname => 'RSTF::DB::TestCase'   }, @_);
}

sub system_configuration {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'system_config_id',
      object_slot => '_sysconfig_slot',
      object_classname => 'RSTF::DB::SystemConfiguration'   }, @_);
}

sub grade {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'grade_id',
      object_slot => '_grade_slot',
      object_classname => 'RSTF::DB::Grade'   }, @_);
}

sub validation_result {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'validation_id',
      object_accessor => 'grade_id',
      object_slot => '_validation_id_slot',
      object_classname => 'RSTF::DB::Grade'   }, @_);
}

sub purpose {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'purpose_id',
      object_slot => '_purpose_slot',
      object_classname => 'RSTF::DB::Purpose'   }, @_);
}


sub outcome {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'outcome_id',
      object_slot => '_outcome_slot',
      object_classname => 'RSTF::DB::Outcome'   }, @_);
}

sub runner {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'runner_id',
      object_slot => '_runner_slot',
      object_accessor => 'contact_id',
      object_classname => 'RSTF::DB::Contact'   }, @_);
}

sub witness {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'witness_id',
      object_slot => '_witness_slot',
      object_accessor => 'contact_id',
      object_classname => 'RSTF::DB::Contact'   }, @_);
}

sub _prompt {
    my $self = shift;
    my $field = shift;
    printf "Run %d is already signed!\n", $self->run_id;
    print "Overwrite (y/N)? "; 
    flush STDOUT;
    my $line = <STDIN>;
    if ($line =~ m/y[e]?[s]?/i) {
	return 1;
    }
    return 0;
}


# update the runner field.
# If this is a change, and 'force' is false, the console will be prompted for input
# return 1 if any changes
sub sign_run {
    my $self = shift;
    my $contact = shift;
    my $force = shift;
    return 0 unless($contact);
    if ($self->runner_id) {
	if ($contact->contact_id != $self->runner_id) {
	    if ($force || $self->_prompt('signed')) {
		$self->runner($contact);
		my $now = localtime;
		$self->runner_sig_time($now);
		return 1;
	    }
	}
    } else {
	$self->runner($contact);
	my $now = localtime;
	$self->runner_sig_time($now);
	return 1;
    }
    return 0;
}

# Update the witness field.
# If this is a change, and 'force' is false, the console will be prompted for input
# return 1 if any changes

sub witness_run {
    my $self = shift;
    my $contact = shift;
    my $force = shift;
    return 0 unless($contact);

    if ($self->witness_id) {
	if ($contact->contact_id != $self->witness_id) {
	    if ($force || $self->_prompt('witnessed')) {
		$self->witness($contact);
		my $now = localtime;
		$self->witness_sig_time($now);
		return 1;
	    }
	}
    } else {
	$self->witness($contact);
	my $now = localtime;
	$self->witness_sig_time($now);
	return 1;
    }
    return 0;
}

sub add_note {
    my $self = shift;
    my $string = shift;
    if ($string) {
	my $note = $self->note();
	if ($note) {
	    $note .= "\n" . $string;
	} else {
	    $note = $string;
	}
	$self->note($string);
    }
}


sub output_results {
    my $self = shift;
    return $self->write_xml;
}


sub write_xml_body {
    my $self = shift;
    print $self->xml_wrap_tag('starttime', $self->time_start);

    if ($self->purpose) {
	$self->purpose->write_xml();
    }

    print $self->xml_wrap_tag('runtag', $self->tag);

    if ($self->system_configuration()) {
	$self->system_configuration->write_xml();
    }

    if ($self->appbinary()) {
	$self->appbinary->write_xml();
    }

    print 
	$outcome_writer->header($self),
	$outcome_writer->format_value('description', $self->note || ' '),
	$outcome_writer->footer();



    print
	$self->xml_result_time($self->setup_time() , "setuptime"),
	$self->xml_result_time($self->compile_time() , "compiletime"),
	$self->xml_result_time($self->installation_time() , "installationtime"),
	$self->xml_result_time($self->preprocess_time() , "preprocesstime"),
	$self->xml_result_time($self->job_time() , "jobtime"),
	$self->xml_result_time($self->postprocess_time() , "postprocesstime"),
	$self->xml_result_time($self->validation_time() , "validationtime"),
	$self->xml_result_time($self->cleanup_time() , "cleanuptime"),
	$self->xml_result_time($self->finally_time() , "finallytime"),


	$self->xml_result_time($self->grade_time() , "gradetime");


    print $validation_writer->header($self->validation_result);

    if ($self->grade) {
	$self->grade->write_xml();
    }

    if ($self->property_matches) {
        $self->property_matches->write_xml();
    }

    print 
	$self->xml_wrap_tag('endtime', $self->time_end );
}

sub primary_metric {
    my $self = shift;

    my $testcase = $self->testcase();
    my $value;
    if ($testcase) {
	my $fieldname = $testcase->primary_metric_name || 'job_time';
	eval {
	    $value = $self->$fieldname;
	};
	unless ($@) {
	    return $value;
	}
	# no such field
	if ($self->property_matches()) {
	    return $self->property_matches()->find($fieldname);
	}
    }
    return undef;
}

1;



