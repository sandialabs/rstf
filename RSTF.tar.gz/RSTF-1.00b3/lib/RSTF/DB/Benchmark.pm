###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Benchmark.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Benchmark.pm,v $
# $Revision: 1.10 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::Benchmark;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Application;
use RSTF::DB::Contact;
use RSTF::DB::BenchmarkState;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'benchmark', id_slot=>'benchmark_id', other_attr=>[qw(nickname tag)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     platform
				     title
				     description
				     nickname
				     tag
				     app_config
				     priority
				     root_directory
				     log_path
				     log_filename

				     benchmark_state
				     analyst

				     benchmark_id
				     testcases
				     app_id
				    )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub update_child_keys {
  my $self = shift;
  my  $tc = $self->testcases;  
  if ($tc) {
    foreach my $testcase (@$tc) {
      $testcase->benchmark($self);
      $testcase->platform($self->platform);
    }
  }
}

sub store {
  my $self = shift;
  if ($self->application) {
      $self->application()->store();
      unless ($self->app_id) {
	  $self->app_id($self->application->app_id);
      }
  }
  $self->SUPER::store();
  $self->update_child_keys();
  my  $tc = $self->testcases;  
  if ($tc) {
    foreach my $testcase (@$tc) {
      $testcase->store();
    }
  }
}

sub application {
  my $self = shift;
  return $self->object_access({ 
			   id_slot => 'app_id',
			   object_slot => '_app_slot',
			   object_classname => 'RSTF::DB::Application'
			  }, @_);
}

sub script_compile {
  my $self = shift;
  $self->purify();
  if ($self->application()) {
    $self->application->script_compile();
  }
  if ($self->platform) {
    $self->platform->script_compile();
  }
  my  $tc = $self->testcases;  
  if ($tc) {
    foreach my $testcase (@$tc) {      $testcase->script_compile();
    }
  }
}

sub get_parallel_dispatch {
    my $self = shift;
    my $platform = shift;
    my  $tc = $self->testcases;  
    if ($tc) {
	foreach my $testcase (@$tc) {
	    my $d = $testcase->get_parallel_dispatch($platform);
	    if ($d) {
		return $d;
	    }
	}
    }
}
    
    

my $log_xmlwriter = new RSTF::DB::XMLWriter(tag => 'log');

sub write_xml_body {
    my $self = shift;
    print $self->xml_wrap_tag('title', $self->title);
    print $self->xml_wrap_tag('description', $self->description);

    if ($self->platform) {
	$self->platform->write_xml();
    }
    print $self->xml_wrap_tag('rootdirectory', $self->root_directory);
    print 
	$log_xmlwriter->header(),
	$log_xmlwriter->format_value('directory', $self->log_path),
	$log_xmlwriter->format_value('name', $self->log_filename),
	$log_xmlwriter->footer();

    if ($self->application()) {
	$self->application->write_xml();
    }
    my  $tc = $self->testcases;  
    if ($tc) {
	foreach my $testcase (@$tc) {
	    $testcase->write_xml();
	}
    }
}

1;
