###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# PropertyMatchList.pm
# 
# Created by: Robert A. Ballance		Wed Apr 14 14:03:57 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PropertyMatchList.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::PropertyMatchList;
use strict;
use warnings;

use RSTF::DB::DBList;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::DBList);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(run_id values)]
);

use RSTF::DB::PropertyMatch;
use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'propertymatchlist', other_attr=>[qw(run_id)]);

my @default_args = (values => [],
		    object_type => 'RSTF::DB::PropertyMatch',
		    key_slots => ['run_id'],
		    list_field => 'values',
		    xmlwriter=>$xmlwriter
		    );

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

sub prepare_insert {
    my $self = shift;
    my $objects = shift;
    foreach my $obj (@$objects) {
	$obj->fixup_property_id();
    }
}

sub prepare_update {
    my $self = shift;
    $self->prepare_insert(@_);
}

sub find {
    my $self = shift;
    my $property_name = shift;

    my $objects = $self->values();

    foreach my $obj (@$objects) {
	if ($obj->property_name() eq $property_name) {
	    if ($obj->valid_value) {
		return $obj->value();
	    }
	}
    }
    return undef;
}

1;

