###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# CompileTool.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/CompileTool.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::CompileTool;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Platform;
use RSTF::DB::Vendor;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'compiletool', id_slot=>'compile_tool_id', other_attr=>[qw(platform_id vendor_id)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     tool_id
				     platform_id
				     vendor_id
				     name
				     version
				     language
				     output_parser
				    )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub platform {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'platform_id',
      object_slot => '_platform_slot',
      object_classname => 'RSTF::DB::Platfrom'
      }, @_);
}

sub vendor {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'vendor_id',
      object_slot => '_vendor_slot',
      object_classname => 'RSTF::DB::Vendor'
      }, @_);
}

sub write_xml_body {
    my $self = shift;
    print
	$self->xml_wrap_tag('version', $self->version),
	$self->xml_wrap_tag('language', $self->language);
}

1;
