###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Utils.pm
# 
# Created by: Robert A. Ballance		Wed Apr  7 09:07:47 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Utils.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
# Miscellaneous helper routines for argument lists, etc.
#
# 
# 
###############################################################################

package RSTF::DB::Utils;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our @EXPORT = qw(
		 split_argument_list
		 subst_env_vars
		 dump_stack

		 format_date
		 format_datetime
		 format_datetime_with_tz

		 add_times
);

our %EXPORT_TAGS = (
   dates => [ qw( format_date  format_datetime format_datetime_with_tz) ],
   times => [ qw(add_times) ],
   utils  => [ qw(split_argument_list dump_stack subst_env_vars) ]
);

###############################################################################
# 
# Utility Functions
# 
###############################################################################

# @args = split_argument_list('a b c d -e 123 "my name"');
#
# Function to split an argument list just like the shell does --- it handles
# arguments that are single words, or quoted arguments like "a b \" c"
#
# Adapted from Mastering Regular Expressions, Jeffrey E.F Friedl,
# Oreilly, 1997, p. 290, CSV parser.
#
sub split_argument_list {
  my $text = shift;

  my $nasty_quotes = 0;		# Set $nasty_quotes if we have any embedded double-quote characters.
  if ($text =~ /\\\"/) {
    $nasty_quotes++;
  }

  my @results = ();
  push (@results, $+) while $text =~ m{
		    "([^\"\\]*(?:\\.[^\"\\]*)*)"\s? # quoted string
		    | (\S+)\s?	# Anything else
		   }gx;

  if ($nasty_quotes) {
    # Clear out quoted quotes, if any

    my @final_results = ();
    foreach my $v (@results) {
      if ($v =~ /\\\"/) {
	$v =~ s/\\\"/\"/g;
      }
      push @final_results, $v;
    }
    return @final_results;
  }
  # No quoted quotes --- just return the list
  return @results;
}

sub dump_stack {
    my $n = shift;
    for (my $i = $n; $i >= 1 ; $i--) {
	my ($package, $filename, $line, $subr, $has_args, $want_array) = caller($i);
	if ($package) {
	    print STDERR "$i: $subr $filename $line\n";
	}
    }
}

# Package method
sub subst_env_vars {
    my $string = shift;
    while ($string =~ /\$(\w+)/gc) {
	my $var = $1;
	my $val = $ENV{$var};
	die "Undefined environment variable $var" unless $val;
	$string =~ s/\$$var/$val/g;
    }
    return $string;
}

###############################################################################
# 
# Date Manipulations
#
###############################################################################

use Date::Manip;
# $x = format_date('a date string')
#  Parse any date parseable by Date::Manip, and return an ISO 8601 date
#
sub format_date {
  my $date = shift;
  if ($date) {
      my $dm = ParseDate($date);
      my $formatted_date = UnixDate($dm, "%Y-%m-%d");
      unless ($formatted_date)  {
	  warn "Invalid date $date\n";
      }
      return $formatted_date;

  }
  return $date;
}

# $x = format_datetime('a date string')
#  Parse any date parseable by Date::Manip, and return an ISO 8601 date/time value
#
sub format_datetime {
  my $date = shift;
  if ($date) {
    my $dm = ParseDate($date);
    return UnixDate($dm, "%Y-%m-%d %H:%M:%S");
  }
  return $date;
}


# $x = format_datetime_with_tz('a date string')
#  Parse any date parseable by Date::Manip, and return an ISO 8601 date/time value including the timezone
#

sub format_datetime_with_tz {
  my $date = shift;
  if ($date) {
    my $dm = ParseDate($date);
    return UnixDate($dm, "%Y-%m-%d %H:%M:%S %Z");
  }
  return $date;
}

###############################################################################
# 
# Time Manipulations
# 
###############################################################################

# $x = add_time($time1, $time2);
# All times are in "HH:MM:SS" format.
#
sub add_times {
    my $time1 = shift;
    my $time2 = shift;

    my $t1 = _parse_time($time1);
    my $t2 = _parse_time($time2);
    my $t3 = $t1 + $t2;
    return _format_time($t3);
}

sub _format_time {
    use integer;
    my $time = shift;
    my $hrs = $time / 3600;
    $time  = $time % 3600;
    my $min = $time / 60;
    my $sec = $time % 60;
    return sprintf("%02d:%02d:%02d", $hrs, $min, $sec);
}

sub _parse_time {
    my $time = shift || '0:00:00';
    if ($time =~ /(\d+):(\d\d):(\d\d)/) {
	return $1 * 3600 + $2 * 60 + $3;
    }
    return 0;
}

1;
