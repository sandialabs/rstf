###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# OutputDirectory.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 19:01:45 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/OutputDirectory.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::OutputDirectory;
use strict;
use warnings;

use RSTF::DB::DBObject;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);
#use RSTF::DB::DAO::LookupTable;
use RSTF::DB::OutputDirectoryType;
use RSTF::FilePath;

use RSTF::DB::DAOFactory;

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw (testcase_id
				       output_directory_id
				       number
				       path
				       directories
				       type_id) ]);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'datadirectory',
					id_slot=>'output_directory_id',
					other_attr=>[qw(testcase_id type_id type_name) ]);

my @init_args = (xmlwriter=>$xmlwriter, number=>1);
sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
  return $self;
}


# my $lookup_table;

sub type_name {
  my $self = shift;
  my $arg = shift;
  if ($arg) {
      my $type = RSTF::DB::OutputDirectoryType->find_by_name($arg);
#$self->lookup_table()->lookup_by_name($arg);
      die "No output directory type found for $arg" unless($type);
      $self->type($type);
  }
}

sub type {
    my $self = shift;
    return $self->object_access(
				{ 
				    id_slot => 'type_id',
				    object_slot => '_type_slot',
				    object_classname => 'RSTF::DB::OutputDirectoryType'
				    }, @_);
}

sub write_xml_body {
  my $self = shift;
  print $self->xml_wrap_tag('directory', $self->path);
  print $self->xml_wrap_tag('number', $self->number);
}

sub allocate {
    my $self = shift;
    my $username = shift;
    my $testname = shift;
    my $test_size = shift;

    my $path_prefix = $self->path;
    my $file = expand_path(sprintf($path_prefix, $username, $testname, $test_size));
    make_directory($file);
    $self->directories([$file]);
    return $file;
}

1;
