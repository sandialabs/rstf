###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# BenchmarkPlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/BenchmarkPlanning.pm,v $
# $Revision: 1.2 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::BenchmarkPlanning;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Platform;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'benchmarkstatus',
					id_slot=>'benchmark_plan_id',
					other_attr=>[qw(platform_id)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     benchmark_plan_id
				     benchmark_id
				     platform_id
				     source_code_ready 
				     compile_scripts_available
				     compile_scripts_tested   
				     )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub platform {
  my $self = shift;
  return $self->object_access({id_slot => 'platform_id',
			       object_slot => '_platform_slot',
			       object_classname => 'RSTF::DB::Platform'}, @_);
}


sub write_xml_body {
    my $self = shift;
    warn "write_xml_body not defined for BenchmarkPlanning\n";
}

1;
