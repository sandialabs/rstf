##############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestCase.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 18:50:22 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/TestCase.pm,v $
# $Revision: 1.11 $
# $Name:  $
# $State: Exp $
# 
###############################################################################


package RSTF::DB::TestCase;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::Contact;
use RSTF::DB::TestType;
use RSTF::DB::Platform;
use RSTF::DB::Benchmark;
use RSTF::DB::BenchmarkState;
use RSTF::DB::Run;
use RSTF::DB::TestCasePlanning;
use RSTF::DB::AppBinary;

use RSTF::DB::PropertyList;
use RSTF::DB::Environment;
use RSTF::ToolInfo;
use RSTF::FilePath;
use Sys::Hostname;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;

# Package variable for writing test cases
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'testcase', id_slot=>'testcase_id');

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [ qw(
					
					testcase_id
					benchmark_id
					test_type_id
					appbinary_id
					
					name
					benchmark_state_id
					platform_id
					
					procs_per_node
					nodes_required
					size
					description
					
					prepared_by_id
					validated_by_id
					
					data_directories
					est_walltime
					
					working_directory
					stdout
					stderr
					
					red_proc_mode
					
					output_files
					environment
					
					preprocess_commands
					exec_commands
					postprocess_commands
					validate_commands
					grade_commands
					property_matchers

					setup_commands
					compile_commands
					installation_commands
					cleanup_commands
					final_commands

					run_list
					primary_metric_name
					
					actual_appbinary
					)],
			);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
    my $self = shift;  
    $self->SUPER::init(@init_args, @_);
    return $self;
}

sub benchmark {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'benchmark_id',
      object_slot => '_benchmark_slot',
      object_classname => 'RSTF::DB::Benchmark'
      }, @_);
}

sub benchmark_state {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'benchmark_state_id',
      object_slot => '_benchmark_state_slot',
      object_classname => 'RSTF::DB::BenchmarkState'
      }, @_);
}

sub test_type {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'test_type_id',
      object_slot => '_test_type_slot',
      object_classname => 'RSTF::DB::TestType'
      }, @_);
}

sub platform {
  my $self = shift;
  return $self->object_access({id_slot => 'platform_id',
			       object_slot => '_platform_slot',
			       object_classname => 'RSTF::DB::Platform'}, @_);
}

sub validated_by {
  my $self = shift;
  return $self->object_access({id_slot => 'validated_by_id',
			       object_slot => '_validated_by_slot',
			       object_classname => 'RSTF::DB::Contact'
			       }, @_);
}

# The appbinary object in the database is just a place holder for
# path information.
# 
# During the RUN, the actual_appbinary is updated to have the md5sum
# in the information.
# The update is handled by the update_appbinary() method in this class.
#
# Runs use the actual_appbinary() for their information.
#
sub appbinary {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'appbinary_id',
      object_slot => '_executable_slot',
      object_classname => 'RSTF::DB::AppBinary'   }, @_);
}

sub prepared_by {
  my $self = shift;
  return $self->object_access({id_slot => 'prepared_by_id',
			       object_slot => '_prepared_by_slot',
			       object_classname => 'RSTF::DB::Contact'
			       }, @_);
}

sub planning_status {
    my $self = shift;
    unless ($self->testcase_id) {
	$self->insert();
    }
    my $status = RSTF::DB::TestCasePlanning->find_by_name($self->testcase_id);
    unless ($status) {
	$status = new RSTF::DB::TestCasePlanning(testcase_id=>
						 $self->testcase_id);
	$status->insert();
    }
    return  $status;
}
      
sub update_child_keys {
    my $self = shift;
    my $keyval = [$self->testcase_id];
    my $dao = $self->dao();
    if ($self->dao) {
	my $nested_obj = $self->dao()->nested_object_fields();
	foreach my $field (@$nested_obj) {
	    my $obj = $self->$field;
	    if ($obj) {
		$obj->set_child_keys($keyval);
	    }
	}
    }
}

sub script_compile {
    my $self = shift;
    $self->compile_nested_fields();
    $self->purify();
}

sub total_time {
    return $_[0]->total_execution_time();
}

sub job_time {
    return $_[0]->exec_commands()->execution_time();
}

sub preprocess_time {
    return $_[0]->preprocess_commands()->execution_time();
}

sub postprocess_time {
    return $_[0]->postprocess_commands()->execution_time();
}

sub validation_time {
    return $_[0]->validate_commands()->execution_time();
}

sub grade_time {
    return $_[0]->grade_commands()->execution_time();
}

sub compile_time {
    return $_[0]->compile_commands()->execution_time();
}

sub setup_time {
    return $_[0]->setup_commands()->execution_time();
}

sub cleanup_time {
    return $_[0]->cleanup_commands()->execution_time();
}

sub installation_time {
    return $_[0]->installation_commands()->execution_time();
}

sub finally_time {
    return $_[0]->final_commands()->execution_time();
}

# If I have an app binary, check that it exists and get its md5sum.
# Stash these results into the actual_appbinary.
#
sub check_app_binary {
    my $self = shift;
    my $app = shift;
    my $timestamp = shift;
    my $config  = shift;

    my $appbinary = $self->appbinary();
    if ($appbinary) {
	# expand the path relative to the root directory!
	# Otherwise it will be working-directory relative
	my $file = $appbinary->expanded_path();
	if ($file) {
	    if (-e $file && -r $file) {
		my $sum = RSTF::ToolInfo::do_md5($file, $config);
		my $bytecount = RSTF::ToolInfo::get_bytecount($file);
		if ($sum) {
		    my $actual = RSTF::DB::AppBinary->find_by_name({md5sum=>$sum, appname=>$app->name, platform=>$self->platform->name});
		    unless ($actual) {
			$actual = new RSTF::DB::AppBinary(
							  app_id=>$app->app_id,
							  app_name => $app->name,
							  platform_id => $self->platform->platform_id,
							  compilation_date=>$timestamp,
							  compiled_by_email=>$config->runner,
							  compilation_host=>hostname(),
							  md5sum => $sum,
							  filepath => $file,
							  byte_count =>$ bytecount);
		    }
		    $self->actual_appbinary($actual);
		}
	    } else {
		die "Unable to access $file as the application binary\n";
	    }
	} else {
	    die "Invalid appbinary object in testcase\n";
	}
    }
}

sub write_xml_body  {
    my $self = shift;
    print $self->xml_wrap_tag('name', $self->name);
    print $self->xml_wrap_tag('description', $self->description);
    print $self->xml_wrap_tag('size', $self->size);

    $self->platform->write_xml();
    $self->environment ->write_xml;
    if ($self->actual_appbinary) {
	$self->actual_appbinary ->write_xml;
    }
    print $self->xml_wrap_tag('workingdirectory', $self->working_directory);

    $self->setup_commands ->write_xml;
    $self->compile_commands ->write_xml;
    $self->installation_commands->write_xml;
    # stdout, stderr
    print $self->xml_wrap_tag('stdout', $self->stdout);
    print $self->xml_wrap_tag('stderr', $self->stdout);
    $self->data_directories->write_xml;;

    $self->preprocess_commands->write_xml;
    $self->exec_commands ->write_xml;
    $self->postprocess_commands ->write_xml;
    $self->validate_commands ->write_xml;
    $self->grade_commands ->write_xml;
    $self->final_commands ->write_xml;
    $self->property_matchers->write_xml;
    $self->cleanup_commands ->write_xml;

    $self->run_list ->write_xml;

}

sub sign_and_witness {
    my $self = shift;
    my $signer = shift;
    my $witness = shift;
    my $force = shift;
    $self->run_list ->sign_and_witness($signer, $witness, $force);
}

sub get_parallel_dispatch {
    print STDERR "top level call\n";    
    return undef;
}

1;

