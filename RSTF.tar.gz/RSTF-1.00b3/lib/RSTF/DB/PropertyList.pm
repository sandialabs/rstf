###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# PropertyList.pm
# 
# Created by: Robert A. Ballance		Wed Mar 17 11:11:16 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/PropertyList.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::PropertyList;
use strict;
use warnings;

use RSTF::DB::DBList;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::DBList);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw(matchers testcase_id)]
);

use RSTF::DB::Property;
use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'propertylist', id_slot=>'testcase_id');

my @default_args = (matchers => [],
		    object_type => 'RSTF::DB::Property',
		    key_slots => ['testcase_id'],
		    list_field => 'matchers',
		    xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}


1;

