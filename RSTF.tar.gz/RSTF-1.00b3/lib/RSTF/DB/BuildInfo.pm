###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# BuildInfo.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/BuildInfo.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::BuildInfo;
use strict;
use warnings;

use RSTF::DB::DBObject;
use RSTF::DB::AppBinary;
use RSTF::DB::CompileTool;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'buildinfo', id_slot=>'executable_id', other_attr=>[qw(compiler_id)]);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     id
				     tool_id
				     executable_id
				     filename
				     directory
				     raw_flags
				     expanded_flags
				     ordinal
				    )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub tool {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'compile_tool_id',
      object_slot => '_compiler_slot',
      object_classname => 'RSTF::DB::CompileTool'
      }, @_);
}

sub executable {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'executable_id',
      object_slot => '_executable_slot',
      object_classname => 'RSTF::DB::AppBinary'
      }, @_);
}

sub write_xml_body {
    my $self = shift;
    print $self->xml_wrap_tag('filename', $self->filename);
    print $self->xml_wrap_tag('directory', $self->directory);
    print $self->xml_wrap_tag('raw_flags',      $self->raw_flags);
    print $self->xml_wrap_tag('expanded_flags', $self->expanded_flags);
}

1;
