###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Machine.pm
# 
# Created by: Robert A. Ballance		Fri May 28 13:42:53 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/Machine.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  >>>description of file contents<<<
# 
###############################################################################

package RSTF::DB::Machine;
use strict;
use warnings;
use RSTF::DB::Platform;

use RSTF::DB::DBObject;
use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use Class::MethodMaker(
		       new_with_init=>'new',
		       get_set=> [qw(machine_name machine_id platform_id classified)]
		      );

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'machine', id_slot=>'machine_id', 
					other_attr=>[qw(machine_name platform_id classified)],
					is_empty=>1);

my @init_args = (xmlwriter=>$xmlwriter);
sub init {
  my $self = shift;  
  $self->SUPER::init(@init_args, @_);
  return $self;
}

sub platform {
  my $self = shift;
  return $self->object_access({ 
      id_slot => 'platform_id',
      object_slot => '_platform_slot',
      object_classname => 'RSTF::DB::Platform'
      }, @_);
}

sub script_compile {
    my $self = shift;
    $self->platform->script_compile();
    $self->purify();
}

# Machine should only be in the DB once for each unique 
# instance. Skip the real insert if it is already there!
#
sub insert {
    my $self = shift;
    unless (defined($self->machine_id)) {
	return $self->SUPER::insert();
    }
    return undef;
}

1;
