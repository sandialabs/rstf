###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestCasePlanning.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/TestCasePlanning.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::DB::TestCasePlanning;
use strict;
use warnings;

use RSTF::DB::DBObject;

use vars qw(@ISA);
@ISA=qw(RSTF::DB::DBObject);

use RSTF::DB::XMLWriter;
my $xmlwriter = new RSTF::DB::XMLWriter(tag => 'testcasestatus', id_slot=>'testcase_plan_id', );

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set=> [qw(
				     testcase_plan_id
				     testcase_id 
				     data_set_on_hand 
				     inputs_prepared  
				     sample_scripts_available
				     rst_scripts_written   
				     rst_scripts_tested   
				     preliminary_runs_scheduled 
				     preliminary_runs_complete 
				     final_runs_scheduled    
				     final_runs_complete  
				     )]
);

my @init_args = (xmlwriter=>$xmlwriter);

sub init {
  my $self = shift;  
  return $self->SUPER::init(@init_args, @_);
}

sub write_xml_body {
    my $self = shift;
    warn "write_xml_body not defined for TestCasePlanning\n";
}

1;
