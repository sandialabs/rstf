package RSTF::DB::Cache::Outcome;
use RSTF::DB::Outcome;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'failed' => bless( {
                                  'name' => 'Failed',
                                  'outcome_id' => '4',
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::Outcome' ),
             'completed' => bless( {
                                     'name' => 'Completed',
                                     'outcome_id' => '5',
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::Outcome' ),
             'scheduled' => bless( {
                                     'name' => 'Scheduled',
                                     'outcome_id' => '2',
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::Outcome' ),
             'not scheduled' => bless( {
                                         'name' => 'Not scheduled',
                                         'outcome_id' => '1',
                                         'dao' => undef,
                                         '_cached_object_slots' => {}
                                       }, 'RSTF::DB::Outcome' ),
             'initiated' => bless( {
                                     'name' => 'Initiated',
                                     'outcome_id' => '3',
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::Outcome' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Outcome(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
