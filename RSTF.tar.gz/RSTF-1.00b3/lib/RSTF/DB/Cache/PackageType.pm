package RSTF::DB::Cache::PackageType;
use RSTF::DB::PackageType;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'application' => bless( {
                                       'name' => 'Application',
                                       'package_type_id' => '1',
                                       'dao' => undef,
                                       '_cached_object_slots' => {}
                                     }, 'RSTF::DB::PackageType' ),
             'library' => bless( {
                                   'name' => 'Library',
                                   'package_type_id' => '2',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::PackageType' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::PackageType(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
