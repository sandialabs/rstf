package RSTF::DB::Cache::Vendor;
use RSTF::DB::Vendor;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'cray' => bless( {
                                'name' => 'Cray',
                                'vendor_id' => 1,
                                'xmlwriter' => bless( {
                                                        'tag' => 'vendor',
                                                        'is_empty' => 0,
                                                        'other_attr' => [
                                                                          'poc_id'
                                                                        ],
                                                        'id_slot' => 'vendor_id'
                                                      }, 'RSTF::DB::XMLWriter' ),
                                'poc_id' => undef,
                                'dao' => undef,
                                '_cached_object_slots' => {}
                              }, 'RSTF::DB::Vendor' ),
             'suse' => bless( {
                                'name' => 'SUSE',
                                'vendor_id' => 3,
                                'xmlwriter' => {},
                                'poc_id' => undef,
                                'dao' => undef,
                                '_cached_object_slots' => {}
                              }, 'RSTF::DB::Vendor' ),
             'pallas' => bless( {
                                  'name' => 'Pallas',
                                  'vendor_id' => 4,
                                  'xmlwriter' => {},
                                  'poc_id' => undef,
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::Vendor' ),
             'pgi' => bless( {
                               'name' => 'PGI',
                               'vendor_id' => 2,
                               'xmlwriter' => {},
                               'poc_id' => undef,
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Vendor' ),
             'snl' => bless( {
                               'name' => 'SNL',
                               'vendor_id' => 5,
                               'xmlwriter' => {},
                               'poc_id' => undef,
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Vendor' )
           };
$objects->{'suse'}{'xmlwriter'} = $objects->{'cray'}{'xmlwriter'};
$objects->{'pallas'}{'xmlwriter'} = $objects->{'cray'}{'xmlwriter'};
$objects->{'pgi'}{'xmlwriter'} = $objects->{'cray'}{'xmlwriter'};
$objects->{'snl'}{'xmlwriter'} = $objects->{'cray'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Vendor(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
