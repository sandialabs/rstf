package RSTF::DB::Cache::Platform;
use RSTF::DB::Platform;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'red storm' => bless( {
                                     'name' => 'Red Storm',
                                     'platform_id' => 2,
                                     'xmlwriter' => bless( {
                                                             'tag' => 'platform',
                                                             'is_empty' => 1,
                                                             'other_attr' => [
                                                                               'name'
                                                                             ],
                                                             'id_slot' => 'platform_id'
                                                           }, 'RSTF::DB::XMLWriter' ),
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::Platform' ),
             'red' => bless( {
                               'name' => 'Red',
                               'platform_id' => 1,
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Platform' )
           };
$objects->{'red'}{'xmlwriter'} = $objects->{'red storm'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Platform(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
