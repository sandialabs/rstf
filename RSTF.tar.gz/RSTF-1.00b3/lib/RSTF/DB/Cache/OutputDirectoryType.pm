package RSTF::DB::Cache::OutputDirectoryType;
use RSTF::DB::OutputDirectoryType;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'raid' => bless( {
                                'type_name' => 'raid',
                                'type_id' => '2',
                                'dao' => undef,
                                '_cached_object_slots' => {}
                              }, 'RSTF::DB::OutputDirectoryType' ),
             'viz' => bless( {
                               'type_name' => 'viz',
                               'type_id' => '3',
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::OutputDirectoryType' ),
             'scalar' => bless( {
                                  'type_name' => 'scalar',
                                  'type_id' => '1',
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::OutputDirectoryType' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::OutputDirectoryType(type_name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
