package RSTF::DB::Cache::FileCategory;
use RSTF::DB::FileCategory;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'output' => bless( {
                                  'name' => 'output',
                                  'xmlwriter' => bless( {
                                                          'tag' => 'category',
                                                          'is_empty' => 1,
                                                          'other_attr' => [
                                                                            'name'
                                                                          ],
                                                          'id_slot' => 'category_id'
                                                        }, 'RSTF::DB::XMLWriter' ),
                                  'dao' => undef,
                                  '_cached_object_slots' => {},
                                  'category_id' => '3'
                                }, 'RSTF::DB::FileCategory' ),
             'intermediate' => bless( {
                                        'name' => 'intermediate',
                                        'xmlwriter' => {},
                                        'dao' => undef,
                                        '_cached_object_slots' => {},
                                        'category_id' => '4'
                                      }, 'RSTF::DB::FileCategory' ),
             'input' => bless( {
                                 'name' => 'input',
                                 'xmlwriter' => {},
                                 'dao' => undef,
                                 '_cached_object_slots' => {},
                                 'category_id' => '2'
                               }, 'RSTF::DB::FileCategory' ),
             'source' => bless( {
                                  'name' => 'source',
                                  'xmlwriter' => {},
                                  'dao' => undef,
                                  '_cached_object_slots' => {},
                                  'category_id' => '1'
                                }, 'RSTF::DB::FileCategory' )
           };
$objects->{'intermediate'}{'xmlwriter'} = $objects->{'output'}{'xmlwriter'};
$objects->{'input'}{'xmlwriter'} = $objects->{'output'}{'xmlwriter'};
$objects->{'source'}{'xmlwriter'} = $objects->{'output'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::FileCategory(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
