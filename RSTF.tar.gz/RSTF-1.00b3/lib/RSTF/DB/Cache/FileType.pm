package RSTF::DB::Cache::FileType;
use RSTF::DB::FileType;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'log' => bless( {
                               'name' => 'Log',
                               'type_id' => '4',
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::FileType' ),
             'directory' => bless( {
                                     'name' => 'Directory',
                                     'type_id' => '3',
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::FileType' ),
             'script' => bless( {
                                  'name' => 'Script',
                                  'type_id' => '1',
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::FileType' ),
             'data' => bless( {
                                'name' => 'Data',
                                'type_id' => '5',
                                'dao' => undef,
                                '_cached_object_slots' => {}
                              }, 'RSTF::DB::FileType' ),
             'summary' => bless( {
                                   'name' => 'Summary',
                                   'type_id' => '8',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::FileType' ),
             'viz' => bless( {
                               'name' => 'Viz',
                               'type_id' => '6',
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::FileType' ),
             'source' => bless( {
                                  'name' => 'Source',
                                  'type_id' => '2',
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::FileType' ),
             'restart' => bless( {
                                   'name' => 'Restart',
                                   'type_id' => '7',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::FileType' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::FileType(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
