package RSTF::DB::Cache::CommandType;
use RSTF::DB::CommandType;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'postprocess' => bless( {
                                       'name' => 'postprocess',
                                       'type_id' => '5',
                                       'dao' => undef,
                                       '_cached_object_slots' => {}
                                     }, 'RSTF::DB::CommandType' ),
             'preprocess' => bless( {
                                      'name' => 'preprocess',
                                      'type_id' => '6',
                                      'dao' => undef,
                                      '_cached_object_slots' => {}
                                    }, 'RSTF::DB::CommandType' ),
             'finally' => bless( {
                                   'name' => 'finally',
                                   'type_id' => '10',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::CommandType' ),
             'compile' => bless( {
                                   'name' => 'compile',
                                   'type_id' => '2',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::CommandType' ),
             'setup' => bless( {
                                 'name' => 'setup',
                                 'type_id' => '1',
                                 'dao' => undef,
                                 '_cached_object_slots' => {}
                               }, 'RSTF::DB::CommandType' ),
             'score' => bless( {
                                 'name' => 'score',
                                 'type_id' => '9',
                                 'dao' => undef,
                                 '_cached_object_slots' => {}
                               }, 'RSTF::DB::CommandType' ),
             'runjob' => bless( {
                                  'name' => 'runjob',
                                  'type_id' => '7',
                                  'dao' => undef,
                                  '_cached_object_slots' => {}
                                }, 'RSTF::DB::CommandType' ),
             'validate' => bless( {
                                    'name' => 'validate',
                                    'type_id' => '8',
                                    'dao' => undef,
                                    '_cached_object_slots' => {}
                                  }, 'RSTF::DB::CommandType' ),
             'cleanup' => bless( {
                                   'name' => 'cleanup',
                                   'type_id' => '4',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::CommandType' ),
             'installation' => bless( {
                                        'name' => 'installation',
                                        'type_id' => '3',
                                        'dao' => undef,
                                        '_cached_object_slots' => {}
                                      }, 'RSTF::DB::CommandType' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::CommandType(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
