package RSTF::DB::Cache::Language;
use RSTF::DB::Language;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'f95' => bless( {
                               'name' => 'F95',
                               'xmlwriter' => bless( {
                                                       'tag' => 'language',
                                                       'is_empty' => 1,
                                                       'id_slot' => 'name'
                                                     }, 'RSTF::DB::XMLWriter' ),
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' ),
             'm4' => bless( {
                              'name' => 'm4',
                              'xmlwriter' => {},
                              'dao' => undef,
                              '_cached_object_slots' => {}
                            }, 'RSTF::DB::Language' ),
             'hpf' => bless( {
                               'name' => 'HPF',
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' ),
             'f90' => bless( {
                               'name' => 'F90',
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' ),
             'f77' => bless( {
                               'name' => 'F77',
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' ),
             'cpp' => bless( {
                               'name' => 'cpp',
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' ),
             'c' => bless( {
                             'name' => 'C',
                             'xmlwriter' => {},
                             'dao' => undef,
                             '_cached_object_slots' => {}
                           }, 'RSTF::DB::Language' ),
             'c++' => bless( {
                               'name' => 'C++',
                               'xmlwriter' => {},
                               'dao' => undef,
                               '_cached_object_slots' => {}
                             }, 'RSTF::DB::Language' )
           };
$objects->{'m4'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'hpf'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'f90'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'f77'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'cpp'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'c'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};
$objects->{'c++'}{'xmlwriter'} = $objects->{'f95'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Language(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
