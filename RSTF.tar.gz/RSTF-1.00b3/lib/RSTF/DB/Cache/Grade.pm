package RSTF::DB::Cache::Grade;
use RSTF::DB::Grade;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'p   ' => bless( {
                                'name' => 'pass',
                                'mnemonic' => 'P   ',
                                'description' => 'Test passed',
                                '_cached_object_slots' => {},
                                'grade_id' => '4',
                                'xmlwriter' => bless( {
                                                        'tag' => 'grade',
                                                        'is_empty' => 1,
                                                        'other_attr' => [
                                                                          'mnemonic'
                                                                        ],
                                                        'id_slot' => 'grade_id'
                                                      }, 'RSTF::DB::XMLWriter' ),
                                'dao' => undef,
                                'value' => '4'
                              }, 'RSTF::DB::Grade' ),
             'f   ' => bless( {
                                'name' => 'fail',
                                'mnemonic' => 'F   ',
                                'description' => 'Test failed',
                                '_cached_object_slots' => {},
                                'grade_id' => '1',
                                'xmlwriter' => {},
                                'dao' => undef,
                                'value' => '1'
                              }, 'RSTF::DB::Grade' ),
             'm   ' => bless( {
                                'name' => 'marginal',
                                'mnemonic' => 'M   ',
                                'description' => 'Marginal outcome --- review results, but probably ok',
                                '_cached_object_slots' => {},
                                'grade_id' => '3',
                                'xmlwriter' => {},
                                'dao' => undef,
                                'value' => '3'
                              }, 'RSTF::DB::Grade' ),
             'e   ' => bless( {
                                'name' => 'exceptional',
                                'mnemonic' => 'E   ',
                                'description' => 'Test passed, but with exceptional results --- better check them',
                                '_cached_object_slots' => {},
                                'grade_id' => '5',
                                'xmlwriter' => {},
                                'dao' => undef,
                                'value' => '5'
                              }, 'RSTF::DB::Grade' ),
             'd   ' => bless( {
                                'name' => 'dubious',
                                'mnemonic' => 'D   ',
                                'description' => 'Dubious outcome --- review results',
                                '_cached_object_slots' => {},
                                'grade_id' => '2',
                                'xmlwriter' => {},
                                'dao' => undef,
                                'value' => '2'
                              }, 'RSTF::DB::Grade' )
           };
$objects->{'f   '}{'xmlwriter'} = $objects->{'p   '}{'xmlwriter'};
$objects->{'m   '}{'xmlwriter'} = $objects->{'p   '}{'xmlwriter'};
$objects->{'e   '}{'xmlwriter'} = $objects->{'p   '}{'xmlwriter'};
$objects->{'d   '}{'xmlwriter'} = $objects->{'p   '}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Grade(mnemonic => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
