package RSTF::DB::Cache::TestType;
use RSTF::DB::TestType;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'stretch' => bless( {
                                   'name' => 'Stretch',
                                   'test_type_id' => '2',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::TestType' ),
             'other' => bless( {
                                 'name' => 'Other',
                                 'test_type_id' => '5',
                                 'dao' => undef,
                                 '_cached_object_slots' => {}
                               }, 'RSTF::DB::TestType' ),
             'jumbo' => bless( {
                                 'name' => 'Jumbo',
                                 'test_type_id' => '3',
                                 'dao' => undef,
                                 '_cached_object_slots' => {}
                               }, 'RSTF::DB::TestType' ),
             'scaling' => bless( {
                                   'name' => 'Scaling',
                                   'test_type_id' => '4',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::TestType' ),
             'standard' => bless( {
                                    'name' => 'Standard',
                                    'test_type_id' => '1',
                                    'dao' => undef,
                                    '_cached_object_slots' => {}
                                  }, 'RSTF::DB::TestType' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::TestType(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
