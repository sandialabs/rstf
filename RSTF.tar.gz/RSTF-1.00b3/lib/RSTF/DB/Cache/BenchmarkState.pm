package RSTF::DB::Cache::BenchmarkState;
use RSTF::DB::BenchmarkState;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'complete' => bless( {
                                    'name' => 'Complete',
                                    'benchmark_state_id' => '5',
                                    'dao' => undef,
                                    '_cached_object_slots' => {}
                                  }, 'RSTF::DB::BenchmarkState' ),
             'scheduled' => bless( {
                                     'name' => 'Scheduled',
                                     'benchmark_state_id' => '4',
                                     'dao' => undef,
                                     '_cached_object_slots' => {}
                                   }, 'RSTF::DB::BenchmarkState' ),
             'ready to run' => bless( {
                                        'name' => 'Ready to Run',
                                        'benchmark_state_id' => '3',
                                        'dao' => undef,
                                        '_cached_object_slots' => {}
                                      }, 'RSTF::DB::BenchmarkState' ),
             'proposed' => bless( {
                                    'name' => 'Proposed',
                                    'benchmark_state_id' => '1',
                                    'dao' => undef,
                                    '_cached_object_slots' => {}
                                  }, 'RSTF::DB::BenchmarkState' ),
             'planned' => bless( {
                                   'name' => 'Planned',
                                   'benchmark_state_id' => '2',
                                   'dao' => undef,
                                   '_cached_object_slots' => {}
                                 }, 'RSTF::DB::BenchmarkState' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::BenchmarkState(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
