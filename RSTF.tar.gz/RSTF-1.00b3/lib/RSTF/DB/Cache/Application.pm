package RSTF::DB::Cache::Application;
use RSTF::Exec::Application;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'seacas' => bless( {
                                  'name' => 'Seacas',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '16',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '2',
                                  'xmlwriter' => bless( {
                                                          'tag' => 'application',
                                                          'is_empty' => 0,
                                                          'id_slot' => 'app_id'
                                                        }, 'RSTF::DB::XMLWriter' ),
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' ),
             'sppm' => bless( {
                                'name' => 'sPPM',
                                'description' => undef,
                                'completion_date' => undef,
                                'lab' => 'LLNL',
                                'app_id' => '9',
                                '_cached_object_slots' => {},
                                'package_type_id' => '1',
                                'xmlwriter' => {},
                                'status' => undef,
                                'dao' => undef,
                                'primary_language' => 'F90'
                              }, 'RSTF::Exec::Application' ),
             'sage' => bless( {
                                'name' => 'Sage',
                                'description' => undef,
                                'completion_date' => undef,
                                'lab' => 'LANL',
                                'app_id' => '7',
                                '_cached_object_slots' => {},
                                'package_type_id' => '1',
                                'xmlwriter' => {},
                                'status' => undef,
                                'dao' => undef,
                                'primary_language' => 'F90'
                              }, 'RSTF::Exec::Application' ),
             'netcdf' => bless( {
                                  'name' => 'NetCDF',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '12',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '2',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' ),
             'trilinos' => bless( {
                                    'name' => 'Trilinos',
                                    'description' => undef,
                                    'completion_date' => undef,
                                    'lab' => 'SNL',
                                    'app_id' => '17',
                                    '_cached_object_slots' => {},
                                    'package_type_id' => '2',
                                    'xmlwriter' => {},
                                    'status' => undef,
                                    'dao' => undef,
                                    'primary_language' => 'C++'
                                  }, 'RSTF::Exec::Application' ),
             'exodus - alegra' => bless( {
                                           'name' => 'Exodus - Alegra',
                                           'description' => undef,
                                           'completion_date' => undef,
                                           'lab' => 'SNL',
                                           'app_id' => '15',
                                           '_cached_object_slots' => {},
                                           'package_type_id' => '2',
                                           'xmlwriter' => {},
                                           'status' => undef,
                                           'dao' => undef,
                                           'primary_language' => 'C++'
                                         }, 'RSTF::Exec::Application' ),
             'sierra' => bless( {
                                  'name' => 'Sierra',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '11',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '2',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' ),
             'calore' => bless( {
                                  'name' => 'Calore',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '2',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '1',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' ),
             'cth' => bless( {
                               'name' => 'CTH',
                               'description' => undef,
                               'completion_date' => undef,
                               'lab' => 'SNL',
                               'app_id' => '3',
                               '_cached_object_slots' => {},
                               'package_type_id' => '1',
                               'xmlwriter' => {},
                               'status' => undef,
                               'dao' => undef,
                               'primary_language' => 'F77'
                             }, 'RSTF::Exec::Application' ),
             'umt2000' => bless( {
                                   'name' => 'UMT2000',
                                   'description' => undef,
                                   'completion_date' => undef,
                                   'lab' => 'LLNL',
                                   'app_id' => '10',
                                   '_cached_object_slots' => {},
                                   'package_type_id' => '1',
                                   'xmlwriter' => {},
                                   'status' => undef,
                                   'dao' => undef,
                                   'primary_language' => 'F90'
                                 }, 'RSTF::Exec::Application' ),
             'netcdf - alegra' => bless( {
                                           'name' => 'NetCDF - Alegra',
                                           'description' => undef,
                                           'completion_date' => undef,
                                           'lab' => 'SNL',
                                           'app_id' => '13',
                                           '_cached_object_slots' => {},
                                           'package_type_id' => '2',
                                           'xmlwriter' => {},
                                           'status' => undef,
                                           'dao' => undef,
                                           'primary_language' => 'C++'
                                         }, 'RSTF::Exec::Application' ),
             'alegra' => bless( {
                                  'name' => 'Alegra',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '1',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '1',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'F77'
                                }, 'RSTF::Exec::Application' ),
             'exodus' => bless( {
                                  'name' => 'Exodus',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '14',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '2',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' ),
             'hdf4' => bless( {
                                'name' => 'HDF4',
                                'description' => undef,
                                'completion_date' => undef,
                                'lab' => 'SNL',
                                'app_id' => '18',
                                '_cached_object_slots' => {},
                                'package_type_id' => '2',
                                'xmlwriter' => {},
                                'status' => undef,
                                'dao' => undef,
                                'primary_language' => 'C++'
                              }, 'RSTF::Exec::Application' ),
             'partisn' => bless( {
                                   'name' => 'Partisn',
                                   'description' => undef,
                                   'completion_date' => undef,
                                   'lab' => 'LANL',
                                   'app_id' => '5',
                                   '_cached_object_slots' => {},
                                   'package_type_id' => '1',
                                   'xmlwriter' => {},
                                   'status' => undef,
                                   'dao' => undef,
                                   'primary_language' => 'F90'
                                 }, 'RSTF::Exec::Application' ),
             'salinas' => bless( {
                                   'name' => 'Salinas',
                                   'description' => undef,
                                   'completion_date' => undef,
                                   'lab' => 'SNL',
                                   'app_id' => '8',
                                   '_cached_object_slots' => {},
                                   'package_type_id' => '1',
                                   'xmlwriter' => {},
                                   'status' => undef,
                                   'dao' => undef,
                                   'primary_language' => 'C++'
                                 }, 'RSTF::Exec::Application' ),
             'its' => bless( {
                               'name' => 'ITS',
                               'description' => undef,
                               'completion_date' => undef,
                               'lab' => 'SNL',
                               'app_id' => '4',
                               '_cached_object_slots' => {},
                               'package_type_id' => '1',
                               'xmlwriter' => {},
                               'status' => undef,
                               'dao' => undef,
                               'primary_language' => 'F77'
                             }, 'RSTF::Exec::Application' ),
             'presto' => bless( {
                                  'name' => 'Presto',
                                  'description' => undef,
                                  'completion_date' => undef,
                                  'lab' => 'SNL',
                                  'app_id' => '6',
                                  '_cached_object_slots' => {},
                                  'package_type_id' => '1',
                                  'xmlwriter' => {},
                                  'status' => undef,
                                  'dao' => undef,
                                  'primary_language' => 'C++'
                                }, 'RSTF::Exec::Application' )
           };
$objects->{'sppm'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'sage'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'netcdf'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'trilinos'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'exodus - alegra'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'sierra'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'calore'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'cth'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'umt2000'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'netcdf - alegra'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'alegra'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'exodus'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'hdf4'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'partisn'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'salinas'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'its'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};
$objects->{'presto'}{'xmlwriter'} = $objects->{'seacas'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::Exec::Application(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
