package RSTF::DB::Cache::Purpose;
use RSTF::DB::Purpose;
use RSTF::DB::XMLWriter;
my 
$objects = {
             '' => bless( {
                            'name' => undef,
                            'purpose_id' => '6',
                            'xmlwriter' => bless( {
                                                    'tag' => 'purpose',
                                                    'is_empty' => 1,
                                                    'other_attr' => [
                                                                      'name'
                                                                    ],
                                                    'id_slot' => 'purpose_id'
                                                  }, 'RSTF::DB::XMLWriter' ),
                            'dao' => undef,
                            '_cached_object_slots' => {}
                          }, 'RSTF::DB::Purpose' )
           };

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Purpose(name => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
