package RSTF::DB::Cache::Role;
use RSTF::DB::Role;
use RSTF::DB::XMLWriter;
my 
$objects = {
             'red porter' => bless( {
                                      'xmlwriter' => bless( {
                                                              'tag' => 'role',
                                                              'is_empty' => 1,
                                                              'other_attr' => [
                                                                                'role'
                                                                              ],
                                                              'id_slot' => 'role_id'
                                                            }, 'RSTF::DB::XMLWriter' ),
                                      'dao' => undef,
                                      'role_id' => '7',
                                      '_cached_object_slots' => {},
                                      'role' => 'Red Porter'
                                    }, 'RSTF::DB::Role' ),
             'snl witness' => bless( {
                                       'xmlwriter' => {},
                                       'dao' => undef,
                                       'role_id' => '5',
                                       '_cached_object_slots' => {},
                                       'role' => 'SNL Witness'
                                     }, 'RSTF::DB::Role' ),
             'snl runner' => bless( {
                                      'xmlwriter' => {},
                                      'dao' => undef,
                                      'role_id' => '9',
                                      '_cached_object_slots' => {},
                                      'role' => 'SNL Runner'
                                    }, 'RSTF::DB::Role' ),
             'application poc' => bless( {
                                           'xmlwriter' => {},
                                           'dao' => undef,
                                           'role_id' => '2',
                                           '_cached_object_slots' => {},
                                           'role' => 'Application POC'
                                         }, 'RSTF::DB::Role' ),
             'cray witness' => bless( {
                                        'xmlwriter' => {},
                                        'dao' => undef,
                                        'role_id' => '6',
                                        '_cached_object_slots' => {},
                                        'role' => 'Cray Witness'
                                      }, 'RSTF::DB::Role' ),
             'cray runner' => bless( {
                                       'xmlwriter' => {},
                                       'dao' => undef,
                                       'role_id' => '10',
                                       '_cached_object_slots' => {},
                                       'role' => 'Cray Runner'
                                     }, 'RSTF::DB::Role' ),
             'cray poc' => bless( {
                                    'xmlwriter' => {},
                                    'dao' => undef,
                                    'role_id' => '4',
                                    '_cached_object_slots' => {},
                                    'role' => 'Cray POC'
                                  }, 'RSTF::DB::Role' ),
             'snl 7x poc' => bless( {
                                      'xmlwriter' => {},
                                      'dao' => undef,
                                      'role_id' => '3',
                                      '_cached_object_slots' => {},
                                      'role' => 'SNL 7x POC'
                                    }, 'RSTF::DB::Role' ),
             'red storm porter' => bless( {
                                            'xmlwriter' => {},
                                            'dao' => undef,
                                            'role_id' => '8',
                                            '_cached_object_slots' => {},
                                            'role' => 'Red Storm Porter'
                                          }, 'RSTF::DB::Role' ),
             'analyst' => bless( {
                                   'xmlwriter' => {},
                                   'dao' => undef,
                                   'role_id' => '1',
                                   '_cached_object_slots' => {},
                                   'role' => 'Analyst'
                                 }, 'RSTF::DB::Role' )
           };
$objects->{'snl witness'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'snl runner'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'application poc'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'cray witness'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'cray runner'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'cray poc'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'snl 7x poc'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'red storm porter'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};
$objects->{'analyst'}{'xmlwriter'} = $objects->{'red porter'}{'xmlwriter'};

sub lookup {
    my $pkg = shift;
    my $name = shift;
    $name = lc($name);
    my $obj = $objects->{$name};
    return $obj;
}

sub create_object {
    my $pkg = shift;
    my $name = shift;

    my $obj = new RSTF::DB::Role(role => $name);
    $objects{$name} = $obj;
    return $obj;
}

1;
