###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# EnvPath.pm
# 
# Created by: Robert A. Ballance		Thu Apr 15 19:34:38 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/DB/EnvPath.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

# -- methods

package RSTF::DB::EnvPath;
use strict;
use warnings;

use RSTF::DB::EnvironmentSetting;
use RSTF::DB::Utils;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::EnvironmentSetting);

use Class::MethodMaker(
		       new_with_init => 'new',
		       get_set => [qw (old_path) ]);

use RSTF::LogFile;

my $valuewriter = new RSTF::DB::XMLWriter(tag=>'pathdir',
					  id_slot=>'env_id',
					  other_attr=>[qw(env_type testcase_id)]);

my @default_args = (env_type => RSTF::DB::EnvironmentSetting::PATH, xmlwriter=>$valuewriter);

sub init {
    my $self = shift;
    $self->SUPER::init(@default_args, @_);
    return $self;
}

sub add {
    my $self = shift;
    my $dir = $self->value;
    $dir = subst_env_vars($dir);
    $self->old_path($ENV{PATH});
    $ENV{PATH} = $dir . ':' . $ENV{PATH};
    log_debug("PATH = " . $ENV{PATH});
}

sub remove {
    my $self = shift;
    my $old_path = $self->old_path();
    if ($old_path) {
	$ENV{PATH} = $old_path;
    } else {
	delete $ENV{PATH};
    }
    log_debug("PATH reset to " . $ENV{PATH});
}

sub write_xml_body {
    my $self = shift;
    print  $self->value;
}

1;
