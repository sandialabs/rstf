###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# PGI.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/ToolInfo/PGI.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::ToolInfo::PGI;

use strict;
use RSTF::ToolInfo;
use vars qw(@ISA);
@ISA = qw(RSTF::ToolInfo);

sub process_info  {
    my $self = shift;
    my $info = shift;

    my @lines = split(/\s*\n/, $info);
    foreach my $line  (@lines) {
	next if ($line =~ /^\s*$/);
	if ($line =~ /^(\w+)\s+Rel\s+(.*)/) {
	    $self->realname($1);
	    $self->version($2);
	    next;
	}
	if ($line =~ m[^(/[\w\/]*/pgc)\s+([\w\.]+)\s+(.*)$]) {
	    $self->toolpath($1);
	    $self->filename($2);
	    $self->expanded_flags($3);
	    last;
	}
    }
}

1;
