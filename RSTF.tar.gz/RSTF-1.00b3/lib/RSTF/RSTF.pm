###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
#  
# 
# RSTF.pm
# 
# Created by: Robert A. Ballance		Tue Sep 28 15:17:56 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/RSTF.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RST;

use 5.008002;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use RST ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );

our @EXPORT = qw(
	
);

our $VERSION = '1.00b3';



# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

RSTF - Robust Systems Test Framework

=head1 SYNOPSIS

    rst <command> <command-args> 

=head1 DESCRIPTION

I<rst> is a wrapper for a benchmark database. It is a  script that invokes the proper commands
needed to manage the database test cases.

=head2 Commands

The following commands and arguments are recognized:

=over 4

=item validate I<file...>

Run the XML validator on the specified files. The validator lists each file name, and presents any errors if discrepancies
between the file and the DTD are found.

=item compile I<file...>

Translate the specified xml files into Perl code for execution on the target machine

=item format I<file...>

Replace the specified XML files with equivalent formatted versions.

=item prettyprint I<file...>

Format the specified files, writing the results to the standard output.

=item write I<file...>

Store the contents of the specified XML files into the Sevenx database.

=item read --testcase_id=I<n>

Read the specified testcase from the database, and write the resulting XML to the standard output.

=head1 SEE ALSO

=head1 AUTHOR

raballa, E<lt>raballa@sandia.govE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2004 Sandia National Laboratories.

=cut
