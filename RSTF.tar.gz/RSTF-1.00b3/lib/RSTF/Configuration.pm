###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Configuration.pm
# 
# Created by: Robert A. Ballance		Thu Sep  9 12:02:35 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Configuration.pm,v $
# $Revision: 1.21 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
# Add user variables
# allow platform variables
#
#  red_default_queue
#  red_default_walltime
#
#
package RSTF::Configuration;

use AppConfig qw(:expand :argcount);
use strict;

use vars qw(@ISA);
@ISA = qw(AppConfig);

my $global_config = {
    CASE => 0,
    GLOBAL => {
	ARGCOUNT => ARGCOUNT_ONE,
	DEFAULT => undef,
	EXPAND => EXPAND_UID | EXPAND_ENV
	}
};


my @globals = qw(debug verbose help);

my @sections = qw( global rst database  make pack platform  run);

my %variables =  (
		  
		  # Generic debugging values
		  debug => { DOC => "Turn on debugging.",
			     DEF => {DEFAULT => 0,
				     ARGCOUNT => ARGCOUNT_NONE}},
		  verbose => { DOC => "Turn on verbose output.",
			       DEF => {ARGCOUNT => ARGCOUNT_NONE}},

		  help => { DOC => "Print help and exit.",
			    DEF => {ARGCOUNT => ARGCOUNT_NONE}},

		  # rst section
		  
		  rst_dtd_dir => { DOC => ["Location of the DTDs.",
					   'The default value is formed by  <filename>$HOME/etc/</filename>.'
					   ],
				   DEF => {
				       DEFAULT => "$ENV{HOME}/etc/",
				       ARGCOUNT => ARGCOUNT_ONE
				       }
			       },

		  rst_script_bin => { DOC => ["Location of RST helper scripts.",
					      'The default value is formed by  <filename>$HOME/bin</filename>.'],
				      DEF => {
					  DEFAULT => "$ENV{HOME}/bin",
					  ARGCOUNT => ARGCOUNT_ONE
					  }
				  },
		  
		  rst_perl => { DOC => "Full path to perl executable. Change this if you need to run using an alternate perl executable.",

				DEF => {
				    DEFAULT => "perl",
				    ARGCOUNT => ARGCOUNT_ONE
				    }
			    },
		  
		  # pack section
		  # pack_app is a list of app names used during 
		  # packing to split file paths.
		  pack_app => { DOC => "List of applications to be used during packing.",
				DEF => {
				    ALIAS =>'app',
				    DEFAULT => [qw(alegra calore cth its presto salinas)],
				    ARGCOUNT => ARGCOUNT_LIST}},
		  
		  pack_archive => { DOC => ["Name of tar file used to contain results.",
					    "The default  value is <filename>\$HOME/rst_results.tar</filename>."],
				    DEF => {
					ALIAS =>'archive',
					DEFAULT => '${HOME}/rst_results.tar',
					ARGCOUNT => ARGCOUNT_LIST
					}
				},
		  
		  # database section
		  database_user => { DOC => "Login name of user. Default is \$LOGNAME.",
				     DEF => {
					 DEFAULT => "$ENV{LOGNAME}",
					 ARGCOUNT => ARGCOUNT_ONE}
				 },
		  database_name => { DOC => "Name of database.",
				     DEF => {
					 DEFAULT => "rst",
					 ARGCOUNT => ARGCOUNT_ONE}
				 },

		  database_pw =>  {
		      DOC => "Database password for user.",
		      ALIAS  => 'password',
		      DEF => {ARGCOUNT => ARGCOUNT_ONE}
		  },
		  database_host => { DOC => "Database server name.",
				     DEF => {
					 DEFAULT => "localhost",
					 ARGCOUNT => ARGCOUNT_ONE}
				 },

		  database_port => { DOC => "TCP port  used by server.",
				     DEF => {
					 DEFAULT => 5432,
					 ARGCOUNT => ARGCOUNT_ONE}
				 },

		  database_connect => { DOC => "Set to no/false to skip connections if you don't want to use the database.",
					DEF => {
					    ALIAS => "connect",
					    DEFAULT => 1,
					    ARGCOUNT => ARGCOUNT_NONE
					    }
				    },
    
		  database_dbi_trace => { DOC => "Set the DBI tracing level. This option is only useful for deep debugging.",
					DEF => {
					    ALIAS => "dbi_trace",
					    DEFAULT => 0,
					    ARGCOUNT => ARGCOUNT_ONE
					    }
				    },

		  database_ignore_cache => { DOC => "Deep Voodoo. Turn off DB Named Object Caching",
					     DEF => {
						 DEFAULT => 0,
						 ARGCOUNT => ARGCOUNT_NONE
						 }
					 },
		  
		  # being reset to UNDEF
		  # run section
		  run_dryrun => { DOC => "If set, just print commands during a run.",
				  DEF => {
				      ARGCOUNT => ARGCOUNT_NONE,
				      ALIAS => 'dryrun'
				      }
			      },
		  
		  run_interactive=> { DOC => "Use interactive submission.",
				      DEF => {
					  ALIAS => 'interactive',
					  ARGCOUNT => ARGCOUNT_NONE
					  }
				  },

		  run_suppress_path_lookups =>  {
		      DOC => ["If set, don't try to resolve executables to their full name.",
			      "This is useful for testing scripts on different machines than you",
			      "intend to run them on."],
		      
		      DEF => {
			  ALIAS => 'suppress_path_lookups',
			  ARGCOUNT => ARGCOUNT_NONE
			  }
		  },

		  run_purpose => {
		      DOC => [ "The purpose of this run. Must be one of the purpose names",
			       "defined in the database"],
		      DEF => {
			  ALIAS=> 'purpose',
			  ARGCOUNT => ARGCOUNT_ONE,
			  DEFAULT => 'unknown'
			  }
		  },

		  run_tag => {
		      DOC => "An uninterpreted string stored in the DB with the run.",
		      DEF => {ARGCOUNT => ARGCOUNT_ONE}
		  },
		  
		  run_runner => { DOC => ["Email address of the person running the script.",
			    'The default value is formed by  $LOGNAME@sandia.gov.'],
		    DEF => {
			DEFAULT => "$ENV{LOGNAME}\@sandia.gov",
			ALIAS => 'runner',
			ARGCOUNT => ARGCOUNT_ONE
			}
		},
		  
# Make section
		  make_wrapper_bin => { DOC => ["Location of RST compiler wrapper scripts.",
						'The default value is formed by  <filename>$HOME/bin</filename>.'],
				   DEF => {
				       DEFAULT => "$ENV{HOME}/bin/wrappers",
				       ALIAS => 'wrapper_bin',
				       ARGCOUNT => ARGCOUNT_ONE
				       }
				    },
		  

		  make_wrapper_info_file =>
		  { DOC => 
			["This file contains output from the compilation wrapper scripts" ],
			DEF => {
			    DEFAULT => "rst_wrappers.out",
			    ALIAS => 'wrapper_info_file',
			    ARGCOUNT => ARGCOUNT_ONE
			    }
		},

		  make_size_program =>
		  { DOC => 
			["name of executable for extracting size info"],
			DEF => {
			    DEFAULT => "size",
			    ALIAS => 'size_program',
			    ARGCOUNT => ARGCOUNT_ONE
			    }
		},
		  make_md5_program =>
		  { DOC => 
			["name of executable for coputing md5 checksum"],
			DEF => {
			    DEFAULT => "md5sum",
			    ALIAS => 'md5sum_program',
			    ARGCOUNT => ARGCOUNT_ONE
			    }
		},

		  run_log_directory =>
		  { DOC => 
			["The log directory stores the timestamped directories containing run information."],
			DEF => {
			    ALIAS => 'log_directory',
			    DEFAULT => "LOGS",
			    ARGCOUNT => ARGCOUNT_ONE
			    }
		},

		  run_run_log =>
		  { DOC => 
			["The run log is a file that lists the directories containing run information.",
			 "It is used by the 'pack' command to generate a tarball of the results.",
			 'The default value is formed by  <filename>$HOME/rst.log</filename>.'],
			DEF => {
			    ALIAS => 'run_log',
			    DEFAULT => "$ENV{HOME}/rst.log",
			    ARGCOUNT => ARGCOUNT_ONE
			    }
		},

# 		  run_ignore_env => { DOC => "List of environment variables to ignore.",
# 				     DEF => {
# 					 ARGCOUNT => ARGCOUNT_LIST}},
		  

# 		  run_preserve_env => { DOC => "List of environment variables to preserve, even if in the ignore list.",
# 					DEF => {
# 					ARGCOUNT => ARGCOUNT_LIST}},
		  


		platform_red =>
		  { DOC => 
			[ "A set of values used to configure the Red platform.",
			  "Example: \\literal{red default_queue snl.}",
			  "The following key values are used:",
			  "   default_queue, ",
			  "   default_walltime, ",
			  "   max_nodes_for_interactive,",
			  "   queue_submit_script. "],

			DEF => {
			    DEFAULT => {
				default_queue => 'snl',
				default_walltime => "08:00:00",
				max_nodes_for_interactive => '16',
				queue_submit_script => 'make_nqs_submit.pl'
				},
			    EXPAND => EXPAND_ALL,
			    ARGCOUNT => ARGCOUNT_HASH}
		},

		platform_redstorm =>
		  { DOC => 
			[ "A set of values used to configure the Red Storm platform.",
			  "Example: \\literal{redstorm default_queue snl}.",
			  "The following key values are used:",
			  "   default_queue, ",
			  "   default_walltime,",
			  "   max_nodes_for_interactive,",
			  "   queue_submit_script." 
			  ],

			DEF => {
			    DEFAULT => {
				default_queue => 'snl.day',
				default_walltime => "02:00:00",
				max_nodes_for_interactive => '16',
				queue_submit_script => 'make_pbs_submit.pl'
				},
			    EXPAND => EXPAND_ALL,
			    ARGCOUNT => ARGCOUNT_HASH}
		},


		  );

use constant CONFIG_FILE => "$ENV{HOME}/rst.conf";
my @check_files = (
		   'rst.conf',
		   '.rst',
		   $ENV{HOME} . "/.rst",
		   $ENV{HOME}. "/rst.conf",
		   $ENV{RST_GLOBAL_CONFIG}
		   );

my $config;
my $filename;

sub new {
    my $self = shift;

    # reference to list of getopt-style strings.
    my $args = shift;
    unless ($config) {
	$config = $self->SUPER::new($global_config);
	foreach my $key (keys %variables) {
	    my $hash = $variables{$key}->{'DEF'};
	    $config->define($key, $hash);
	}

	if ($ENV{'RST_CONFIGFILE'}) {
	    @check_files = (  $ENV{RST_CONFIGFILE}, $ENV{RST_GLOBAL_CONFIG} );
	}

	my @files = ();

	foreach my $filename (reverse @check_files) { 
	    # Hmm. check file permissions?
	    if (defined($filename) && -e $filename && -r $filename) {
		my $mode = (stat($filename))[2] & 07777;
		unless ($mode eq 0600 || $mode eq 0400) {
		    die "Configuration file '$filename' must be mode rw--";
		}
#		print STDERR "Adding $filename to config list\n";
		push @files, $filename;
	    }
	}
	$config->file(@files) or die "Unable to read configuration file from  " . join(',', @files);
	
	# Handle new arguments
	if ($args) {
	    foreach my $s (@$args) {
		$config->define($s);
	    }
	}
    }
    return $config;
}
# These used to be appconfig variables, but I moved the configuration option into the
# rst_dtd_dir slot.
sub   rst_xml_dtd {
    my $self = shift;
    my $dir = $self->rst_dtd_dir();
    return "$dir/benchmark.dtd";
}

sub xml_dtd {
    my $self = shift;
    return $self->rst_xml_dtd();
}


# This function returns the full name of a variable if it is named or aliased in the
# variables hash
sub globally_configurable {
    my $self = shift;
    my $name = shift;
    if ($variables{$name}) {
	return $name;
    }
    foreach my $key (keys %variables) {
	my $hash = $variables{$key}->{'DEF'};
	if ($hash->{'ALIAS'} && $hash->{'ALIAS'} =~ /$name/i)  {
	    return $key;
	}
    }
    return undef;;
}


sub describe_settings {
    my $self = shift;
    my $sect_list = shift || \@sections;

    my %vars;
    foreach my $sect (@$sect_list) {
	$sect = lc $sect;
	if ($sect =~ /global/i) {
	    $self->print_header("Global settings");
	    foreach my $global (@globals) {
		my $value = $self->$global();
		$self->describe_variable($global, $global, $value);
	    }
	 } else {
	     %vars = $self->varlist("^$sect" . '_', 1);
	     $self->print_header("Section $sect");
	     foreach my $key (sort keys %vars) {
		 my $fullname = sprintf("%s_%s",$sect, $key);
		 $self->describe_variable($key, $fullname, $vars{$key});
	     }
	 }
    }
}

use constant INDENT => '  ';
sub print_header {
    my $self = shift;
    my $title = shift;
    print "$title:\n\n";
}

sub describe_variable {
    my $self = shift;
    my $key = shift;
    my $fullname =shift;
    my $value = shift;

    print "$key\n";
    print INDENT . "Value: ", print_value($value), "\n";

    my $href = $variables{$fullname};
    if ($href) {
	my $defn = $href->{'DEF'}->{'DEFAULT'};
	print INDENT . 'Default: ',  print_value($defn), "\n";

	my $doc = $href->{'DOC'};
	if ($doc) {
	    if (ref($doc)) {
		$doc =  join("\n" . INDENT, @$doc);
	    }
	    print INDENT . $doc . "\n";
	}
    }
    print "\n";

}

# Formatting functions
sub print_value {
    my $value = shift;

    if (defined($value)) {
	if (ref($value)) {
	    if (ref($value) eq 'ARRAY') {
		return  join(',', @$value);
	    } elsif (ref($value) eq 'HASH') {
		my @values = ();
		foreach my $key (sort keys %$value) {
		    push @values, "$key = " . $value->{$key};
		}
		return  join(',', @values);
	    }
	} else {
	    return $value;
	}
    } else {
	return '?';
    }
}


###########
# sub to_refman {
#     my $self = shift;

#     my %vars;
#     print "<variablelist>\n";
#     print "<title>Globals</title>\n";

#     foreach my $global (@globals) {
# 	my $value = $self->$global();
# 	$self->to_refman_variable($global, $global, $value, 'global');
#     }
#     print "</variablelist>\n";

#     foreach my $sect (@sections) {
# 	unless ($sect eq 'global') {
# 	    %vars = $self->varlist("^$sect" . '_', 1);
# 	    print "<variablelist><title>[$sect]</title>\n";
# 	    foreach my $key (sort keys %vars) {
# 		my $fullname = sprintf("%s_%s",$sect, $key);
# 		$self->to_refman_variable($key, $fullname, $vars{$key}, $sect);
# 	    }
# 	    print "</variablelist>\n";
# 	 }
#      }
# }


# sub to_refman_variable {
#     my $self = shift;
#     my $key = shift;
#     my $fullname =shift;
#     my $value = shift;
#     my $section = shift;
#     print << "EOF";

#     <varlistentry>
# 	<term><anchor id="conf_$fullname" xreflabel="[$section] $key"/><literal>$key</literal></term>
# 	<listitem>
# 	<para>
# EOF
#     ;
#     my $href = $variables{$fullname};
#     if ($href) {
# 	my $defn = $href->{'DEF'}->{'DEFAULT'};
# 	if (defined($defn)) {
# 	    print INDENT . 'Default: <literal>', print_value($defn), '</literal>';
# 	}
# 	print "</para>\n";
# 	my $doc = $href->{'DOC'};
# 	if ($doc) {
# 	    print "<para>\n";
# 	    if (ref($doc)) {
# 		$doc =  join("\n" . INDENT, @$doc);
# 	    }
# 	    print INDENT . $doc . "\n";
# 	    print "</para>\n";
# 	}
# 	print "</listitem>\n</varlistentry>\n";
#     }
#     print "\n";
# }

# ###########
# sub to_refman_astex {
#     my $self = shift;

#     my %vars;
#     # begin reflist
#     print "\\begin{options}{Globals}\n";
#     foreach my $global (@globals) {
# 	my $value = $self->$global();
# 	$self->to_refman_variable_astex($global, $global);
#     }
#     # end reflist
#     print "\\end{options}\n";

#     foreach my $sect (@sections) {
# 	unless ($sect eq 'global') {
# 	    %vars = $self->varlist("^$sect" . '_', 1);
# 	    # begin reflist
# 	    print "\\begin{options}{[$sect]}\n";
# 	    foreach my $key (sort keys %vars) {
# 		my $fullname = sprintf("%s_%s",$sect, $key);
# 		$self->to_refman_variable_astex($key, $fullname);
# 	    }
# 	    # end reflist
# 	    print "\\end{options}\n";
# 	 }
#      }
# }


# sub to_refman_variable_astex {
#     my $self = shift;
#     my $key = shift;
#     my $fullname =shift;

#     # begin variable_def
#     print << "EOF";
#     \\item[$key]\\label{conf:$fullname}
# EOF
#     ;
#     my $href = $variables{$fullname};
#     if ($href) {
# 	my $defn = $href->{'DEF'}->{'DEFAULT'};
# 	if (defined($defn)) {
# 	    # print default_value
# 	    print INDENT . '\defaultvalue{', print_value($defn), '}' , "\n";
# 	}
# 	my $doc = $href->{'DOC'};
# 	if ($doc) {
# 	    if (ref($doc)) {
# 		$doc =  join("\n" . INDENT, @$doc);
# 	    }
# 	    # print_docstring
# 	    print INDENT . $doc . "\n";
# 	}
#     }
#     # end variable
#     print "\n";
# }

sub format {
    my $self = shift;
    my $formatter = shift;

    my %vars;
    # begin reflist
    $formatter->begin_section('Globals');
    foreach my $global (@globals) {
	my $value = $self->$global();
	$self->format_variable($global, $global, $value, 'global', $formatter);
    }
    # end reflist
    $formatter->end_section;

    foreach my $sect (@sections) {
	unless ($sect eq 'global') {
	    %vars = $self->varlist("^$sect" . '_', 1);
	    # begin reflist
	    $formatter->begin_section($sect);
	    foreach my $key (sort keys %vars) {
		my $fullname = sprintf("%s_%s",$sect, $key);
		$self->format_variable($key, $fullname, $vars{$key}, $sect, $formatter);
	    }
	    # end reflist
	    $formatter->end_section($sect);
	}
    }
}

sub format_variable {
    my $self = shift;
    my $key = shift;
    my $fullname =shift;
    my $value = shift;
    my $section = shift;

    my $formatter = shift;

    # begin variable_def
    $formatter->begin_variable($key, $fullname, $value, $section);

    my $href = $variables{$fullname};
    if ($href) {
	my $defn = $href->{'DEF'}->{'DEFAULT'};
	if (defined($defn)) {
	    $formatter->default_value(print_value($defn));
	}
	my $doc = $href->{'DOC'};
	if ($doc) {
	    if (ref($doc)) {
		$doc =  join("\n" . INDENT, @$doc);
	    }
	    # print_docstring
	    $formatter->var_docstring($doc);
	}
    }
    # end variable
    $formatter->end_variable($key, $fullname);
}

1;
	
		     
