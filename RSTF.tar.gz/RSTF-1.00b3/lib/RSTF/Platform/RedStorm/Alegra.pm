###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Alegra.pm
# 
# Created by: Robert A. Ballance		Mon May 31 13:17:35 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Platform/RedStorm/Alegra.pm,v $
# $Revision: 1.3 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Platform::RedStorm::Alegra;
use RSTF::Exec::Dispatch;
use RSTF::FilePath;
use RSTF::LogFile;
use strict;
use RSTF::DB::Utils;
use vars qw(@ISA);

@ISA = qw(RSTF::Exec::Dispatch);

# How to handle proc3 in Alegra?
my @default_args = (procs => 1, arguments=>'', max_time=>'2:00:00', job_queue=>'snl', mode=>'proc0', is_parallel=>1);

sub init {
  my $self = shift;
  return $self->SUPER::init(@default_args, @_);
}

sub get_command {
  my $self = shift;
  my $cmd = shift;
  my $cmd_args = shift;
  my $options = shift;

# Build the magic reference here.
  my $exe = $cmd->executable_file();
  # check for exe on path, unless we are in cross-compile mode
  unless ($options->suppress_path_lookups()) {
    $exe = find_executable($exe);
  }
  
  # Looks just like a direct dispatch!
  return [$exe, @$cmd_args];
}

1;
