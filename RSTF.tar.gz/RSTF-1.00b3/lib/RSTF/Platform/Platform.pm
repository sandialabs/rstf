###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Platform.pm
# 
# Created by: Robert A. Ballance		Fri Apr  9 15:57:33 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Platform/Platform.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Platform::Platform;
use strict;

use RSTF::DB::Platform;
use vars qw(@ISA);

@ISA = qw(RSTF::DB::Platform);

use RSTF::Configuration;
use RSTF::Platform::Red::Platform;
use RSTF::Platform::RedStorm::Platform;
use RSTF::Exec::QueueCommand;

use RSTF::Exec::ParBlock;

use RSTF::FilePath;
use POSIX qw(uname);
use Sys::Hostname;

sub print_description {
    my $self = shift;
    print "Platform: " . $self->name . "\n";
}

sub get_config_file_options {
    die "Abstract method get_config_file_options ccalled --- your platform must define this method!";
}

# Override this for other platforms
sub default_walltime {
    my $self = shift;
    my $hr = $self->get_config_file_options();
    return $hr->{default_walltime} or die "No default walltime specified!";
}

# Override this for other platforms
sub default_queue {
    my $self = shift;
    my $hr = $self->get_config_file_options();
    return $hr->{default_queue} or die "No default queue  specified!";
}

sub get_make_queue_cmd_script  {
    my $self = shift;
    my $options = shift;
    my $hr = $self->get_config_file_options($options);
    my $script = $hr->{queue_submit_script};
    return $script  or die "No queue_submit_command  specified!";
}

# Singleton implementation of system con figuration stuff
my $config;
sub get_configuration {
    my $self = shift;

    unless ($config) {
	my $os = join(' ', uname());
	my $hostname = hostname();
	$config = RSTF::DB::SystemConfiguration->make($hostname, $os, $self);
    }
    return $config;
}


sub get_platform {
  my $name = shift;
  my $id = shift;
  if ($name =~ m/^(red|janus)$/i) {
      return new RSTF::Platform::Red::Platform(name => 'Red', platform_id=>$id);
  }
  if ($name =~ m/^(red\s*storm)$/i) {
      return new RSTF::Platform::RedStorm::Platform(name => 'RedStorm', platform_id=>$id);
  }
  if ($name =~ m/^(null)$/i) {
      return new RSTF::Platform::Null::Platform(name => 'Null', platform_id=>$id);
  }

  die "Undefined platform $name";
}

sub get_dispatcher {
    my $self = shift;
    my $values = shift;

    my $name = $values->{name};
    
    my $classname = $self->get_dispatcher_class($name);
    die "Unknown dispatch class $classname" unless (defined($classname));
    
    eval "require $classname";
    if ($@) {
    	die $@;
     }
    my $x = $classname->new();
    foreach my $key (keys %$values) {
       if ($values->{$key}) {
	  $x->$key($values->{$key});
       }
    }
    return $x;
}


sub clone_dispatch {
    my $self = shift;
    my $other = shift;
    
    my $classname = $self->get_dispatcher_class($other->name);
    die "Unknown dispatch class $classname" unless (defined($classname));
    
    eval "require $classname";
    my $x =   $classname->new(
			      name => $other->name,
			      procs => $other->procs,
			      arguments=>$other->arguments,
			      max_time=>$other->max_time,
			      job_queue=>$other->job_queue,
			      mode=>$other->mode);
    return $x;
}


# Could move this to a Platform inherited method if we lift out a way
# to get the queue object name.
#
sub build_queue_command {
    my $self = shift;
    my $strings = shift;		# reference to an array of command strings
    my $parblock = shift;		# actual parallel block - it has the max_time and max_procs!
    my $options = shift;		# compilation and other options.
    my $queue_dispatcher = $self->get_dispatcher({name=>'queue'});
    return  $queue_dispatcher->build_queue_command($self, $strings, $parblock, $options);
}

sub check_job_status {
    my $self = shift;
    my $jobid = shift;
    my $queue_name = shift;
    my $queue_dispatcher = $self->get_dispatcher({name=>'queue'});
    return  $queue_dispatcher->check_job_status($self, $jobid, $queue_name);
}

1;
