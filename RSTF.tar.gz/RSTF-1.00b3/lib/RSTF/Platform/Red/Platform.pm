###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Platform.pm
# 
# Created by: Robert A. Ballance		Thu May 20 17:55:06 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Platform/Red/Platform.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Platform::Red::Platform;
use RSTF::Platform::Platform;

use RSTF::Configuration;

use strict;
use vars qw(@ISA);
@ISA = qw(RSTF::Platform::Platform);

my %dispatch_factory = (
			direct => 'RSTF::Platform::DirectDispatch',
			yod => 'RSTF::Platform::Red::Yod',
			sierra => 'RSTF::Platform::Red::Sierra',
			alegra => 'RSTF::Platform::Red::Alegra',
			queue => 'RSTF::Platform::Red::NQS',
		       );


sub get_dispatcher_class {
  my $self = shift;
  my $dispatch_name = shift;
  $dispatch_name = lc $dispatch_name;
  return $dispatch_factory{$dispatch_name} || die "Unknown dispatch name: $dispatch_name";
}

sub get_config_file_options {
    my $self = shift;
    my $config = shift;
    $config = $config || new RSTF::Configuration;
    return $config->platform_red();
}

1;

