###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# NQS.pm
# 
# Created by: Robert A. Ballance		Thu May 20 17:47:59 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Platform/Red/NQS.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
#  NQS is the abstraction for a Queuing System
#  It currently only provides a single package method - build_queue_command
#  It probably also needs a method to check if a given job is still in
#  the queue
#  
#  checkstatus($job_id, queue_name) -> Q,R,D, ???
#  Again, the platform object needs to forward this to the queue object.
#
# Request 14617.janus submitted to queue: snl.day.
# Porting gotchas -
#   line printed by qsub.
#   differences in tail commmand usage.
# 
###############################################################################

package RSTF::Platform::Red::NQS;
use Fcntl;
use RSTF::Platform::Platform;
use RSTF::Exec::QueueCommand;
use RSTF::FilePath;
use POSIX qw(:sys_wait_h);
use Time::HiRes qw(tv_interval);

use RSTF::LogFile;

use strict;
use Class::MethodMaker(
		       new_hash_init=> 'new',
		       get_set => [qw(name dribble_file) ]
		       );

my $index = 1;

# Need the qsub arguments!
# This might best be another object.... but not worth it today!

sub  make_run_script {
    my $pkg = shift;
    my $strings = shift;		# reference to an array of command strings
    my $platform_name = shift;

    die "No script strings!" unless ($strings);

    # $run_script contains the actual commands!
    # Problem is the directory
    my $cwd = current_directory();
    my $run_script = sprintf("%s/nqs_run%d.%d.sh", $cwd, $$, $index);
    my $dribblefile = sprintf("%s/rst_%d.%d.dribble", $cwd, $$, $index);
    my $utils = sprintf('${HOME}/lib/%s.utils', $platform_name);
    $index++;

    open (SCRIPT, ">$run_script") or die "Unable to create $run_script \n";
    print SCRIPT << 'EOF';
#!/bin/sh
# ==== Shell Script ===
# Assumes that PBS_WORKDIR and PBS_JOBID are correct
#
cd $QSUB_WORKDIR
EOF
;
      print SCRIPT "DRIBBLEFILE=\"$dribblefile\"\n";
      print SCRIPT ". $utils\n";

    print SCRIPT << 'EOF';
date > $DRIBBLEFILE
echo `pwd` >> $DRIBBLEFILE


# End standard header

EOF
;
print SCRIPT join("\n", @$strings), "\n";

print SCRIPT << 'EOF';
#
# standard footer
#
echo "++++ COMPLETED" >> $DRIBBLEFILE
echo `date` >> $DRIBBLEFILE
exit 0
EOF
;
    close(SCRIPT);

    my $ok = chmod 0700, $run_script;

#    system("touch $dribblefile");
    touch($dribblefile);

    if ($ok) {
	return ($run_script, $dribblefile);
    } else {
	die "Unable to make $run_script executable\n";
    }
}

sub build_queue_command {
    my $pkg = shift;
    my $platform = shift;
    my $strings = shift;		# reference to an array of command strings
    my $parblock = shift;		# actual parallel block - it has the max_time and max_procs!
    my $options = shift;		# compilation and other options.

    # $nqs_script get qsub'd. When it runs, it runs $run_script
    my ($run_script, $dribblefile)  = $pkg->make_run_script($strings, $platform->name); 

    my $pardispatch = $parblock->dispatch();

    my $arguments = sprintf("-q %s -lP %d -lT \"%s\"", $pardispatch->job_queue || 'snl.day', $pardispatch->nodes(), $pardispatch->max_time);
    
    return new RSTF::Exec::QueueCommand(
				       script_name => $run_script,
				       arguments => $arguments,
				       executable => "qsub",
				       install_directory => undef,
				       working_directory=> undef,
				       stdin => undef,
				       stdout => undef,
				       stderr => undef,
				       dispatch => $platform->get_dispatcher({name => 'Direct', procs =>1}),
				       handler => $pkg,
				       dribblefile => $dribblefile
				       );
}

sub check_job_status {
    my $pkg = shift;
    my $platform = shift;
    my $jobid = shift;
    my $queue_name = shift;
    die "Unimplemented function: check_job_status";
}

sub describe {
    my $pkg = shift;
    my $cmd = shift;
    my $cmdstring = $cmd->cmd_string;
    log_normal($cmdstring);
    return 0;
}

sub submit {
    my $pkg = shift;
    my $cmd = shift;

    my $cmdstring = $cmd->cmd_string;
    log_normal($cmdstring);

    my $pid = open(SUBMIT, "$cmdstring |");
    unless ($pid) {
	die"Unable to submit job\n";
    }
    my $jobid;
    while (<SUBMIT>) {
	print STDERR "Parsing " . $_;
	if  (/^Request\s+(.*)\s+submitted to queue:\s*(.*)\s*$/) {
	    $jobid = $1;
	    my $queue_name = $2;
	    log_normal("Submission complete for job = $jobid");
	    last;
	}
    }
    # need to wait for NQS to complete before closing the pipe
    my $x = waitpid($pid, WUNTRACED);
    close(SUBMIT);
    warn "No jobid found " unless ($jobid);
    if ($jobid) {
	my ($return, $time) = $pkg->wait_for_job($cmd, $jobid);

	$cmd->execution_time($time);
	log_normal("Run complete with return code $return, total time = $time");
	return $return;
    } else {
	$cmd->execution_time(0);
	log_warn("No jobid found ");
	log_normal("Run failed");
	return 1;
    }
}

# this is the guy who needs to block.
sub  wait_for_job {
    my $pkg = shift;
    my $cmd = shift;
    my $jobid = shift;

    my $total_time = 0;

    my $start;
    my $end; 
    my $sec;
    my $msec;
    my $exit_code;

    my $DRIBBLEFILE = $cmd->dribblefile();

    log_normal("Wait is running on $DRIBBLEFILE");

    # JANUS specific flags!
    my $pid = open (INPUT, "tail -f  -50 $DRIBBLEFILE |");

    unless($pid) {
	die "Unable to open $DRIBBLEFILE";
    }
    
    while (<INPUT>) {
#	log_normal("dribble: $_");
	if (/\+\+\+\+\s*FAILED\s*\((\d+)\)/) { 
	    $exit_code = $1;
	    kill 9 => $pid;
	    last;
	}
	
	if (/\+\+\+\+\s*COMPLETED/) { 
	    $exit_code = 0;
	    kill 9 => $pid;
	    last;
	}

	if (/%cmd:\s*(.*)$/) {
	    $cmd = $1;
	    next;
	}
	
	if (/%start:\s*(\d+)\.(\d+)/) {
	    $start = [$1, $2];
	    next;
	}
	
	if (/%end:\s*(\d+)\.(\d+)/) {
	    $end = [$1, $2];
	    if ($start && $end) {
		my $elapsed = tv_interval($start, $end);
		log_notice(sprintf("cmd %s took %12.6f seconds\n", $cmd, $elapsed));
		$total_time += $elapsed;
	    } else {
		log_warn("Got %end without %start");
	    }

	    undef $start;
	    undef $end;
	    undef $cmd;
	    next;
	}
    }
    close(INPUT);
    log_notice("Closing pipe");
    return ($exit_code, $total_time);
}

sub touch {
    my $filename = shift;
    open(DF, "> $filename") or die "Unable to create $filename";
    close(DF);
}

1;
