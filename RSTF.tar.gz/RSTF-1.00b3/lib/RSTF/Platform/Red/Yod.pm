###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
#  
# 
# Yod.pm
# 
# Created by: Robert A. Ballance		Tue Sep 28 15:12:57 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Platform/Red/Yod.pm,v $
# $Revision: 1.3 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::Platform::Red::Yod;
use strict;

use RSTF::Exec::Dispatch;
use vars qw(@ISA);
@ISA = qw(RSTF::Exec::Dispatch);

use RSTF::FilePath;
use RSTF::LogFile;
use RSTF::Exec::Command;
use RSTF::Exec::Options;

use RSTF::DB::Utils;

my %mode_map = ( proc0 => 0,
		 proc3=> 3);

my @default_args = (procs => 1, arguments=>'', max_time=>'2:00:00', job_queue=>'snl', mode=>'proc0', is_parallel=>1);

sub init {
    my $self = shift;
    return $self->SUPER::init(@default_args, @_);
}

sub get_command {
  my $self = shift;
  my $cmd = shift;
  my $cmd_args = shift;
  my $options = shift;

  my $mode = $self->mode();

  # default to proc0
  my $modevar = $mode_map{$mode} || 0;

  my @args = split_argument_list($self->arguments);

  my $exe = $cmd->executable_file();
  # check for exe on path, unless we are in cross-compile mode
  unless ($options->suppress_path_lookups()) {
      $exe = find_executable($exe);
  }
  my $processor_ct = $self->procs();
# Build the magic reference here.
  return ['yod', '-sz', $processor_ct, '-proc', $modevar, @args, $exe, @$cmd_args];
}


sub nodes {
    my $self = shift;
    # Compute nodes from procs!
    my $processor_ct = $self->procs();
    my $mode = $self->mode();
    my $nodes = $processor_ct;
    if ($mode eq 'proc3') {
	if ($processor_ct % 2) {
	    # round up
	    $processor_ct++;
	    $nodes = $processor_ct / 2;
	}
    }
    return $nodes;
}

1;
