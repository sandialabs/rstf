###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# FilePath.pm
# 
# Created by: Robert A. Ballance		Mon Feb 16 13:13:54 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/FilePath.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  Simple path handling for the Run suite.
# Captures the working directory at startup
#
#   expand_path(X) takes the working directory onto X
#   push_directory(D) pushes the current directory onto a stack (like pushd)
#   pop_directory() pops the directory stack (like popd)
# 
###############################################################################


package RSTF::FilePath;

use File::Path;
use Exporter;
use Cwd;
use RSTF::LogFile;
use RSTF::DB::Utils;

use strict;
use warnings;

my $ROOT = cwd();
my $CWD = $ROOT;
my @dirs;

my $opt_paranoid = 1;

use vars qw(@ISA @EXPORT);

@ISA = qw(Exporter);
@EXPORT = qw(expand_path push_directory pop_directory set_working_root find_executable current_directory
	     make_directory make_log_directory);

# set the root directory
sub current_directory {
    return cwd();
}

# set the root directory
sub set_working_root {
  my $dir = shift || cwd();
  $ROOT = $dir;
}

sub expand_path {
  my $path = shift;
  # do environment variable substitution
  $path = subst_env_vars($path);

  # now return absolute pathnames
  if ($path =~ m[^/]) {
    return $path;
  }
  # handle tilde expansion
  if ($path =~ m[^~]) {
    my $home = $ENV{HOME};
    $path =~ s/~/$home/;
    return $path;
  }
  # Finally prefix root if necessary
  return sprintf("%s/%s", $ROOT,$path);
}

sub find_executable {
  my $name = shift;
  if ($name =~ m[^/]) {
    return $name;
  }
  if ($name =~ m[^~]) {
    my $home = $ENV{HOME};
    $name =~ s/~/$home/;
    return $name;
  }

  # Search the directory stack, and then PATH
  # Always search '.'
  my @paths = ($CWD, @dirs, split(/:/, $ENV{PATH}));
  foreach my $dir (@paths) {
     my $exe = sprintf("%s/%s", $dir, $name);
     if (-e $exe && -r $exe && -x $exe) {
       return $exe;
     }
   }
  die "Unable to find executable $name\n";
}

sub push_directory {
    my $new_directory = shift;

    if ($opt_paranoid) {
      my $dir = cwd();
      die "Mismatched directories $dir, $CWD" unless ($dir eq $CWD);
    }

    log_debug("Current directory is $CWD");
    push(@dirs, $CWD);
    make_directory($new_directory);
    chdir ($new_directory) or die "Unable to change to directory " . $new_directory;
    $CWD = cwd();
    $ENV{X7_WD}=$CWD;
    log_debug("Working directory is $CWD");
}

sub make_directory {
    my $new_directory = shift;

    if (! -e $new_directory) {
	log_notice("Creating directory " . $new_directory);
	mkpath($new_directory,0,0700) or die "Unable to create working directory " . $new_directory;
    }
}


sub pop_directory {
    my $new_dir = pop (@dirs);
    log_debug("Changing to " . $new_dir);
    chdir $new_dir or die "Unable to change to " . $new_dir;
    $CWD = $new_dir;

    if ($opt_paranoid) {
      my $dir = cwd();
      die "Mismatched directories $dir, $CWD" unless ($dir eq $CWD);
    }

    log_debug("Current directory is  now $CWD");
}

use constant CURRENT => 'CurrentRun';

sub make_log_directory {
    my $log_directory = shift;

    make_directory($log_directory);

    if (-e CURRENT) {
	unlink(CURRENT) or die "Unable to remove link to prior run";
    }
    
    if (-e $log_directory && -d $log_directory) {
	symlink($log_directory, CURRENT) or die "Unable to create symlink to " . CURRENT;
    }
}

1;
