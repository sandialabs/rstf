###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Parser.pm
# 
# Created by: Robert A. Ballance		Wed Mar 10 11:18:07 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Compile/Parser.pm,v $
# $Revision: 1.12 $
# $Name:  $
# $State: Exp $
# 
# 
###############################################################################

package RSTF::Compile::Parser;
use strict;
use warnings;
use RSTF::Compile::XMLParser;
use XML::Twig;
use RSTF::Exec;
use RSTF::Compile::ClassFactory;
use RSTF::Configuration;
use RSTF::DB::SystemConfiguration;
use RSTF::DB::Machine;

use vars qw(@ISA);
@ISA = qw(RSTF::Compile::XMLParser);

my $runner;
my $app;
my $platform;
my $global_sysconfig;

my @testcases;
my @outputdirectories;
my @matchers;
my @match_values;
my @runs;



# sub safe_get_text {
#   my $field = shift;
#   my $name = shift;
#   my $child;
#   if ($child = $field->first_child($name)) {
#     return $child->trimmed_text($name);
#   }
#   return undef;
# }

# sub safe_get_attr {
#   my $field = shift;
#   my $name = shift;
#   my $attr;
#   if ($attr = $field->att($name)) {
#     return $attr;
#   }
#   return undef;
# }

sub start_testcase {
  my ($twig, $field) = @_;
  @outputdirectories = ();
  @matchers = ();
  @match_values = ();
  @runs = ();
}

sub output_directory_set {
  my ($twig, $field) = @_;

  trace_enter('output_directory_set');
  my $type_name= safe_get_attr($field,    'type_name');
  my $type_id = safe_get_attr($field, 'type_id');
  my $id = safe_get_attr($field, 'id');
  unless ($type_name || $type_id) {
      die "Malformed data directory: no type specified\n";
  }


  my $testcase_id = $field->att('testcase_id');
  my $path = $field->first_child('directory')->trimmed_text();
  my $number = $field->first_child('number')->trimmed_text() || 1;
  my $dir = RSTF::Compile::ClassFactory->make_output_directory(
							    {type_name=>$type_name,
							     type_id=>$type_id,
							     output_directory_id=>$id,
							     testcase_id=>$testcase_id,
							     number => $number,
							     path => $path});
  push @outputdirectories, $dir;
  trace_exit('output_directory_set');
}

use Data::Dumper;
my $machine;

sub machine_handler {
    my ($twig, $field) = @_;

    trace_enter('machine_handler');    
    my $id = safe_get_attr($field, 'id');
    my $machine_name = safe_get_attr($field, 'machine_name');
    my $machine_platform_id = safe_get_attr($field, 'platform_id');
    my $machine_classified = safe_get_attr($field, 'classified');

    $machine = RSTF::Compile::ClassFactory->make_machine(
							{ machine_id => $id,
							  machine_name=> $machine_name, 
							  platform_id => $machine_platform_id,
							  classified => $machine_classified});
    trace_exit('machine_handler');
}


sub sysconfig_handler {
    my ($twig, $field) = @_;

    trace_enter('sysconfig_handler');
    my $id = safe_get_attr($field, 'id');
    my $osinfo = safe_get_text($field, 'osinfo');
    my $created = safe_get_text($field, 'timestamp');
    my $description = safe_get_text($field, 'description');

#    my $procs = safe_get_text($field, 'procsavailable');
#    my $nodes = safe_get_text($field, 'nodesavailable');

    $global_sysconfig =  RSTF::Compile::ClassFactory->make_sysconfig($id, $machine, $osinfo, $created, $description);
    trace_exit('sysconfig_handler');
}

sub get_app_binary {
    my ($field) = @_;
    my %args;
    trace_enter('app_binary_handler');
    $args{appbinary_id}= safe_get_attr($field, 'id');
    $args{platform_id} = safe_get_attr($field, 'platform_id');
    $args{compiled_by_id} = safe_get_attr($field, 'compiled_by_id');
    $args{app_id} = safe_get_attr($field, 'app_id');

    $args{filepath} = safe_get_text($field, 'filepath');
    $args{app_name} = safe_get_text($field, 'appname');
    $args{compilation_date} = safe_get_text($field, 'compilationdate');
    $args{compilation_host} = safe_get_text($field, 'host');
    $args{compilation_platform} = safe_get_text($field, 'compilationplatform');
    $args{compiled_by_email} = safe_get_text($field, 'compiledby');

    $args{md5sum} = safe_get_text($field, 'md5sum');
    $args{byte_count} = safe_get_text($field, 'bytecount');
    $args{size_info} = safe_get_text($field, 'sizeinfo');

    my $appbinary =  RSTF::Compile::ClassFactory->make_appbinary(\%args);
    trace_exit('app_binary_handler');
    return $appbinary;
}

# field is a Property object.
sub property_handler {
  my $twig = shift;
  my $field = shift;

  trace_enter('property_handler');
  my $type = safe_get_attr($field, 'type') || 'grep';
  my $name = safe_get_text($field, 'name');
  my $filename = safe_get_text($field, 'filename');
  my $pattern = safe_get_text($field, 'pattern');
  my $id = safe_get_attr($field, 'id');
  # cool, here to subclass matcher according to type
  push @matchers, RSTF::Compile::ClassFactory->make_property({filename => $filename, pattern => $pattern, property_name=> $name, match_type=>$type, property_id=>$id});
  trace_exit('property_handler');
}

# field is a Property object.
sub property_match_handler {
  my $twig = shift;
  my $field = shift;

  trace_enter('property_match_handler');
  my $property_id = safe_get_attr($field, 'property_id');
  my $id = safe_get_attr($field, 'id');
  my $run_id = safe_get_attr($field, 'run_id');

  my $result = safe_get_text($field, 'result');
  my $value= safe_get_text($field, 'value');
  push @match_values,  RSTF::Compile::ClassFactory->make_property_match({property_match_id=>$id,
								      property_id=>$property_id,
								      run_id=>$run_id,
								      matched=>$result,
								      value=>$value});
								     
  trace_exit('property_match_handler');
}

my %run_fields = (
		  runtag => 'tag',
		  starttime => 'time_start',
		  endtime => 'time_end',
		  setuptime => 'setup_time',
		  compiletime => 'compile_time',
		  installationtime => 'installation_time',
		  preprocesstime => 'preprocess_time',
		  postprocesstime => 'postprocess_time',
		  jobtime => 'job_time',
		  validationtime => 'validation_time',
		  gradetime => 'grade_time',
		  cleanuptime => 'cleanup_time'
		  );

sub run_handler {
  my $twig = shift;
  my $field = shift;

  trace_enter('run_handler');
  my $id = safe_get_attr($field, 'id');
  my %args;

  my $child;

  $args{run_id} = $id;

  if ($global_sysconfig) {
      $args{system_configuration} = $global_sysconfig;
      $args{system_config_id} = $global_sysconfig->system_config_id;
      $global_sysconfig = undef;
  }

  # Get outcome
  if ($child = $field->first_child('outcome')) {
      $args{outcome_id} = safe_get_attr($child, 'id');
      $args{note} = safe_get_text($child, 'description');
  }

  # get the purpose value
  if ($child = $field->first_child('purpose')) {
      $args{purpose_id} = safe_get_attr($child, 'id');
  }
  # get the validationgrade value
  if ($child = $field->first_child('validationgrade')) {
      $args{validation_id} = safe_get_attr($child, 'id');
  }

  # get the grade value
  if ($child = $field->first_child('grade')) {
      $args{grade_id} = safe_get_attr($child, 'id');
  }


  foreach my $key (keys %run_fields) {
      my $argname = $run_fields{$key};
      my $value = safe_get_text($field, $key);
      if ($value) {
	  $args{$argname} = $value;
      }
  }

  # property matchers?	  
  my @matches = @match_values;
  # I don't like this hack, but...
  my $index = 0;
  for (my $i = 0; $i <= $#matchers; $i++) {
      if ($matches[$i]) {
	  $matches[$i]->property($matchers[$i]);
      }
  }


  $args{property_matches}= RSTF::Compile::ClassFactory->make_property_match_list({values=>\@matches, run_id=>$id});

  my $new_run = RSTF::Compile::ClassFactory->make_run(\%args);

  # get the app binary value
  if ($child = $field->first_child('appbinary')) {
      my $app_binary= get_app_binary($child);
      $new_run->appbinary($app_binary);
  }

  push @runs,  $new_run;
  trace_exit('run_handler');
}


# $field is the Dispatch guy, if present.
sub get_dispatcher {
  my $field = shift;
  my $args = "";
  my $name = 'direct';
  my $mode;
  my $procs = 1;
  my $queue;
  my $time;

  my $child;
  trace_enter('get_dispatcher');
  if ($field) {
      if ($child = $field->first_child('direct')) {
	  $name = 'direct';
	  $procs  = 1;
      } elsif ($child = $field->first_child('parallel')) {
	  $name = safe_get_attr($child, 'type');
	  $procs = safe_get_text($child, 'procs'),
	  $args = safe_get_text($child, 'arguments');
	  $mode = safe_get_text($child, 'mode');
	  $time = safe_get_text($child, 'timelimit');
	  $queue = safe_get_text($child, 'queue');
      } else {
	  die "Malformed dispatch\n";
      }
  }
  die "Malformed dispatch - no name found" unless ($name);
  my $dispatcher = RSTF::Compile::ClassFactory->make_dispatcher($platform,
								$name,
								$procs,
								$mode,
								$time,
								$args, 
								$queue);
  trace_exit('get_dispatcher');
  return $dispatcher;
}


sub get_command {
  my $field = shift;
  my $args = safe_get_text($field, 'arguments') || '';
  my $failure_ok = safe_get_attr($field, 'failure_ok') || '0';
  trace_enter('get_command');
  my $cmd = RSTF::Compile::ClassFactory->make_command({
      command_id => safe_get_attr($field, 'id'),
      executable => safe_get_text($field, 'executable'),
      description => safe_get_text($field, 'description'),
      failure_ok => ($failure_ok eq '1' ? 1 : 0),
      arguments => $args,
      stdin => safe_get_text($field, 'stdin'),
      stdout => safe_get_text($field, 'stdout'),
      stderr=> safe_get_text($field, 'stderr'),
      dispatch => get_dispatcher($field->first_child('dispatch')),
      working_directory=> safe_get_text($field, 'workingdirectory'),
      install_directory => safe_get_text($field, 'installationdirectory')
      }
    );
  trace_exit('get_command');
  return $cmd;
}

sub get_nested_commands {
  my ($field, $key_slots, $name, $blocktype) = @_;
  $blocktype ||= $name;

  trace_enter('get_nested_commands');
  my $subfield = $field->first_child($name);
  my @commands = ();
  
  if ($subfield) {
      my $cmd_field = $subfield->first_child('command');
      while ($cmd_field) {
	  my $cmd = get_command($cmd_field);
	  push @commands, $cmd;
	  $cmd_field = $cmd_field->next_sibling('command');
      }
      return RSTF::Compile::ClassFactory->make_outer_block({commands=>\@commands, name=>$blocktype, blocks=>[], key_slots=>$key_slots});
  }
  my $block =  RSTF::Compile::ClassFactory->make_outer_block({commands=>[], name=>$blocktype, blocks=>[], key_slots=>$key_slots});
  trace_exit('get_nested_commands');
  return $block;
}



sub get_loginfo {
  my $field = shift;
  trace_enter('get_loginfo');
  my $subfield = $field->first_child('log');
  if ($subfield) {
    my $dir = safe_get_text($subfield, 'directory') || undef;
    my $name = safe_get_text($subfield, 'name');
    trace_exit('get_loginfo');
    return ($dir, $name);
  }
  trace_exit('get_loginfo');
  return (undef, undef);
}

sub get_environment {
  my ($field, $key_slots) = @_;

  trace_exit('get_environment');
  my $subfield = $field->first_child('environment');
  if ($subfield) {
    my @vars = ();
    my $child = $subfield->first_child();
    while ($child) {
	if ($child -> matches('pathdir')) {
	    my $dir =  $child->trimmed_text();
	    my $id = safe_get_attr($child, 'id');
	    my $testcase_id = safe_get_attr($child, 'testcase_id');
	    push @vars, RSTF::Compile::ClassFactory->make_environment_path({value=>$dir, env_id=>$id, testcase_id=>$testcase_id});
	} 
	if ($child -> matches('variable')) {
	    my $id = safe_get_attr($child, 'id');
	    my $testcase_id = safe_get_attr($child, 'testcase_id');
	    my $name =  $child->first_child('name')->trimmed_text();
	    my $value =  $child->first_child('value')->trimmed_text();
	    push @vars, RSTF::Compile::ClassFactory->make_environment_variable({name=>$name, value=>$value, env_id=>$id, testcase_id=>$testcase_id});
	}
      $child = $child->next_sibling();
    }
    trace_exit('get_environment');
    return RSTF::Compile::ClassFactory->make_environment({settings=> \@vars, key_slots=>$key_slots});
  }
  trace_exit('get_environment');
  return RSTF::Compile::ClassFactory->make_environment({settings=> [], key_slots=>$key_slots});
}


sub testcase_handler {
    my ($twig, $field) = @_;
    my $child;
    trace_enter('testcase_handler');
    my @outputs = @outputdirectories;
    my @properties = @matchers;
    my @run_list = @runs;

    my $key_slots = ['testcase_id'];



    my $testcase = 
	RSTF::Compile::ClassFactory->
	make_testcase(
		      {
			  name => safe_get_text($field, 'name'),
			  platform=>$platform,
			  testcase_id=>safe_get_attr($field, 'id'),
			  environment => get_environment($field, $key_slots),
			  description => safe_get_text($field, 'description'),
			  
			  size => safe_get_text($field, 'size') || 1,
			  
			  working_directory => safe_get_text($field, 'workingdirectory'),
			  
			  data_directories => 
			      RSTF::Compile::ClassFactory->make_data_directory_list({
				  directories=>\@outputs
				  }),
				      
				      stdout => safe_get_text($field, 'stdout'),
				      stderr=> safe_get_text($field, 'stderr'),
				      
				      preprocess_commands =>get_nested_commands($field, $key_slots, 'preprocess'),
				      postprocess_commands =>get_nested_commands($field, $key_slots, 'postprocess'),
				      validate_commands =>get_nested_commands($field, $key_slots, 'validate'),
				      exec_commands => get_nested_commands($field, $key_slots, 'runjob'),

				      grade_commands => get_nested_commands($field, $key_slots, 'score'),
				      compile_commands =>get_nested_commands($field, $key_slots, 'compile'),
				      setup_commands =>get_nested_commands($field, $key_slots, 'setup'),
				      cleanup_commands =>get_nested_commands($field, $key_slots, 'cleanup'),
				      installation_commands =>get_nested_commands($field, $key_slots, 'installation'),
				      final_commands =>get_nested_commands($field, $key_slots, 'finally'),
				      
				      property_matchers => RSTF::Compile::ClassFactory->make_propertylist({matchers=>\@properties,key_slots=>$key_slots}),
				  });
    
    my $rl = RSTF::Compile::ClassFactory->
	make_run_list({runs=>\@run_list, testcase_id=>$testcase->testcase_id});

    die "Bad run list" unless($rl);

    $testcase->run_list($rl);

    # get the app binary value
    if ($child = $field->first_child('appbinary')) {
	my $app_binary = get_app_binary($child);
	$testcase->appbinary($app_binary)
    }

    push @testcases, $testcase;
    trace_exit('testcase_handler');
}

sub application {
  my ($twig, $field) = @_;

  trace_enter('application');
  my $hard_coded_value = undef;
  $app = RSTF::Compile::ClassFactory->make_application({
      name => safe_get_text($field, 'name'),
      app_id=>safe_get_attr($field, 'id'),
  });
  trace_exit('application');
}


sub platform {
  trace_enter('platform');
  my ($twig, $field) = @_;
  my $platform_id = safe_get_attr($field, 'id');
  my $platform_name = safe_get_attr($field, 'name');
  $platform = RSTF::Compile::ClassFactory->make_platform($platform_name, $platform_id);
  trace_exit('platform');

}

sub run_outcome {
   my ($twig, $field) = @_;
   trace_enter('run_outcome');
   my $id = safe_get_attr($field, 'id');
   my $name = safe_get_text($field, 'description');
   trace_enter('run_outcome');
 }


sub benchmark {
  my ($twig, $field) = @_;
  my @tests = @testcases;
  my ($logdir, $logname) = get_loginfo($field);

  trace_enter('benchmark');
  # app_config
  $runner = RSTF::Compile::ClassFactory->make_benchmark({root_directory => safe_get_text($field, 'rootdirectory'),
							 benchmark_id=>safe_get_attr($field, 'id'),
							 nickname=>safe_get_attr($field, 'nickname'),
							 platform => $platform,
							 testcases => \@tests,
							 application => $app,
							 description=>safe_get_text($field, 'description'),
							 title=>safe_get_text($field, 'title'),
							 log_path=>$logdir,
							 log_filename=>$logname,
						     });
  trace_exit('benchmark');
}

sub parse {
  my $filename = shift;

  my $config = new RSTF::Configuration;
  my $verbose = $config->verbose();
  trace_init($verbose);

  trace_enter('parse');
  # (re)init any global lists.
  @testcases = ();
  @outputdirectories = ();
  @matchers = ();
  @match_values= ();
  @runs = ();

  my @runs;
  my $twig;
  eval {
      $twig = new XML::Twig(
			  TwigHandlers => { 
			      application => \&application,
			      testcase => \&testcase_handler,
			      benchmark => \&benchmark,
			      platform => \&platform,
			      property => \&property_handler,
			      propertymatch => \&property_match_handler,
			      run => \&run_handler,
			      systemconfiguration => \&sysconfig_handler,
			      machine => \&machine_handler,
			      datadirectory => \&output_directory_set
			      },
			    start_tag_handlers => {
				testcase => \&start_testcase,
			    }
			    );
  };
  if ($@) {
      die $@;
  }
# $twig->safe_parsefile($filename) or die "Malformed file $filename";
  if ($verbose) {
      print STDERR "Calling parsefile on $filename\n";
  }
  my $ok = 0;
  eval {
      $ok = $twig->parsefile($filename);
  };
  if ($@) {
      die $@;
  }
#  print STDERR "PARSE COMPLETE\n";
  if ($verbose) {
      print STDERR "parsefile returns $ok\n";
  }
  if ($ok) {
      my @module_list = RSTF::Compile::ClassFactory->get_classes();
      return ($runner, $platform, \@module_list);
  }
  return (undef, undef, undef);
}

1;
