###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# ClassFactory.pm
# 
# Created by: Robert A. Ballance		Mon Mar 29 09:13:26 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Compile/ClassFactory.pm,v $
# $Revision: 1.9 $
# $Name:  $
# $State: Exp $
# 
# The parser uses this class to create new objects. It's really a factoring
# to hide the various application objects, and to handle some database
# lookups.
# 
###############################################################################


package RSTF::Compile::ClassFactory;
use strict;
use warnings;

use RSTF::Exec;
use RSTF::Utils;
use RSTF::DB::DataDirectoryList;
use RSTF::DB::OutputDirectory;
use RSTF::DB::RunList;
use RSTF::DB::Machine;
use RSTF::DB::SystemConfiguration;
use RSTF::Platform::Platform;
use RSTF::DB::AppBinary;

my %classes;

sub get_classes {
    my $pkg = shift;
    return sort keys %classes;
}

# package method!
sub add_class {
    my $obj = shift;
    if ($obj) {
	$classes{ref($obj)}++;
    }
}

# sub execute_query {
#   my $self = shift;
#   my  $sql = shift;
#   my $dbh = $self->dbh();
#   my $sth = $dbh->prepare($sql);
#   $sth->execute() || die $sth->errstr;
#   if (my @row = $sth->fetchrow_array()) {
#     return $row[0];
#   }
#   return undef;
# }

sub copy_fields {
    my $pkg = shift;
    my $obj = shift;
    my $hash_ref = shift;
    if ($obj && $hash_ref) {
	foreach my $key (keys %$hash_ref) {
	    my $value = $hash_ref->{$key};
	    if ($value) {
		$obj->$key($value);
	    }
	}
    }
}

sub make_directory_set {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::Exec::DiskAllocator(%$values);
#  $pkg->copy_fields($obj, $values);
    add_class($obj);
    return $obj;
}

sub make_property {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::Exec::Property(%$values);
#  $pkg->copy_fields($obj, $values);
    add_class($obj);
    return $obj;
}

sub make_propertylist {
    my $pkg = shift;
    my $values = shift;

    my $obj = new RSTF::Exec::PropertyList( %$values);
    add_class($obj);
    return $obj;
}


sub make_property_match {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::PropertyMatch(%$values);
#  $pkg->copy_fields($obj, $values);
    add_class($obj);
    return $obj;
}

sub make_property_match_list {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::PropertyMatchList(%$values);
    add_class($obj);
    return $obj;
}

# Is this the best place to look for matching AppBinary files?
# 
#
sub make_appbinary {
    my $pkg = shift;
    my $values = shift;
    my $appbinary = new RSTF::DB::AppBinary(%$values);


# Force binary object to update external values!
    $appbinary->prepare_insert();
    add_class($appbinary);

    if ($appbinary->md5sum) {
	my $platform = $appbinary->platform();
	my $app = $appbinary->application();
	if ($app) { 
	    my $orig_binary= RSTF::DB::AppBinary->find_by_name({ md5sum=> $appbinary->md5sum,
								 appname => $app->name,
								 platform=>$platform->name
								 } );
	    if ($orig_binary) {
		$orig_binary->fetch();
		return $orig_binary;
	    }  else {
		if (yes_no("No compatible AppBinary object is in the database. " .
			   "Perhaps you need to run rst write-build-info?\n" . 
			   "Create a new one?", 'yes')) {
		    print "Doing insert on " , $appbinary->md5sum, "\n";
		    $appbinary->insert();
		} else {
		    die "Please create the executable first!\n";
		}
		return $appbinary;
	    }
	} 
    }
    return $appbinary;
}


sub make_dispatcher {
    my $pkg = shift;
    my $platform= shift;
    my ($name, $procs, $mode, $time, $args, $queue) = @_;

    my $dispatcher = $platform->get_dispatcher({name => $name,  procs => $procs, mode => $mode, max_time => $time, arguments => $args, job_queue=>$queue});
    add_class($dispatcher);
    return $dispatcher;
}

sub make_machine {
    my $pkg = shift;
    my $args = shift;


    my $machine;

    unless ($args->{machine_id}) {
	if ($args->{machine_name} &&  $args->{platform_id}) {
	    $machine = RSTF::DB::Machine->find_by_name($args->{machine_name}, $args->{platform_id});
#	    print STDERR "Found machine $machine\n";
	}
    }
    unless ($machine) {
	$machine = new RSTF::DB::Machine(%$args);
    }
    unless (defined($machine->machine_id)) {
	$machine->insert();
    } 
    add_class($machine);

    return $machine;
}

sub make_sysconfig {
    my $pkg = shift;
    my ($id, $machine, $osinfo, $created, $description) = @_;

    my $sysconfig;
    unless ($id) {
	if ($machine && $machine->machine_id) {
	    $sysconfig = RSTF::DB::SystemConfiguration->find_by_name($osinfo, $machine->machine_id);
	} else {
	    warn "Bad machine spec!\n";
	}
    }

    unless ($sysconfig) {
	$sysconfig = new RSTF::DB::SystemConfiguration(system_config_id=>$id,
						       machine_id=> $machine->machine_id, 
						       os=>$osinfo,
						       created=>$created,
						       description=>$description);
    }
    unless (defined($sysconfig->system_config_id)) {
	$sysconfig = $sysconfig->insert();
    }

    if ($sysconfig) {
	add_class($sysconfig);
    }
    return $sysconfig;
}


sub make_command {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::Exec::Command(%$values);
    add_class($obj);
    return $obj;
}

sub make_outer_block {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::Exec::OuterBlock(%$values);
    add_class($obj);
#  $obj->fetch();
    return $obj;
}

sub make_data_directory_list {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::DataDirectoryList(%$values);
    add_class($obj);
    return $obj;
}

sub make_output_directory {
    my $pkg = shift;
    my $values = shift;
    if ($values->{type_name} eq 'scalar') {
	my $obj =  new RSTF::DB::OutputDirectory(%$values);
	add_class($obj);
	return $obj;
    } else {
	my $obj =  new RSTF::Exec::DiskAllocator(%$values);
	add_class($obj);
	return $obj;
    }
}

sub make_run {
    my $pkg = shift;
    my $values = shift;

    my $run;
    if ($values->{run_id}) {
	my $run = new RSTF::DB::Run(%$values);
	if ($run->run_id) {
	    $run->fetch();
	}
    }
    unless ($run) {
	if ($values->{testcase_id} && $values->{time_start}) {
	    $run = RSTF::DB::Run->find_by_name($values->{timestart}, $values->{testcase_id} );
	} 
    }
    unless ($run) {
	$run = new RSTF::DB::Run(%$values);
    }
    add_class($run);
    return $run;
}

sub make_run_list {
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::RunList(%$values);
    add_class($obj);
    return $obj;
}

sub make_environment_variable{
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::EnvVar(%$values);
    add_class($obj);
    $obj->fetch();
    return $obj;
}

sub make_environment_path{
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::EnvPath(%$values);
    add_class($obj);
    $obj->fetch();
#  $pkg->copy_fields($obj, $values);
    return $obj;
}

sub make_environment{
    my $pkg = shift;
    my $values = shift;
    my $obj = new RSTF::DB::Environment(%$values);
    add_class($obj);
#  $obj->fetch();
#  $pkg->copy_fields($obj, $values);
    return $obj;
}

sub make_testcase {
    my $pkg = shift;
    my $values = shift;
    my $testcase = new RSTF::Exec::TestCase(testcase_id=>$values->{testcase_id});
    add_class($testcase);
    $testcase->fetch();
    $pkg->copy_fields($testcase, $values);
    return $testcase;
}

sub make_application {
    my $pkg = shift;
    my $values = shift;

    my $app;
    if ($values->{name}) {
	$app = RSTF::Exec::Application->find_by_name($values->{name});
    } 
    unless ($app) {
	$app = new RSTF::Exec::Application(app_id=>$values->{app_id});
    }

    if ($app) {
	$app->fetch();
	$pkg->copy_fields($app, $values);
	add_class($app);
    }
    return $app;
}


sub make_platform {
    my $pkg = shift;
    my $platform_name = shift;
    my $platform_id = shift;
    unless ($platform_id) {
	my $x = RSTF::Platform::Platform->find_by_name($platform_name);
	die "Unable to find platform $platform_name" unless ($x);
	$platform_id = $x->platform_id();
    }
    my $platform = RSTF::Platform::Platform::get_platform($platform_name, $platform_id);
    $platform->fetch();
    add_class($platform);
    return $platform;
}

sub make_benchmark{
    my $pkg = shift;
    my $values = shift;

    my $obj;

    my $name = $values->{nickname};
    if ($name && $name ne '') {
	$obj = RSTF::Exec::Benchmark->find_by_name($name);
    }
    unless ($obj) {
	$obj = new RSTF::Exec::Benchmark(benchmark_id=>$values->{benchmark_id});
    }
    $obj->fetch();
    $pkg->copy_fields($obj, $values);
    add_class($obj);
    return $obj;
}

1;
