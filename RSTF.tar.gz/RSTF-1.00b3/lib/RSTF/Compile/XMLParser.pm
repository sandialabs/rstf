###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# XMLParser.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Compile/XMLParser.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
# common routines for parsing
#
package RSTF::Compile::XMLParser;
use strict;
use XML::Twig;
use vars qw(@ISA @EXPORT);
require Exporter;
@ISA = 'Exporter';
@EXPORT = qw(safe_get_text safe_get_attr trace_init trace_enter trace_exit);


sub safe_get_text {
  my $field = shift;
  my $name = shift;
  my $child;
  if ($child = $field->first_child($name)) {
    return $child->trimmed_text($name);
  }
  return undef;
}

sub safe_get_attr {
  my $field = shift;
  my $name = shift;
  my $attr = $field->att($name);
  if (defined($attr)) {
      return $attr;
  }
  return undef;
}

my $_xml_verbose = 1;			# Set at runtime!
my $_xml_level = 0;
my $_xml_indent = 0;

sub trace_init {
    my $flag = shift;
    my $indent = shift;
    $indent ||= 2;

    $_xml_verbose = $flag;
    $_xml_indent = $indent;
}

sub trace_enter {
    my $name = shift;
    if ($_xml_verbose) {
	print STDERR (' ' x $_xml_level) . "Entering $name\n";
	$_xml_level += $_xml_indent;
    }
}

sub trace_exit {
    my $name = shift;
    if ($_xml_verbose) {
	$_xml_level -= $_xml_indent;
	print STDERR (' ' x $_xml_level) . "Leaving $name\n";
    }
}

1;
