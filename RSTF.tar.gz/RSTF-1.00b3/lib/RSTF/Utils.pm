###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Utils.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Utils.pm,v $
# $Revision: 1.8 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::Utils;
use strict;
use warnings;

require Exporter;

our @ISA = qw(Exporter);

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

our @EXPORT = qw( yes_no prompt_for_string);

# Returns a the name of the validated file, or undef
sub validate {
    my $file = shift;
    my $dtd = shift;
    my $filename = force_suffix($file, 'xml');
    if ($filename && -e $filename && -r $filename) {
	if (system("xmllint --noout --dtdvalid $dtd $filename") == 0) {
	    return $filename;
	}
    } else {
	die "$filename: not found\n";
    }
    return undef;
}


sub force_suffix {
    my $filename = shift;
    my $suffix = shift;
    if ($filename !~ /\.$suffix$/) {
	if ($filename =~ /^[\w\-\/]+$/) {
	    $filename .= ".$suffix";
	} else {
	    warn "$filename does not appear to be a valid input.";
	    return undef;
	}
    };
    return $filename;
}    

# prompt for a yes/no answer/
# yes_no($prompt, $default)
# if the $default is not specified, it defaults to 'yes'
# Returns: 1 on match, 0 on no-match
sub yes_no {
    my $prompt = shift;
    my $default = shift || 'yes';
    my $line;
    my $flushvalue = $|;
    $| = 1;
    my $result;

    $prompt .= " [$default] ";
    print $prompt;
    while (defined($line = <STDIN>)) {
	chomp($line);
	$line =~ s/\s+//g;
	if ($line =~ /^\s*$/) {
	    $line = $default;
	}
	if ($line =~ /^\s*[Yy][Ee]?[Ss]?\s*$/i) {
	    $result = 1;
	    last;
	}
	if ($line =~ /^\s*[NN][Oo]?\s*$/i) {
	    $result = 0;
	    last;
	}
	print "Found /$line/";
	print $prompt;
    }
    $| = $flushvalue;
    return $result;
}

# prompt for a string
# prompt_for_string($prompt, $default)
# Returns: new string.
sub prompt_for_string {
    my $prompt = shift;
    my $default = shift || '';

    my $line;
    my $flushvalue = $|;
    $| = 1;

    $prompt .= " [$default] ";
    print $prompt;
    $line = <STDIN>;
    chomp($line);
    if ($line =~ /^\s*$/) {
	$line = $default;
    }
    $| = $flushvalue;
    return $line;
}

1;
