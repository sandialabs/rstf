###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# GradedCommand.pm
# 
# Created by: Robert A. Ballance		Mon May 17 09:30:12 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/GradedCommand.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
# GradedCommand overrides the usual Command class because the execution has to 
# read from the output of the Command. This is akin to Queue command, but accomplishes
# the task by using IPC::Run features, rather than opening the given command
# as a pipe.
# Why do I use both methods?
#
#  The 'grade' executable should be on the path
#  It should print 1 line of the form 'Grade: X' where X is a known mnemonmic
#  It should return 0 for success and 1 for failure.
#
#  Stdout is read
#  Stderr is ignored, so both XML slots are ignored.
#  
# 
###############################################################################

package RSTF::Exec::GradedCommand;
use strict;
use warnings;

use RSTF::Exec::Command;
use RSTF::LogFile;
use RSTF::DB::Grade;

use vars qw(@ISA);

@ISA = qw(RSTF::Exec::Command);

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [ qw( regexp ) ] );

sub init {
  my $self = shift;
  return $self->SUPER::init( @_);
}
	
#  This is *NOT* thread safe.
my $in;
my $out;

sub _make_harness {
    my $self = shift;
    my $env = shift;
    my @harness_args = ();

    my $stdin = $self->stdin();
    if ($self->stdout) {
	warn "Stdout setting on Grade command being ignored!";
	$self->stdout(undef);
    }
    my $stderr = $self->stderr();

    if ($stdin) {
	push(@harness_args, ('<', $stdin));
    } else {
	push(@harness_args, \$in);
    }

    push(@harness_args, \$out);

    if ($stderr) {
	# Tie stdout to stderr as needed.
	push(@harness_args, ('2>', $stderr));
    }
    $self->_command_args(\@harness_args);
}

sub finish_command {
    my $self = shift;
    my $run = shift;

    my $grade_char;
    my $comment;
    my $regexp = $self->regexp;

    if ($out=~ /$regexp/) {
	$grade_char = $1;
	$comment = $2;
	if ($comment) {
	    #trim
	    $comment =~ s/^\s*//g;
	    $comment =~ s/\s*$//g;
	    if ($comment eq '') {
		$comment = undef;
	    }
	}
    } else {
	die "Grade command returned an invalid line:  $out";
    }
    my $grade = RSTF::DB::Grade->grade_from_mnemonic($grade_char);
    unless ($grade) {
	die "Unable to find grade $grade_char";
    }
    if ($comment) {
	$grade->comments($comment);
    }
    $self->grade($grade);
    log_normal("Graded command complete with grade " . $grade->mnemonic);
    if ($comment) {
	log_normal("Graded command: $comment");
    }
    return 1;
}

1;
    
