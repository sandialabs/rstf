###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# OuterBlock.pm
# 
# Created by: Robert A. Ballance		Tue Mar  2 10:23:04 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/OuterBlock.pm,v $
# $Revision: 1.6 $
# $Name:  $
# $State: Exp $
# 
#  'OuterBlock' represents the equivalent of a sequence of basic blocks.
#
###############################################################################
#
#
package RSTF::Exec::OuterBlock;
use strict;

use RSTF::DB::OuterBlock;

use vars qw(@ISA);
@ISA =qw(RSTF::DB::OuterBlock);

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [qw(blocks execution_time last_block)] );

use RSTF::Exec::Command;
use RSTF::Exec::Block;
use RSTF::Exec::ParBlock;
use RSTF::Exec::Options;

my @default_args = (blocks=>[],  name => 'Unnamed block', execution_time => 0);
sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

sub find_bb {
    my $self = shift;
    my $platform = shift;

    my $current_block = new RSTF::Exec::Block();
    my @blocks = ();
    my $commands = $self->commands();
    foreach my $command (@$commands) {			
	if (!$current_block->add($command, $platform)) {
	    
	    # First close this block
	    if (!$current_block->is_empty()) {
		push @blocks, $current_block;
	    }
	    
	    # now open a new one
	    if ($command->is_parallel) {
		$current_block = new RSTF::Exec::ParBlock();
	    } else {
		$current_block = new RSTF::Exec::Block();
	    }
	    $current_block->add($command, $platform);
	}
    }

    # Finally close the old block
    if (!$current_block->is_empty()) {
	push @blocks, $current_block;
    }
    $self->blocks(\@blocks);
}


sub compile {
  my $self = shift;
  my $env = shift;
  my $options = shift;
  
  $self->find_bb($options->platform());
  my $blocks = $self->blocks();
  foreach my $block (@$blocks) {
      $block->compile($env, $options, $self->name);
  }
}

sub get_parallel_dispatch {
    my $self = shift;
    my $platform = shift;

    my $commands = $self->commands;
    my $dispatch;

    foreach my $command (@$commands) {
	my $cmd_disp = $command->dispatch();    
	
	unless ($dispatch) {
	    # Need own dispatch
	    $dispatch = $platform->clone_dispatch($cmd_disp);
	    # reset time to 0!
	    $dispatch->max_time('0:00:00');
	}
	if ($dispatch->unify($cmd_disp)) {
	    next;
	}
	# introduce a partial order on normal queues?
	warn "Unable to unify the various dispatch elements in this file.";
	warn "Try specifying a queue on the command line.";
	return undef;
    }
    return $dispatch;
}

#
# Just run the list of compiled commands and
# execute them. In general, the $env is a
# test case.
sub execute {
  my $self = shift;
  my $options = shift;
  my $run  = shift;

  my $blocks = $self->blocks();
  my $time = 0;
  my $failed = 0;
  my $last_block;
  foreach my $block (@$blocks) {
      # Blocks return 0 on success
      $last_block = $block;
      $failed = $block->execute($options, $run);
      $time += $block->execution_time();
      if ($failed) {
	  last;
      }
  }
  $self->execution_time($time);
  # Can now do something with last block.
  $self->last_block($last_block);
  return $failed;
}

sub grade {
    my $self = shift;
    my $last_block = $self->last_block();
    if ($last_block) {
	return $last_block->grade();
    }
    return undef;
}

1;
