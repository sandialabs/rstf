###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Property.pm
# 
# Created by: Robert A. Ballance		Wed Apr 14 14:20:50 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Property.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 

###############################################################################
package RSTF::Exec::Property;

use strict;

use RSTF::DB::Property;
use vars qw(@ISA);
use RSTF::DB::PropertyMatch;

@ISA = qw(RSTF::DB::Property);

sub do_match {
  my $self = shift;
  my $run = shift;
  my $filename = $self->filename;
  my $filepath = $self->filepath;
  my $pattern = $self->pattern;
  my $name = $self->property_name;
 
  my $result = new RSTF::DB::PropertyMatch(run_id => $run ? $run->run_id : undef,
					   matched=> 'false',
					   property=>$self,
					   property_id=>$self->property_id);

  if ($filepath) {
    $filename = sprintf("%s/%s", $filepath, $filename);
  }
  open(INFILE, "<$filename") or die "Unable to open $filename";
  while (<INFILE>) {
    if (/$pattern/) {
      my $value = $1 || 'present';
      $result->matched('true');
      $result->value($value);
      last;
    }
  }
  close(INFILE);
  $self->result($result);
  return $result;
}

1;

