###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Command.pm
# 
# Created by: Robert A. Ballance		Tue Feb 17 12:43:53 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Command.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Exec::Command;

use RSTF::DB::Command;
use RSTF::DB::Utils;
use vars qw(@ISA);

@ISA = qw(RSTF::DB::Command);

use Class::MethodMaker (
    new_with_init => 'new',
    get_set => [ qw(
		    _command_args
		    _compiled_command

		    execution_time
		    grade

		    _tied_outputs
		    _stdout_filename

		   )]
);

use strict;
use RSTF::Exec::TestCase;  # For command line fixups.
use RSTF::LogFile;
use RSTF::FilePath;
use RSTF::Exec::Options;
use RSTF::Exec::Property;
use Cwd;
use Time::HiRes qw(tv_interval gettimeofday);

use IPC::Run qw(run timeout harness);

my @default_args = ();

sub init {
  my $self = shift;
  return $self->SUPER::init(@default_args, @_);
}


sub describe  {
  my $self = shift;
  return $self->description || '';
}

sub procs {
  my $self = shift;
  return $self->dispatch->procs();
}

# Returns T iff this command needs to be executed
# using parallel execution.
sub is_parallel {
  my $self = shift;
  return $self->dispatch->is_parallel();
}

# Return the max wall time of the command (if specified);
sub max_wall_time {
    my $self = shift;
    my $platform = shift;
    my $arg = shift;
    die "max_wall_time : no dispatcher!\n" unless ($self->dispatch);
    if ($arg) {
	$self->dispatch->max_time($arg);
    }
    return $self->dispatch()->max_time() || $platform->default_wall_time;
}

sub executable_file {
  my $self = shift;
  my $path = $self->install_directory;
  my $binary_name = $self->executable();
  if ($path) {
     return expand_path(sprintf("%s/%s", $path, $binary_name));
  }
  return $binary_name;
}

sub cmd_string {
  my $self = shift;
  my $cmd = $self->_compiled_command();
  my $harness_args = $self->_command_args();
  return join(' ', @$cmd) . ' ' . join(' ', @$harness_args);
}


sub compile {
  my $self = shift;
  my $env = shift;
  my $options = shift;

  my @arglist = split_argument_list($self->arguments);
  my $baseargs = \@arglist;

  my $dispatch = $self->dispatch();

  my $cmd_ref = $dispatch->get_command($self,  $baseargs, $options);
  $self->_compiled_command($cmd_ref);
  $self->_make_harness($env);
  return $self;
}

# 
sub _make_harness {
    my $self = shift;
    my $env = shift;
    my @harness_args = ();

    my $stdin = $self->stdin();
    my $stdout = $self->stdout();
    my $stderr = $self->stderr();

    my $stdout_director = '>';
    my $stderr_director = '2>';
    # Is this inheritance necessary?
    if ($env) {
	unless ($stdout) {
	    $stdout = $env->std_output_filename();
	    $stdout_director = '>>';
	}
	unless ($stderr) {
	    $stderr = $env->std_error_filename();
	    $stderr_director = '2>>';
	}
    }

    
    if ($stdin) {
#	$stdin = expand_path($stdin);
	push(@harness_args, ('<', $stdin));
    }

    if ($stdout) {
#	$stdout = expand_path($stdout);
	$self->_stdout_filename($stdout);
	push(@harness_args, ($stdout_director, $stdout));
    }

    if ($stderr) {
	# Tie stdout to stderr as needed.
#	my $expanded_stderr = expand_path($stderr);
	my $expanded_stderr = $stderr;
	# This test has to look at both the unexpanded and expanded value of $stderr!
	if (($stderr =~ m/stdout/i)  or (defined($stdout) && ($stdout eq $expanded_stderr))) {
	    $self->_tied_outputs(1);
	    # if tied, and $stdout is appending, this will still work.
	    push(@harness_args, '2>&1');
	} else {
	    push(@harness_args, ($stderr_director, $expanded_stderr));
	}
    }
    $self->_command_args(\@harness_args);
}

sub as_shell_command {
    my $self = shift;

    my $newdir = $self->working_directory();

    # Extend to check for failure!
    my $cmd_string = $self->cmd_string();
    if (defined($newdir)) {
	$cmd_string =  sprintf("(cd %s; run_command %d %s)", expand_path($newdir),
			       $self->failure_ok ? 1 : 0,
			       $cmd_string);
    }  else {
	$cmd_string =  sprintf("run_command %d %s",  $self->failure_ok ? 1 : 0,     $cmd_string);
    }
    return $cmd_string;
}

sub execute {
    my $self = shift;
    my $options = shift;
    my $run  = shift;

    my $newdir = $self->working_directory();
    if (defined($newdir)) {
      push_directory(expand_path($newdir));
    }

    # Compile the command (and bind the executables!) after
    # pushing into the current working directory.
    my $cmd = $self->_compiled_command();
    my $harness_args = $self->_command_args();

    my @results = ();
    eval {
      my $cmd_harness = harness $cmd, @$harness_args;
      my $pwd = cwd();

      log_debug("In directory " . $pwd);
      my $cmd_string = $self->cmd_string;
      log_normal("Command: (" . $self->describe  . ") => " . $cmd_string);

      if ($options->dryrun()) {
	@results = (0);
      } else {
	my $before = [gettimeofday];
	$cmd_harness->run();
	my $after = [gettimeofday];
	$cmd_harness->finish();
	my $time = tv_interval($before, $after);      
	@results = $cmd_harness->results();
	$self->execution_time($time);

	if (defined($results[0]) && $results[0] == 0) {
	    $self->finish_command($run);
	}
	log_normal(sprintf("Elapsed time = %12.6f",$time));
      }
    };
    my $die_msg = $@;

    # Copy Stdout and Stderr to the log file
    unless ($options->dryrun()) {
	if ($self->stdout) { 
	    log_push_category("stdout");
	    log_file_contents($self->stdout());
	    log_pop_category();
	}
	unless ($self->_tied_outputs()) {
	    if ($self->stderr) {
		log_push_category("stderr");
		log_file_contents($self->stderr());
		log_pop_category();
	    }
	}
    }

    if (defined($newdir)) {
      pop_directory();
    }

    if ($die_msg) {
      log_die($die_msg);
    }
    if (defined($results[0])) {
      log_normal("Command returned = " . $results[0]);
      return $results[0];
    } else {
      log_warn("Command Failed");
    }
    return -1;
}

sub finish_command {
    # empty!
}

sub grep_output {
    my $self = shift;
    my $regexp = shift;
    if ($self->_stdout_filename()) {
	
	my $property = new RSTF::Exec::Property(	
						pattern => $regexp,
						filename => $self->_stdout_filename()
						);
	
	my $match = $property->do_match();
	if ($match && ($match->matched() eq 'true')) {
	    return $match->value();
	}
    }
    return undef;
}	

1;
