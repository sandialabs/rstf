###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# QueueCommand.pm
# 
# Created by: Robert A. Ballance		Tue Apr 27 16:46:19 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/QueueCommand.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Exec::QueueCommand;
use strict;
use warnings;


use RSTF::Exec::Command;
use RSTF::LogFile;
use RSTF::FilePath;


use vars qw(@ISA);

@ISA = qw(RSTF::Exec::Command);

# handler is a queue object.
# Right now, the only one is NQS.
use Class::MethodMaker(
		       new_with_init => 'new',
		       new_hash_init=> '_init_hash',
		       get_set => [qw(default_maxtime script_name handler dribblefile)]
		       );

sub cmd_string {
  my $self = shift;
  my $cmd_string = sprintf("%s %s %s", $self->executable, $self->arguments, $self->script_name);
}

sub compile {
    my $self = shift;
    my $script = $self->script_name;

    unless (-e $script && -x $script) {
	die "Invalid run script $script\n";
    }
    return $self;
}

sub execute {
    my $self = shift;
    my $options = shift;	# Ignored
    my $run = shift;		# Ignored

    my $queueproc = $self->handler;
    my $result;
    log_push_category('queue');
    if ($options->dryrun()) {
	$result = $queueproc->describe($self);
    } else {
	$result  = $queueproc->submit($self);
    }
    log_pop_category();

    return $result;
}


1;
    
