###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# DiskAllocator.pm
# 
# Created by: Robert A. Ballance		Fri May 14 09:32:22 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/DiskAllocator.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Exec::DiskAllocator;

use RSTF::DB::OutputDirectory;
use RSTF::FilePath;

use vars qw(@ISA);

@ISA = qw(RSTF::DB::OutputDirectory);

my %typemap = (
	       'viz' => {countvar => 'NUMVDISKS',  diskname => 'VDISK%d'},
	       'raid' => {countvar => 'NUMRAIDS',  diskname => 'RAID%d'}
	      );

use RSTF::LogFile;

sub allocate  {
  my $self = shift;

  my $username = shift;
  my $testname = shift;
  my $test_size = shift;

  my $path_prefix = $self->path;

  my $type = $self->type;
  my $howmany = $self->number;
  if ($howmany > $test_size) {
    log_warn("Test size $test_size is smaller than the $type disk request $howmany");
    $howmany = $test_size;
  }

  my @dirs = ();

  my $diskname = $typemap{$type->type_name}->{diskname};
  my $count_var = $typemap{$type->type_name}->{countvar};

  die "BAD DISK ALLOCATOR" unless ($diskname && $count_var);

  log_notice("$count_var = $howmany");
  $ENV{$count_var} = $howmany;
  for (my $i = 1; $i <= $howmany; $i++) {
      my $file = sprintf($path_prefix, $i, $username, $testname, $test_size);
      my $var = sprintf($diskname, $i);
      make_directory($file);
      $ENV{$var} = $file;
      push (@dirs, $file);
      log_notice("$var = $file");
  }
  $self->directories(\@dirs);
  return @dirs;
}


1;
