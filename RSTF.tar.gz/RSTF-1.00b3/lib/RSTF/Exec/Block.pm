###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Block.pm
# 
# Created by: Robert A. Ballance		Tue Mar  2 10:23:04 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Block.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
#  'Block' represents the equivalent of a basic block in compilerese.
# It is a sequence of commands that are executed together, without
# branching.
#
# The Block module is pretty simple --- it just walks over lists 
# of commands doing the "right thing".
#
# ParBlock, derived from Block, handles the nastiness of queuing 
# systems.
#
###############################################################################
#
#
package RSTF::Exec::Block;
use strict;
use Class::MethodMaker (
			new_hash_init => '_init_hash',
			new_with_init => 'new',
			get_set => [qw(commands
				       compiled_commands
				       execution_time
				       last_command
				       dispatch)]
);
			
use RSTF::Exec::Command;
use RSTF::Exec::GradedCommand;
use RSTF::DB::Grade;

use RSTF::DB::Utils qw(:utils);

my @default_args = (commands=>[], compiled_commands=>[], execution_time=>0);

sub init {
  my $self = shift;
  $self->_init_hash(@default_args, @_);
  return $self;
}

sub is_empty {
  my $self = shift;
  my $cmds = $self->commands();
  unless ($cmds) {
      dump_stack(8);
      die "Illegal command reference\n";
  }
  my @x = @$cmds;
  return ($#x < 0);
}

#
# add is overridden in ParBlock to add new commands to
# a Parallel execution environment.
#
sub add {
  my $self = shift;
  my $command = shift;
  if (!$command->is_parallel()) {
      my $cmds = $self->commands();
      my @clist = @$cmds;
      push @clist, $command;
      $self->commands(\@clist);
      return 1;
  } else {
      return 0;
  }
}

my %graded_command_regexp = (
			     validate => '^\s*Validate:\s*(\w)\w*(.*)$',
			     score => '^\s*Score:\s*(\w)\w*(.*)$'
			     );

# Compile is overridden within a ParBlock
# to allow compiling for queued execution.

sub compile {
  my $self = shift;
  my $env = shift;
  my $options = shift;
  my $block_name  = shift;

  my $cmd_list = $self->commands();


  my $last_cmd;
  my @compiled_commands = ();
  foreach my $cmd (@$cmd_list) {
      $last_cmd = $cmd;
      my $result = $cmd->compile($env, $options);
      push @compiled_commands, $result;
  }

  my $regexp = $graded_command_regexp{$block_name};
  if ($last_cmd && $regexp) {
      pop @compiled_commands;
        my $gc = bless($last_cmd, 'RSTF::Exec::GradedCommand');
      $gc->regexp($regexp);
      my $result = $gc->compile($env, $options);
      push @compiled_commands, $result;
  }

  $self->compiled_commands(\@compiled_commands);
}

#
# Just run the list of compiled commands and
# execute them. In general, the $env is a
# test case.
sub execute {
  my $self = shift;
  my $options = shift;
  my $run = shift;

  my $cmd_list = $self->compiled_commands();
  my $time = 0;
  my $last_command;
  my $result = 0;
  foreach my $cmd (@$cmd_list) {
      $last_command = $cmd;
      $result = $cmd->execute($options, $run);
      $time += ($cmd->execution_time() || 0);
      if ($result) {
	  if ($cmd->failure_ok()) {
	      # Skip cmd, set result to 0 (in case this is the last command) and keep going
	      $result = 0;
	  } else {
	      last;
	  }
      }
  } 
  $self->last_command($last_command);
  $self->execution_time($time);
  return $result;
}

sub grade {
    my $self = shift;

    my $last_command = $self->last_command();
    if ($last_command) {
	return $last_command->grade();
    }
    undef;
}

1;
