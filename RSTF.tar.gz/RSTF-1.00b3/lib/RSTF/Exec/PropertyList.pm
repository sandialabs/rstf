###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# PropertyList.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/PropertyList.pm,v $
# $Revision: 1.5 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
# ToDo - Compile the matchers into all those that process a single File.
#
package RSTF::Exec::PropertyList;
use strict;

use RSTF::DB::PropertyList;

use vars qw(@ISA);
@ISA = qw(RSTF::DB::PropertyList);

use RSTF::Exec::Property;
use RSTF::LogFile;
use RSTF::DB::PropertyMatch;
use RSTF::DB::PropertyMatchList;

sub execute {
  my $self = shift;
  my $run = shift;
  my $matchers = $self->matchers();

  log_push_category('properties');
  my @result_list = ();
  foreach my $m (@$matchers) {
    log_notice("Checking " . $m->property_name );
    my $result =  $m->do_match($run);
    if ($result->matched) {
      log_normal("Matcher for " . $m->property_name . " found " . $result->value);
    } else {
      log_normal("Matcher for " . $m->property_name . " FAILED");
    }
    push @result_list, $result;
  }
  $run->property_matches(new RSTF::DB::PropertyMatchList(values=>\@result_list, run_id=>$run->run_id));
  log_pop_category();
}

1;

