###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Dispatch.pm
# 
# Created by: Robert A. Ballance		Tue Apr 27 15:50:40 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Dispatch.pm,v $
# $Revision: 1.4 $
# $Name:  $
# $State: Exp $
# 

###############################################################################

package RSTF::Exec::Dispatch;
use RSTF::DB::Dispatch;

use vars qw(@ISA);

@ISA=qw(RSTF::DB::Dispatch);

use Class::MethodMaker(
		       get_set => [qw(platform)]

);

# convert processor count to nodes
sub nodes {
    my $self = shift;
    return $self->procs;
}

1;
