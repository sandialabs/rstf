###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# ParBlock.pm
# 
# Created by: Robert A. Ballance		Mon Apr 12 12:05:03 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/ParBlock.pm,v $
# $Revision: 1.7 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::Exec::ParBlock;
use strict;
use warnings;

use RSTF::Exec::Block;
use RSTF::Exec::Command;
use RSTF::Platform::Red::Platform;
use RSTF::Platform::RedStorm::Platform;
use RSTF::Exec::Options;
use RSTF::DB::Utils qw(:times);
use RSTF::DB::Dispatch;

use vars qw(@ISA);
@ISA = qw(RSTF::Exec::Block);


sub compile {
    my $self = shift;
    my $env = shift;
    my $options = shift;

    if ($options->interactive()) {
	$self->SUPER::compile($env, $options);
    } else {
	# Here to build the right script!
	my $commands = $self->commands();
	my @strings = ();
	my $platform = $options->platform();

	foreach my $command (@$commands) {
	    $command->compile($env, $options);
	    my $cmd_shell_str = $command->as_shell_command();
	    push @strings, $cmd_shell_str;
	}

	my $newcommand = $platform->build_queue_command(\@strings, $self, $options);
	
	my $ccommand = $newcommand->compile($env, $options);

	$self->compiled_commands([$ccommand]);
    }
}

#
# Add a new command into the block --- remember the number of processors required,
# and increment the needed wall time.
#
sub add {

    my $self = shift;
    my $command = shift;
    my $platform = shift;
    
    my $dispatch = $self->dispatch();
    my $cmd_disp = $command->dispatch();    

    unless ($dispatch) {
	# Need own dispatch
	$dispatch = $platform->clone_dispatch($cmd_disp);
	# reset time to 0!
	$dispatch->max_time('0:00:00');
	$self->dispatch($dispatch);
    }

    if ($dispatch->unify($cmd_disp)) {
	my $cmds = $self->commands() || [];
	my @clist = @$cmds;
	push @clist, $command;
	$self->commands(\@clist);
	return 1;
    }
    return 0;
}


1;

