###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# TestCase.pm
# 
# Created by: Robert A. Ballance		Thu Feb 12 14:08:34 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/TestCase.pm,v $
# $Revision: 1.12 $
# $Name:  $
# $State: Exp $
# 
###############################################################################

package RSTF::Exec::TestCase;

use strict;

use RSTF::DB::TestCase;
use RSTF::ToolInfo;

use vars qw(@ISA);

@ISA= qw(RSTF::DB::TestCase);

use Class::MethodMaker (
			new_with_init => 'new',
			get_set => [ qw(
					total_execution_time
					) ]
);

use RSTF::LogFile;
use RSTF::Exec::Command;
use RSTF::FilePath;
use RSTF::Exec::DiskAllocator;
use RSTF::Exec::PropertyList;
use RSTF::DB::RunList;
use RSTF::DB::Run;
use RSTF::DB::Grade;
use RSTF::Exec::Benchmark;

my @default_args = (total_execution_time=> 0.0, description=>'Undocumented test case');

# use constant GRADE_REGEXP => '^\s*Grade:\s*(\w)\w*\s*(.*)$';
# use constant VALIDATE_REGEXP => '^\s*Validate:\s*(\w)\w*\s*(.*)$';

sub init {
  my $self = shift;
  $self->SUPER::init(@default_args, @_);
  return $self;
}

# Print a short description of the test case.
sub describe {
    my $self = shift;
    if ($self->testcase_id) {
	return sprintf("%s (id = %s)", $self->name, $self->testcase_id);
    } else {
	return  $self->name;
    }
}


sub print_description {
    my $self = shift;
    print "TestCase: " . $self->describe . "\n";
    print "Size: " . $self->size . "\n";
    print "Working Directory: " . $self->working_directory . "\n";
    print "Description: " . $self->description . "\n";
}

sub std_output_filename {
    my $self = shift;
    return $self->stdout;
}


sub std_error_filename {
    my $self = shift;
    return $self->stderr;
}

# After setup, perform any preprocessing required.
sub _run_block {
    my $self = shift;
    my $block = shift;
    my $options = shift;
    my $run = shift;

    if ($block) {
	$block->compile($self, $options);
	log_push_category($block->name); 
	my $result = $block->execute($options, $run);
	my $time = $block->execution_time;
	$self->total_execution_time($time + $self->total_execution_time());
	log_pop_category();
	return $result;
    }
    # empty blocks always succeeed
    return 0;
}

# RUNTIME HOOKS
sub setup {
    my $self = shift;
    my $options = shift;
    $self->_run_block($self->setup_commands(), $options);

}

sub start_compile {
    # set the various goodies
    my $self = shift;
    my $app = shift;
    my $timestamp = shift;
    my $options = shift;

    log_normal("Starting the compilation\n");
    log_normal("Wrapper output to: " . $options->make_wrapper_info_file);
    log_normal("Timestamp is : " . $timestamp);

    RSTF::ToolInfo->start_compilation($app->name, 
				     undef,
				     $options->platform->name, 
				     $timestamp,
				     $options);

}

sub end_compile {
    my $self = shift;
    my $app = shift;
    my $options = shift;

    my $appbinary = $self->appbinary();
    if ($appbinary) {
	my $exe = $appbinary->expanded_path();
	RSTF::ToolInfo->end_compilation($exe, $options);
    } else {
	RSTF::ToolInfo->end_compilation();
      }
}


sub compile {
    my $self = shift;
    my $options = shift;
    my $app = shift;
    my $timestamp = shift;

    my $cmd_block = $self->compile_commands();
    if ($cmd_block && !$cmd_block->is_empty()) {
	$self->start_compile( $app, $timestamp, $options);
	eval {
	    $self->_run_block($cmd_block, $options);
	};
	
	$self->end_compile($app, $options);
    }
    $self->check_app_binary($app, $timestamp, $options);
}

sub install {
    my $self = shift;
    my $options = shift;
    $self->_run_block($self->installation_commands(), $options);
}


sub cleanup {
    my $self = shift;
    my $options = shift;
    
    $self->_run_block($self->cleanup_commands(), $options);
    $self->environment()->remove();
}

sub capture_testcase_times {
    my $self = shift;
    my $run = shift;
    
    $run->setup_time($self->setup_time());
    $run->compile_time($self->compile_time());
    $run->installation_time($self->installation_time());
    $run->cleanup_time($self->cleanup_time());
}

# After setup, perform any preprocessing required.
sub initialize_run {
    my $self = shift;
    my $run = shift;
    my $options = shift;

    my $timestamp = localtime;
    $run->system_configuration($self->platform->get_configuration());
    $run->time_start($timestamp);
    $run->outcome_id(RSTF::DB::Outcome::INITIATED);
    $self->environment()->add();
    $run->purpose($options->purpose());

    # Move over the actual app binary object.
    # All the run objects will share the same one!
    if ($self->actual_appbinary) {
	$run->appbinary($self->actual_appbinary);
    }

    my $stdout = $self->std_output_filename();
    my $stderr = $self->std_error_filename();
    my $output_files = $self->output_files() || [];

    foreach my $file ($stdout, $stderr, @$output_files) {
	if (-e $file) {
	    log_notice("Testcase::initialize - removing file $file");
	    my $ok = unlink $file;
	    unless ($ok) {
		log_normal("Unable to delete $file");
	    }
	}
    }
    $self->data_directories->allocate($ENV{LOGNAME}, $self->name,  $self->size);
}

sub finalize_run {
    my $self = shift;
    my $run = shift;
    my $options = shift;

    $self->_run_block($self->final_commands(), $options);
    $run->finally_time($self->finally_time());

    # remove 0-length error outputs

    my $stderr = $self->std_error_filename();
    if (-z $stderr) {
	log_notice("Deleting $stderr");
	my $ok = unlink $stderr;
	unless ($ok) {
	    log_normal("Unable to delete $stderr");
	}
    }
    # Do something with data_directories?

    my $timestamp = localtime;
    $run->time_end($timestamp);
}

# code to run a single run
sub run_run {
    my $self = shift;
    my $run = shift;
    my $options = shift;

    my $return_code;
    eval {

	$self->initialize_run($run, $options);
	
	($self->preprocess($run,  $options) == 0) or die "Preprocess failed";
	
	if ($return_code = $self->exec($run, $options)) {
	    log_warn("Failed: return code $return_code");
	    $run->outcome_id(RSTF::DB::Outcome::FAILED);
#	    $self->handle_failure($run, $options);
	    die "Execution failed (rc=$return_code)";
	} 
	$run->outcome_id(RSTF::DB::Outcome::COMPLETED);
	$run->add_note("Successful completion");

	($self->postprocess($run,  $options) == 0) or die "Postprocess failed";

	($self->validate($run, $options)  == 0) or die "Validation failed";
	
	($self->score($run, $options)  == 0) or die "Scoring failed";

	$self->property_matchers()->execute($run);

    };
    if ($@) {
	my $msg = $@;
	$msg =~ s/ at .*?$//g;
	$run->add_note($msg);
    }
    # finalize run
    $self->finalize_run($run, $options);
}

# Code to run the entire test case, with one or more runs.
sub run_testcase {
    my $self = shift;
    my $options = shift;
    my $app = shift;
    my $timestamp = shift;

    log_push_category("run job");

    log_normal("Test Case: " . $self->describe);
    log_normal("Test Size: " . $self->size);

    if ($self->working_directory) {
	push_directory($self->working_directory);
    }

    $self->setup($options);
    $self->compile($options, $app, $timestamp);
    $self->install($options);

    my $runs = $self->run_list->runs();

    my $run_ct = 0;

    my $first_run;		# Remember the first run;

    # nice to fold this into runlist, but it calls back into RSTF::Exec!
    foreach my $run (@$runs) {
	# skip previously run runs.
	# Nice to call is_interned, but that needs the DAO
	unless (defined($run->job_time)) {
	    $self->run_run($run, $options);
	    $run_ct++;
	    unless ($first_run) {
		$first_run = $run;
	    }
	}
    }

    if ($run_ct == 0)  {
	log_notice("Creating new Run");
	my $run = new RSTF::DB::Run(testcase_id=> $self->testcase_id);
	push @$runs, $run;
	$self->run_run($run, $options);
	$first_run = $run;
	$self->run_list->runs(\@$runs);
     }

    $self->cleanup($options);
    if ($first_run) {
	$self->capture_testcase_times($first_run);
    }
    if ($self->working_directory) {
      pop_directory();
    }
    log_pop_category();
}

# PER_RUN CODE

# After setup, perform any preprocessing required.
sub preprocess {
  my $self = shift;
  my $run  = shift;
  my $options = shift;
  my $result =   $self->_run_block($self->preprocess_commands(), $options, $run);
  $run->preprocess_time($self->preprocess_time());
  return $result;
}

# Execute the core commands
sub exec {
  my $self = shift;
  my $run  = shift;
  my $options = shift;

  my $result =  $self->_run_block($self->exec_commands(), $options, $run);
  my $time = $self->job_time();
  $run->job_time($time);
  log_normal(sprintf("Job Exec Time: %12.6f sec", $time));

  return $result;
}


# Before cleanup, perform any postprocessing required.
sub postprocess {
    my $self = shift;
    my $run  = shift;
    my $options = shift;
    my $result = $self->_run_block($self->postprocess_commands(), $options, $run);
    $run->postprocess_time($self->postprocess_time());
    return $result;
}


# Validation. Need to know if command failed or not! May not be able to use
# run block here
sub validate {
  my $self = shift;
  my $run = shift;
  my $options = shift;

  my $block = $self->validate_commands();
  if ($block) {
      my $result =  $self->_run_block($block, $options, $run);
      $run->validation_time($self->validation_time());
      unless ($result) {
	  my $grade = $block->grade() || RSTF::DB::Grade->grade_from_mnemonic('U');
	  if ($grade && $grade->mnemonic =~ /[UFP]/i) {
	      $run->validation_result($grade);
	      $run->grade($grade);
	      $run->add_note($grade->comments());
	  } else {
	      warn "Invalid result for validation score: " . $grade->mnemonic;
	  }
      }
      return $result;
  }
  return 0;
}


# Score
sub score {
  my $self = shift;
  my $run = shift;
  my $options = shift;

  my $block = $self->grade_commands();
  if ($block) {
      my $result =  $self->_run_block($block, $options, $run);
      $run->grade_time($self->grade_time());
      unless ($result) {
	  my $grade = $block->grade();
	  if ($grade) {
	      $run->grade($grade);
	      $run->add_note($grade->comments());
	  }
	  if ($run->grade->mnemonic) {
	      log_normal("Scoring complete with grade " . $run->grade->mnemonic);
	  } else {
	      log_normal("No score assigned");
	  }
      }
      return $result;
  }
  return 0;
}


# Before cleanup, perform any preprocessing required.
sub app_failed {
    my $self = shift;
    my $run = shift;
    $run->outcome_id(RSTF::DB::Outcome::FAILED);
}

# This ugly bit of code tries to retrieve the Dispatch object
# from a parallel command block.
sub get_parallel_dispatch {
    my $self = shift;
    my $platform = shift;
    my $pcommands = $self->exec_commands();

    my $dispatch;

    eval {
	$dispatch = $pcommands->get_parallel_dispatch($platform);
    };
    if ($@) {
	print STDERR $@;
    }
    return $dispatch;
}



1;
