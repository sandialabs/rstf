###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Options.pm
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Options.pm,v $
# $Revision: 1.10 $
# $Name:  $
# $State: Exp $
# 
###############################################################################
package RSTF::Exec::Options;

use RSTF::Configuration;

use strict;

use vars qw(@ISA);
@ISA = qw(RSTF::Configuration);

use Class::MethodMaker(
		       get_set => [ qw(platform) ] 
);

use strict;
use RSTF::LogFile;
use RSTF::DB::Purpose;

my @config_opts = qw( debug 
		      verbose 
		      dryrun 
		      interactive 
		      suppress_path_lookups 
		      logfile 
		      resultfile 
		      platform 
		      run_purpose );

sub new {
  my $self = shift;
  
  my $x = $self->SUPER::new(@_);
  # My base class returns a singleton. We need to rebless it into our class
  # for this call.
  return bless($x, 'RSTF::Exec::Options');
}

sub show_config {
  my $self = shift;
  foreach my $opt (@config_opts) {
    log_normal(sprintf("Config: %s = %d", $opt, $self->$opt()));
  }
}

# override purpose
sub purpose {
    my $self = shift;
    my $name = $self->run_purpose || 'unknown';
    return RSTF::DB::Purpose->purpose_from_name($name);
}

1;
