###############################################################################
# copyright {
# Copyright (c) 2004, Sandia Corporation. 
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation, the
# U.S. Government retains certain rights in this software.
# 
# This file is a portion of the Robust Systems Test Framework
# distribution, under the provisions of a BSD-style open source license.
# A copy of the license agreement is distributed with the software.
# 
# 
# 
# }
# Benchmark.pm
# 
# Created by: Robert A. Ballance		Wed Apr 14 12:56:59 2004
# 
# $Source: /cvsroot/sevenx/sevenx/util/src/perl/RSTF/lib/RSTF/Exec/Benchmark.pm,v $
# $Revision: 1.9 $
# $Name:  $
# $State: Exp $
# 
# Given an Application and a Test Case, run the Application on the TestCase data.
# Now smart enought to run an array of test cases and to check if each one needs
# to be recompiled.
#
# We might could be smarter about how all this works, but it will be better
# to try to run sPPM tomorrow, with the new structures!
# Also try to run CTH or presto correctly
#
###############################################################################

package RSTF::Exec::Benchmark;

use RSTF::DB::Benchmark;

use vars qw(@ISA);

@ISA = qw(RSTF::DB::Benchmark);

use Class::MethodMaker(
		       get_set => [qw(
				      start_time
				      end_time
				      result_file

				      result_path
				     )]
);


use strict;
use Cwd;
use IPC::Run qw(run timeout harness);
use Time::HiRes qw(tv_interval gettimeofday);

use RSTF::LogFile;
use RSTF::FilePath;
use RSTF::Exec::Application;
use RSTF::Exec::TestCase;
use RSTF::Exec::Options;
use RSTF::DB::Outcome;

## INSTANCE METHODS

# Create the logfile name for this run. 
# Todo: Include the timestamp.
#
sub logfile {
    my $self = shift;
    my $options = shift;

    my $option_name = $options->logfile();

    my $log_file_name = $self->log_filename();

    # name in file overrides the option name.
    unless ($log_file_name) {
	$log_file_name = $option_name;
	$self->log_filename($log_file_name);
    }

    my $logpath = $self->log_path() || $options->run_log_directory();

    log_debug("logpath is $logpath");
    
    log_debug("run log directory is " . $options->run_log_directory() );

    my ($sec, $min, $hr, $day, $month, $year) = localtime;

    my $result_dir = sprintf("%s/%04d%02d%02d.%02d%02d%02d", $logpath, $year + 1900, $month+1, $day, $hr, $min, $sec);

    make_log_directory($result_dir);

    $self->log_path($logpath);

    my $result_path = sprintf("%s/%s", current_directory(),  $result_dir);
    $self->result_path($result_path);

    my $compiler_output_file = sprintf("%s/%s", $result_path, $options->make_wrapper_info_file());
    # update the compiler info file here, in place in the options object
    $options->make_wrapper_info_file($compiler_output_file);

    return  sprintf("%s/%s", $result_dir, $log_file_name);
}

sub execute {
    my $self = shift;
    my $options = shift;

    my $log_level = $options->debug() ? DEBUG : ($options->verbose() ? NOTICE : NORMAL);
    my $app = $self->application() ;
    my $tests =  $self->testcases();
    
    my $rootdir = $self->root_directory();

    if (defined($rootdir)) {
	# Watch the order here. $rootdir is relative to the script,
	# but all other paths are relative to rootdir

	#
	my $directory = expand_path($rootdir); 
	push_directory($directory);
	set_working_root();
    }

    # Recursive tests have an indented section in the log file
    push_log($self->logfile($options), $log_level);

    my $start_time = localtime;
    log_normal("Application: " . $app->describe);
    log_normal("Time: ", $start_time);
    $self->start_time($start_time);

    if ($options->verbose() || $options->debug()) {
	$options->show_config();
    }
    
    foreach my $test (@$tests) {
	# last two arguments are for the compile file, if generated.
	$test->run_testcase($options, $app, $start_time);
    }

    # Log end time
    my $end_time = localtime;
    log_normal("End Time: ", $end_time);
    $self->end_time($end_time);
    
    $self->output_results($options->result_file());

    #remember to pop the logfile
    pop_log();

    if (defined($rootdir)) {
      pop_directory();
      set_working_root();
    }
}

sub print_description {
    my $self = shift;
    print "Benchmark: " . $self->benchmark_id() . "\n";
    $self->application->print_description();
    $self->platform->print_description();
    my $tests =  $self->testcases();
    foreach my $test (@$tests) {
      $test->print_description();
    }
}

# This function will bind STDOUT
sub output_results {
    my $self = shift;
    my $output_file = shift;

    my $result_path  =  $self->result_path();
    log_normal("Result path  directory is " . $result_path );
    log_normal("Output file is " . $output_file );

    my $result_file = sprintf("%s/%s", $result_path,  $output_file);
    $self->result_file($result_file);

    open(OUTPUT, ">$result_file") or die "Unable to create result file $result_file";
    select(OUTPUT);
    $self->write_xml;
    select(STDOUT);
    close(OUTPUT);
}

1;
